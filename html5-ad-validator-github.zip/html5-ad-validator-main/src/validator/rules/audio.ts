import type { ValidationRule } from "../types";

const AUDIO_EXTENSIONS = [
  "mp3",
  "wav",
  "ogg",
  "aac",
  "m4a",
];

export const audioRule: ValidationRule = {
  id: "MEDIA001",

  name: "Audio",

  description:
    "Checks whether the creative package contains audio.",

  category: "media",

  type: "static",

  async run(context) {
    const audioFiles = Array.from(
      context.files.values()
    ).filter((file) =>
      AUDIO_EXTENSIONS.includes(file.extension)
    );

    const htmlHasAudio =
      context.indexHtml
        ?.toLowerCase()
        .includes("<audio") ?? false;

    const detected =
      audioFiles.length > 0 || htmlHasAudio;

    return {
      ruleId: "MEDIA001",
      title: "Audio",
      category: "media",
      status: "pass",

      actual: detected,

      message: detected
        ? `Audio detected${
            audioFiles.length
              ? ` (${audioFiles.length} file(s)).`
              : "."
          }`
        : "No audio detected.",

      files:
        audioFiles.length > 0
          ? audioFiles.map((file) => file.path)
          : undefined,
    };
  },
};