import type { ValidationResult } from "../types";
import type { ValidationRuleProfile, ValidationProfile } from "./types";

export function resolveRuleProfile(profile: ValidationProfile, ruleId: string): ValidationRuleProfile {
  return profile.rules[ruleId as keyof typeof profile.rules] ?? { enabled: true };
}

export function profileMetadata(profile: ValidationProfile) {
  return {
    id: profile.id,
    name: profile.name,
    description: profile.description,
  };
}

export function applySeverityOverride(result: ValidationResult, ruleProfile: ValidationRuleProfile): ValidationResult {
  if (!ruleProfile.severity || result.status === "pass" || result.status === "info") {
    return result;
  }

  return {
    ...result,
    status: ruleProfile.severity,
  };
}
