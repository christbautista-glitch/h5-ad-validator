export interface CreativeFile {
  path: string;
  size: number;
  extension: string;
  content?: string;
  contentBytes?: Uint8Array;
}

export type ResourceType = "script" | "image" | "stylesheet" | "font" | "video" | "audio" | "iframe" | "other";
export type ResourceLocation = "local" | "external" | "data";
export type ResourceProtocol = "http" | "https" | "protocol-relative" | "data" | "local";

export interface CreativeResource {
  raw: string;
  resolved?: string;
  sourceFile: string;
  type: ResourceType;
  location: ResourceLocation;
  protocol: ResourceProtocol;
  commented?: boolean;
}

export interface CreativeContext {
  filename: string;

  compressedSize: number;

  files: Map<string, CreativeFile>;

  indexHtml?: string;

  resources?: CreativeResource[];
}
