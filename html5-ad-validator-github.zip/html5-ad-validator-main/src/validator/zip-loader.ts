import JSZip from "jszip";

import type {
  CreativeContext,
  CreativeFile,
} from "./context";

const MAX_UNCOMPRESSED_BYTES = 250 * 1024 * 1024;

function getExtension(filename: string): string {
  const parts = filename.split(".");

  if (parts.length < 2) {
    return "";
  }

  return parts.pop()?.toLowerCase() ?? "";
}

function isTextFile(extension: string): boolean {
  return [
    "html",
    "htm",
    "css",
    "js",
    "json",
    "txt",
    "svg",
    "xml",
  ].includes(extension);
}

function normalizePath(path: string): string {
  return path.replace(/\\/g, "/");
}

function isIgnoredZipEntry(path: string): boolean {
  const normalizedPath = normalizePath(path);
  const parts = normalizedPath.split("/").filter(Boolean);

  return parts.some((part) => {
    const name = part.toLowerCase();

    return (
      name === "__macosx" ||
      name === ".ds_store" ||
      name === "thumbs.db" ||
      name === "desktop.ini" ||
      name.startsWith("._")
    );
  });
}

function isUnsafePath(path: string): boolean {
  const normalizedPath = normalizePath(path);

  return (
    normalizedPath.includes("../") ||
    normalizedPath.startsWith("/")
  );
}

export async function loadCreativeZip(
  file: File
): Promise<CreativeContext> {
  const buffer = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(buffer);

  /*
   * First filter out:
   * - directories
   * - macOS / Windows metadata
   * - unsafe traversal paths
   */
  const validEntries = Object.entries(zip.files).filter(
    ([path, zipEntry]) => {
      if (zipEntry.dir) {
        return false;
      }

      const normalizedPath = normalizePath(path);

      if (isIgnoredZipEntry(normalizedPath)) {
        return false;
      }

      if (isUnsafePath(normalizedPath)) {
        return false;
      }

      return true;
    }
  );

  /*
   * Detect whether all actual creative files live
   * inside the same top-level wrapper folder.
   *
   * Example:
   *
   * creative/index.html
   * creative/style.css
   * creative/script.js
   *
   * becomes:
   *
   * index.html
   * style.css
   * script.js
   */
  const firstSegments = validEntries.map(([path]) => {
    return normalizePath(path).split("/")[0];
  });

  const hasSingleWrapperFolder =
    validEntries.length > 0 &&
    firstSegments.every(
      (segment) => segment === firstSegments[0]
    ) &&
    validEntries.every(([path]) =>
      normalizePath(path).includes("/")
    );

  const wrapperFolder = hasSingleWrapperFolder
    ? firstSegments[0]
    : undefined;

  const files = new Map<string, CreativeFile>();

  let indexHtml: string | undefined;
  let totalUncompressedBytes = 0;

  for (const [originalPath, zipEntry] of validEntries) {
    let path = normalizePath(originalPath);

    /*
     * Remove the common wrapper folder so the validator
     * sees index.html as being at the creative root.
     */
    if (
      wrapperFolder &&
      path.startsWith(`${wrapperFolder}/`)
    ) {
      path = path.slice(wrapperFolder.length + 1);
    }

    const extension = getExtension(path);

    const binary = await zipEntry.async("uint8array");
    totalUncompressedBytes += binary.byteLength;

    if (totalUncompressedBytes > MAX_UNCOMPRESSED_BYTES) {
      throw new Error("The ZIP archive expands beyond the 250 MB safety limit.");
    }

    let content: string | undefined;

    if (isTextFile(extension)) {
      content = await zipEntry.async("string");
    }

    files.set(path, {
      path,
      size: binary.byteLength,
      extension,
      content,
      contentBytes: binary,
    });

    if (path.toLowerCase() === "index.html") {
      indexHtml = content;
    }
  }

  return {
    filename: file.name,
    compressedSize: file.size,
    files,
    indexHtml,
  };
}
