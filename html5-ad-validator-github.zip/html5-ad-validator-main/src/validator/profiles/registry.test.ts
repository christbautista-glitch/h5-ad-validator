import { describe, expect, it } from "vitest";
import { getDefaultValidationProfile, getValidationProfile, listValidationProfiles } from "./registry";

describe("validation profiles", () => {
  it("resolves the default profile", () => {
    const profile = getDefaultValidationProfile();

    expect(profile.id).toBe("html5-standard");
    expect(profile.name).toBe("HTML5 Standard");
  });

  it("resolves all built-in profiles", () => {
    expect(getValidationProfile("html5-standard")).toMatchObject({ name: "HTML5 Standard" });
    expect(getValidationProfile("gdn")).toMatchObject({ name: "GDN" });
  });

  it("rejects unknown profile IDs", () => {
    expect(getValidationProfile("missing-profile")).toBeUndefined();
  });

  it("lists trusted registered profiles", () => {
    expect(listValidationProfiles()).toEqual([
      expect.objectContaining({ id: "html5-standard", name: "HTML5 Standard" }),
      expect.objectContaining({ id: "gdn", name: "GDN" }),
    ]);
  });

  it("represents ASSET002 as disabled in the default profile", () => {
    expect(getDefaultValidationProfile().rules.ASSET002).toEqual({ enabled: false });
  });

  it("enables the added checklist rules by default", () => {
    const rules = getDefaultValidationProfile().rules;
    for (const id of ["ADBLOCK001", "PERF002", "CODE002", "JS002", "ASSET005", "TRACK001", "PERF003", "NET003", "RENDER002", "CODE003"] as const) {
      expect(rules[id]?.enabled).toBe(true);
    }
  });

  it("uses profile-specific rule enablement", () => {
    expect(getValidationProfile("html5-standard")?.rules.GWD001).toEqual({ enabled: true, severity: "fail", thresholds: { requireEnabler: 1 } });
    expect(getValidationProfile("html5-standard")?.rules.GWD002).toEqual({ enabled: true, thresholds: { requireStudioHooks: 1 } });
    expect(getValidationProfile("gdn")?.rules.GWD001).toEqual({ enabled: true, severity: "fail", thresholds: { requireEnabler: 0 } });
    expect(getValidationProfile("gdn")?.rules.GWD002).toEqual({ enabled: true, thresholds: { requireStudioHooks: 0 } });
  });

  it("keeps thresholds independently configurable by profile", () => {
    expect(getValidationProfile("html5-standard")?.rules.SIZE001?.thresholds?.maxBytes).toBe(4 * 1024 * 1024);
    expect(getValidationProfile("gdn")?.rules.SIZE001?.thresholds?.maxBytes).toBe(600 * 1024);
    expect(getValidationProfile("gdn")?.rules.SIZE002?.thresholds?.maxBytes).toBe(Number.MAX_SAFE_INTEGER);
  });
});
