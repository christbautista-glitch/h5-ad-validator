import { describe, expect, it } from "vitest";
import { createBulkValidationReport, createValidationReport, isBlockingStatus, summarizeResults } from "./report";

describe("validation reporting", () => {
  it("normalizes all result statuses into one summary", () => {
    const results = ["pass", "warning", "fail", "info", "pass"].map((status) => ({
      ruleId: status,
      title: status,
      category: "html" as const,
      status: status as "pass" | "warning" | "fail" | "info",
      message: status,
    }));
    expect(summarizeResults(results)).toEqual({ total: 5, pass: 2, warning: 1, fail: 1, info: 1 });
    expect(createValidationReport("creative.zip", results, "2026-01-01T00:00:00.000Z")).toMatchObject({ filename: "creative.zip", generatedAt: "2026-01-01T00:00:00.000Z" });
  });

  it("includes validation profile metadata", () => {
    const report = createValidationReport("creative.zip", [], "2026-01-01T00:00:00.000Z", {
      id: "html5-standard",
      name: "HTML5 Standard",
    });

    expect(report.profile).toEqual({ id: "html5-standard", name: "HTML5 Standard" });
  });

  it("aggregates summaries for bulk validation reports", () => {
    const first = createValidationReport("first.zip", [{
      ruleId: "PASS001",
      title: "Pass",
      category: "html",
      status: "pass",
      message: "Passed",
    }], "2026-01-01T00:00:00.000Z");
    const second = createValidationReport("second.zip", [{
      ruleId: "FAIL001",
      title: "Fail",
      category: "html",
      status: "fail",
      message: "Failed",
    }], "2026-01-01T00:00:00.000Z");

    expect(createBulkValidationReport([first, second], "2026-01-01T00:00:00.000Z")).toMatchObject({
      generatedAt: "2026-01-01T00:00:00.000Z",
      summary: { total: 2, pass: 1, warning: 0, fail: 1, info: 0 },
      creatives: [first, second],
    });
  });

  it("only treats failures as blocking", () => {
    expect(isBlockingStatus("fail")).toBe(true);
    expect(isBlockingStatus("warning")).toBe(false);
    expect(isBlockingStatus("info")).toBe(false);
  });
});
