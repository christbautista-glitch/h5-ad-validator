import type { ValidationResult } from "../types";
import type { RuntimeRule } from "../runtime/types";
import type { ValidationRuleProfile } from "../profiles/types";

export const animationDurationRule: RuntimeRule = { id: "ANIM001", name: "Animation Duration", category: "performance", async run(context, ruleProfile) {
  const duration = context.animationDurationMs;
  if (duration === undefined) return { ...result("ANIM001", "Animation Duration", "performance", "info", "Animation duration was not measured.", undefined, { measured: false }), actual: "Not measured" };
  if (duration < 0) return { ...result("ANIM001", "Animation Duration", "performance", violationStatus(ruleProfile, "warning"), "Animation did not stabilize before the runtime timeout.", undefined, { animationDurationMs: duration, measured: true }), actual: "Timeout" };
  return { ...result("ANIM001", "Animation Duration", "performance", "pass", `Animation stabilized after ${duration} ms.`, undefined, { animationDurationMs: duration, measured: true }), actual: `${duration} ms` };
} };

export const notFoundRule: RuntimeRule = { id: "NET001", name: "404 File Error", category: "network", async run(context, ruleProfile) {
  const failed = context.responses.filter((response) => response.status === 404);
  return result("NET001", "404 File Error", "network", failed.length ? violationStatus(ruleProfile) : "pass", failed.length ? `${failed.length} resource(s) returned 404.` : "No 404 responses detected.", failed.map((item) => item.url));
} };

export const consoleErrorsRule: RuntimeRule = { id: "JS001", name: "Console Errors", category: "javascript", async run(context, ruleProfile) {
  const errors = [...context.consoleErrors, ...context.pageErrors];
  const warnings = context.consoleWarnings ?? [];
  const diagnostics = [...errors, ...warnings.map((warning) => `Warning: ${warning}`)];
  return result("JS001", "Console Errors", "javascript", errors.length ? violationStatus(ruleProfile) : warnings.length ? "warning" : "pass", errors.length ? `${errors.length} runtime error(s) detected.` : warnings.length ? `${warnings.length} runtime warning(s) detected.` : "No console or page errors detected.", diagnostics, { errors, warnings, dialogs: context.dialogs ?? [], requestFailures: context.requestFailures });
} };

export const adBlockRule: RuntimeRule = { id: "ADBLOCK001", name: "Blocked by AdBlock", category: "network", async run(context, ruleProfile) {
  if (context.adBlockAffected === undefined) return { ...result("ADBLOCK001", "Blocked by AdBlock", "network", "info", "AdBlock impact could not be determined in this browser run.", undefined, { measured: false }), actual: "Not measured" };
  return { ...result("ADBLOCK001", "Blocked by AdBlock", "network", context.adBlockAffected ? violationStatus(ruleProfile) : "pass", context.adBlockAffected ? "A request reported an AdBlock-style blocking signal." : "No AdBlock-style blocking signal was detected.", undefined, { adBlockAffected: context.adBlockAffected, measured: true }), actual: context.adBlockAffected };
} };

export const consoleWarningsRule: RuntimeRule = { id: "JS002", name: "Console Warnings", category: "javascript", async run(context, ruleProfile) {
  const count = (context.consoleWarnings ?? []).length;
  return { ...result("JS002", "Console Warnings", "javascript", count ? violationStatus(ruleProfile, "warning") : "pass", count ? `${count} console warning(s) detected.` : "No console warnings detected.", context.consoleWarnings, { count }), actual: count };
} };

export const cpuUsageRule: RuntimeRule = { id: "PERF002", name: "CPU Usage", category: "performance", async run(context) {
  if (context.cpuTimeMs === undefined) return result("PERF002", "CPU Usage", "performance", "info", "CPU usage was not measurable.", undefined, { measured: false });
  return { ...result("PERF002", "CPU Usage", "performance", "pass", `${context.cpuTimeMs} ms of main-thread long-task time measured.`, undefined, { cpuTimeMs: context.cpuTimeMs, measured: true }), actual: `${context.cpuTimeMs} ms` };
} };

export const memoryUsageRule: RuntimeRule = { id: "PERF003", name: "Memory Usage", category: "performance", async run(context) {
  if (context.memoryUsageMb === undefined) return result("PERF003", "Memory Usage", "performance", "info", "Memory usage was not exposed by this browser.", undefined, { measured: false });
  return { ...result("PERF003", "Memory Usage", "performance", "pass", `${context.memoryUsageMb} MB JavaScript heap used.`, undefined, { memoryUsageMb: context.memoryUsageMb, measured: true }), actual: `${context.memoryUsageMb} MB` };
} };

export const networkRequestsRule: RuntimeRule = { id: "NET003", name: "Network Requests", category: "network", async run(context) {
  return { ...result("NET003", "Network Requests", "network", "pass", `${context.requests.length} network request(s) made during runtime.`, undefined, { count: context.requests.length }), actual: context.requests.length };
} };

export const runtimeMeasurementPixelsRule: RuntimeRule = { id: "TRACK001", name: "Measurement Pixels", category: "network", async run(context) {
  const count = context.measurementPixels ?? 0;
  return { ...result("TRACK001", "Measurement Pixels", "network", "pass", `${count} measurement pixel(s) detected at runtime.`, undefined, { count }), actual: count };
} };

export const visualStartRule: RuntimeRule = { id: "RENDER002", name: "Time to Visual Start", category: "visual", async run(context) {
  if (context.timeToVisualStartMs === undefined) return result("RENDER002", "Time to Visual Start", "visual", "info", "Time to visual start was not measurable.", undefined, { measured: false });
  return { ...result("RENDER002", "Time to Visual Start", "visual", "pass", `The first browser paint occurred after ${context.timeToVisualStartMs} ms.`, undefined, { timeToVisualStartMs: context.timeToVisualStartMs, measured: true }), actual: `${context.timeToVisualStartMs} ms` };
} };

export const visualPaintRule: RuntimeRule = { id: "VIS002", name: "Visual Start", category: "visual", async run(context) {
  const visualStartMs = context.visual?.visualStartMs;
  return result("VIS002", "Visual Start", "visual", visualStartMs === undefined ? "info" : "pass", visualStartMs === undefined ? "Visual start was not measurable." : `Visual content started rendering after ${Math.round(visualStartMs)} ms.`, undefined, { visualStartMs, measured: visualStartMs !== undefined });
} };

export const creativeBorderRule: RuntimeRule = { id: "VIS001", name: "Creative Border", category: "visual", async run(context, ruleProfile) {
  const border = context.visual?.creativeBorder;
  if (!border) {
    return result("VIS001", "Creative Border", "visual", "info", "Creative border detection was not available.");
  }
  return result(
    "VIS001",
    "Creative Border",
    "visual",
    border.detected ? "pass" : violationStatus(ruleProfile, "warning"),
    border.detected ? "A visible creative border was detected." : "No visible CSS border was detected on common creative containers.",
    undefined,
    border,
  );
} };

export const imagesLoadRule: RuntimeRule = { id: "ASSET002", name: "Images Load Correctly", category: "asset", async run(context, ruleProfile) {
  const failed = context.images.filter((image) => !image.complete || image.naturalWidth === 0);
  return result("ASSET002", "Images Load Correctly", "asset", failed.length ? violationStatus(ruleProfile) : "pass", failed.length ? `${failed.length} image(s) failed to load.` : "All detected images loaded correctly.", failed.map((image) => image.url));
} };
export const videoPlaybackRule: RuntimeRule = { id: "MEDIA002", name: "Video Playback", category: "asset", async run(context, ruleProfile) {
  const videos = context.videos ?? [];
  if (!videos.length) return result("MEDIA002", "Video Playback", "asset", "info", "No video elements were detected at runtime.", undefined, { videos: [] });
  const failures = videos.filter((video) => Boolean(video.error) || video.readyState < 2);
  const notPlaying = videos.filter((video) => video.paused && video.autoplay);
  const failed = [...failures, ...notPlaying];
  return result("MEDIA002", "Video Playback", "asset", failed.length ? violationStatus(ruleProfile, "warning") : "pass", failed.length ? `${failed.length} video element(s) did not load or play successfully.` : `${videos.length} video element(s) loaded successfully.`, undefined, { videos, failures, autoplayNotPlaying: notPlaying });
} };

export const initialLoadSizeRule: RuntimeRule = sizeRule("SIZE002", "Initial Load Size", "initialLoadBytes");
export const subloadSizeRule: RuntimeRule = sizeRule("SIZE003", "Subload Size", "subloadBytes");
export const totalLoadSizeRule: RuntimeRule = sizeRule("SIZE004", "Total Load Size", "totalLoadBytes");
export const runtimeDurationRule: RuntimeRule = { id: "PERF001", name: "Runtime Duration", category: "performance", async run(context, ruleProfile) {
  const maxDurationMs = ruleProfile?.thresholds?.maxDurationMs;
  if (maxDurationMs === undefined) throw new Error("PERF001 requires thresholds.maxDurationMs in the active validation profile.");
  const thresholdConfigured = maxDurationMs < Number.MAX_SAFE_INTEGER;
  const exceedsLimit = thresholdConfigured && context.durationMs > maxDurationMs;
  return result(
    "PERF001",
    "Runtime Duration",
    "performance",
    exceedsLimit ? violationStatus(ruleProfile, "warning") : "pass",
    exceedsLimit
      ? `Runtime analysis took ${context.durationMs} ms, exceeding the configured ${maxDurationMs} ms limit.`
      : thresholdConfigured
        ? `Runtime analysis completed in ${context.durationMs} ms.`
        : `Runtime analysis completed in ${context.durationMs} ms. No runtime duration threshold is configured for this profile.`,
    undefined,
    { durationMs: context.durationMs, maxDurationMs: thresholdConfigured ? maxDurationMs : undefined },
  );
} };
export const landingPageRule: RuntimeRule = { id: "CLICK002", name: "Validate Landing Page", category: "click", async run(context, ruleProfile) {
  const destinations = [...new Set([...context.navigationAttempts, ...context.popupAttempts])];
  const destinationStatuses = destinations.map((destination) => {
    const response = context.navigationResponses?.find((item) => item.isFinal && (item.url === destination || item.url.startsWith(`${destination}/`)))
      ?? context.responses.find((item) => item.url === destination || item.url.startsWith(`${destination}/`));
    return { url: destination, status: response?.status };
  });
  const working = destinations.length > 0 && destinationStatuses.every((destination) => destination.status !== undefined && destination.status >= 200 && destination.status < 400);
  const message = working
    ? `Click interaction reached ${destinations.length} working destination(s).`
    : destinations.length
      ? "A landing page destination was observed, but its response could not be confirmed as successful."
    : context.clickTargetFound
      ? "A clickable target was found and activated, but no landing page destination was observed."
      : "No supported clickable target was found for landing page validation.";
  return result("CLICK002", "Validate Landing Page", "click", working ? "pass" : violationStatus(ruleProfile, "warning"), message, destinations, { destinations, destinationStatuses, clickTargetFound: context.clickTargetFound, clickTarget: context.clickTarget });
} };

function formatKilobytes(bytes: number): string { return `${(bytes / 1024).toFixed(1)} KB`; }
function sizeRule(id: string, title: string, detail: "initialLoadBytes" | "subloadBytes" | "totalLoadBytes"): RuntimeRule { return { id, name: title, category: "performance", async run(context, ruleProfile) { const bytes = context[detail]; const maxBytes = ruleProfile?.thresholds?.maxBytes; if (maxBytes === undefined) throw new Error(`${id} requires thresholds.maxBytes in the active validation profile.`); const exceedsLimit = bytes !== undefined && bytes > maxBytes; return { ...result(id, title, "performance", bytes === undefined ? "info" : exceedsLimit ? violationStatus(ruleProfile) : "pass", bytes === undefined ? "Transferred byte size was not measurable." : exceedsLimit ? `${formatKilobytes(bytes)} transferred, exceeding the ${formatKilobytes(maxBytes)} limit.` : `${formatKilobytes(bytes)} transferred.`, undefined, { [detail]: bytes, maxBytes }), actual: bytes === undefined ? undefined : formatKilobytes(bytes), expected: formatKilobytes(maxBytes) }; } }; }
function violationStatus(ruleProfile?: ValidationRuleProfile, fallback: ValidationResult["status"] = "fail"): ValidationResult["status"] { return ruleProfile?.severity ?? fallback; }
function result(ruleId: string, title: string, category: RuntimeRule["category"], status: ValidationResult["status"], message: string, items?: string[], details?: Record<string, unknown>): ValidationResult { return { ruleId, title, category, status, message, files: items?.length ? items : undefined, details }; }
