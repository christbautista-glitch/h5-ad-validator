import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { validateCreative } from "../engine";
import { allowedFileTypesRule, documentWriteRule, minifiedAssetsRule } from "./checklist";

function context(files: Array<[string, string, string]>): CreativeContext {
  return {
    filename: "checklist.zip",
    compressedSize: 1,
    files: new Map(files.map(([path, extension, content]) => [path, { path, extension, content, size: content.length }])),
  };
}

describe("new checklist rules", () => {
  it("detects unsupported packaged file types", async () => {
    const result = await allowedFileTypesRule.run(context([["index.html", "html", ""], ["notes.exe", "exe", ""]]), { enabled: true });
    expect(result).toMatchObject({ ruleId: "ASSET005", status: "fail", actual: false, files: ["notes.exe"] });
  });

  it("detects unminified source and document.write", async () => {
    const creative = context([["index.html", "html", "<script>document.write('x')</script>"], ["main.js", "js", "function render() {\n  return true;\n}"]]);
    expect((await minifiedAssetsRule.run(creative, { enabled: true })).status).toBe("warning");
    expect((await documentWriteRule.run(creative, { enabled: true })).status).toBe("fail");
  });

  it("detects document.write usage and passes clean source", async () => {
    const withWrite = context([["index.html", "html", "<script>document.write('x')</script>"]]);
    const withoutWrite = context([["index.html", "html", "<main>Creative</main>"]]);

    expect(await documentWriteRule.run(withWrite, { enabled: true })).toMatchObject({ ruleId: "CODE003", status: "fail", actual: false, files: ["index.html"] });
    expect(await documentWriteRule.run(withoutWrite, { enabled: true })).toMatchObject({ ruleId: "CODE003", status: "pass", actual: true });
  });

  it("runs CODE003 by default", async () => {
    const results = await validateCreative(context([["index.html", "html", "<script>document.write('x')</script>"]]));
    expect(results.some((result) => result.ruleId === "CODE003")).toBe(true);
  });
});
