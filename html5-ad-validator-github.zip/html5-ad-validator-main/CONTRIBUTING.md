# Contributing Guide

## Start a task

```bash
cd /Users/christroibautista/Documents/GitHub/html5-creative-validator
git switch main
git pull --ff-only origin main
git switch -c feature/short-description
```

Use a separate branch for each task, such as `feature/dark-mode` or `fix/upload-preview`. Do not work directly on `main`.

## Verify your changes

Keep changes focused and preserve existing upload, preview, validation, API, and report behavior.

```bash
npm install
npm run lint
npx tsc --noEmit
npm test
```

Skip `npm install` when dependencies are already installed.

## Review and commit

```bash
git status
git diff
git add .
git diff --cached
git commit -m "feat: describe the change"
```

## Push your branch

```bash
git push -u origin feature/short-description
```

## Open a Pull Request

1. Open `https://github.com/croi-bautista/html5-creative-validator`.
2. Select **Pull requests** and choose **New pull request**, or click **Compare & pull request**.
3. Set the base branch to `main`.
4. Set the compare branch to your feature branch.
5. Add a title, summary, and verification results.
6. Submit the pull request for review.

Suggested commit messages:

```text
feat: redesign validation results
fix: preserve creative preview dimensions
```

Wait for review and required checks before merging.

## Confirm and finish the merge

On GitHub:

- **Merged** means the changes are now in `main`.
- **Open** means review or updates are still needed.
- **Closed** means it was closed without merging.

After the pull request shows **Merged**:

```bash
git switch main
git pull --ff-only origin main
git branch -d feature/short-description
```

The `-d` option refuses to delete unmerged work. Deleting the local branch does not delete the merged code, `main`, the repository, or the pull request on GitHub.

## Useful commands

```bash
git status
git branch --show-current
git branch
git branch -r
git log --oneline --decorate -10
```

## Collaboration rules

- Avoid committing directly to `main`.
- Keep commits focused and descriptive.
- Pull the latest `main` before starting new work.
- Coordinate before editing the same files as another developer.
- Avoid destructive commands such as `git reset --hard`.
