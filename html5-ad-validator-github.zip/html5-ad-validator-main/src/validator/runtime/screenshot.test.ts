import { describe, expect, it } from "vitest";
import { PNG } from "pngjs";
import { analyzeScreenshot } from "./runner";

function pngPixel(color: [number, number, number, number], x = 1, y = 1): Uint8Array {
  const image = new PNG({ width: 10, height: 10 });
  for (let index = 0; index < image.data.length; index += 4) {
    image.data[index] = color[0];
    image.data[index + 1] = color[1];
    image.data[index + 2] = color[2];
    image.data[index + 3] = color[3];
  }
  const pixel = (y * image.width + x) * 4;
  image.data[pixel] = 255;
  image.data[pixel + 1] = 0;
  image.data[pixel + 2] = 0;
  return PNG.sync.write(image);
}

describe("screenshot analysis", () => {
  it("detects visible pixels that differ from the background", () => {
    const result = analyzeScreenshot(pngPixel([255, 255, 255, 255], 5, 5));
    expect(result.nonBlankPixels).toBe(1);
    expect(result.edgeContrast).toBe(false);
  });

  it("detects visible contrast at the screenshot edge", () => {
    const result = analyzeScreenshot(pngPixel([255, 255, 255, 255], 0, 0));
    expect(result.nonBlankPixels).toBeGreaterThan(0);
    expect(result.edgeContrast).toBe(true);
  });

  it("fails safely for invalid screenshot data", () => {
    expect(analyzeScreenshot(new Uint8Array([1, 2, 3]))).toEqual({ nonBlankPixels: 0, edgeContrast: false });
  });
});
