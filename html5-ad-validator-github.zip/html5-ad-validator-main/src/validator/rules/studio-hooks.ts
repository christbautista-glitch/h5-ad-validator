import type { CreativeFile } from "../context";
import type { ValidationRule } from "../types";

interface HookCheck {
  name: string;
  file: string;
  present: boolean;
}

function findFile(files: Map<string, CreativeFile>, basename: string): CreativeFile | undefined {
  const target = basename.toLowerCase();

  return [...files.entries()].find(([path]) => path.split("/").pop()?.toLowerCase() === target)?.[1];
}

function contentOf(files: Map<string, CreativeFile>, basename: string): string {
  return findFile(files, basename)?.content ?? "";
}

export const studioHooksRule: ValidationRule = {
  id: "GWD002",
  name: "Studio / AdLib Policy",
  description: "Validates profile-specific Studio dynamic-content and AdLib hooks in their expected files.",
  category: "javascript",
  type: "static",
  async run(context, ruleProfile) {
    const requireStudioHooks = ruleProfile?.thresholds?.requireStudioHooks;
    const severity = ruleProfile?.severity ?? "fail";

    if (requireStudioHooks !== 0 && requireStudioHooks !== 1) {
      throw new Error("GWD002 requires thresholds.requireStudioHooks in the active validation profile.");
    }

    const invocation = contentOf(context.files, "invocation.js");
    const adlib = contentOf(context.files, "adlib.min.js");
    const runtime = contentOf(context.files, "runtime.js");
    const relevantSource = [invocation, adlib, runtime].join("\n");
    const checks: HookCheck[] = [
      { name: "devDynamicContent", file: "invocation.js", present: /\bdevDynamicContent\b/i.test(invocation) },
      { name: "AdLib.assignInvocationCode()", file: "invocation.js", present: /\bAdLib\s*\.\s*assignInvocationCode\s*\(/i.test(invocation) },
      { name: "localTimeline", file: "adlib.min.js", present: /\blocalTimeline\b/i.test(adlib) },
      { name: "localTesting", file: "adlib.min.js", present: /\blocalTesting\b/i.test(adlib) },
    ];
    const traceDetected = /\btrace\b/i.test(relevantSource);
    const runtimeDevDynamicContent = /\bdevDynamicContent\b/i.test(runtime);

    if (requireStudioHooks === 1) {
      const missing = checks.filter((check) => !check.present);
      const passed = missing.length === 0;

      return {
        ruleId: "GWD002",
        title: "Studio / AdLib Policy",
        category: "javascript",
        status: passed ? "pass" : severity,
        actual: `${checks.length - missing.length}/${checks.length} required hooks found`,
        expected: "Required Studio and AdLib hooks in their expected files",
        message: passed
          ? "Studio dynamic-content setup is present in invocation.js, and localTimeline/localTesting are present in adlib.min.js."
          : `Missing required hook(s): ${missing.map((check) => `${check.name} in ${check.file}`).join(", ")}.`,
        files: ["invocation.js", "adlib.min.js"],
        details: { checks, traceDetected },
        recommendation: passed ? undefined : "Add the missing Studio or AdLib hook to the expected file.",
      };
    }

    const prohibited = checks.filter((check) => check.present);
    const failed = prohibited.length > 0 || traceDetected;
    const runtimeOnlyReference = !failed && runtimeDevDynamicContent;

    return {
      ruleId: "GWD002",
      title: "Studio / AdLib Policy",
      category: "javascript",
      status: failed ? severity : "pass",
      actual: failed
        ? `${prohibited.length} prohibited hook(s); trace ${traceDetected ? "found" : "not found"}`
        : runtimeOnlyReference
          ? "Internal devDynamicContent reference in runtime.js; no trace found"
          : "No prohibited hooks or trace found",
      expected: "No Studio/AdLib hooks and no trace",
      message: failed
        ? [
            prohibited.length ? `Prohibited hook(s) found: ${prohibited.map((check) => `${check.name} in ${check.file}`).join(", ")}.` : "",
            traceDetected ? "Trace was found in the checked Studio/AdLib files." : "",
          ].filter(Boolean).join(" ")
        : runtimeOnlyReference
          ? "devDynamicContent is not in invocation.js, but runtime.js contains an internal devDynamicContent reference. No trace was found."
          : "devDynamicContent and assignInvocationCode are not present in invocation.js; localTimeline and localTesting are not present in adlib.min.js. No trace was found.",
      files: ["invocation.js", "adlib.min.js", "runtime.js"],
      details: { checks, runtimeDevDynamicContent, traceDetected },
      recommendation: failed ? "Remove the prohibited Studio/AdLib hooks and trace code for the GDN profile." : undefined,
    };
  },
};
