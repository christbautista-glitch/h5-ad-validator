import { existsSync } from "node:fs";
import chromium from "@sparticuz/chromium";

export interface PlaywrightPage {
  on(event: string, listener: (...args: never[]) => void): void;
  goto(url: string, options: { waitUntil: string; timeout: number }): Promise<unknown>;
  evaluate<T>(fn: () => T): Promise<T>;
  waitForTimeout(timeout: number): Promise<void>;
  screenshot(options?: { type?: string }): Promise<Uint8Array>;
  setContent(html: string, options?: { waitUntil?: "load" | "domcontentloaded" | "networkidle"; timeout?: number }): Promise<void>;
  emulateMedia(options: { media: "screen" | "print" | null }): Promise<void>;
  pdf(options?: Record<string, unknown>): Promise<Uint8Array>;
  close(): Promise<void>;
  route(pattern: string, handler: (route: PlaywrightRoute) => Promise<void>): Promise<void>;
}

interface PlaywrightRoute {
  request(): { url: () => string };
  continue(): Promise<void>;
  abort(errorCode?: string): Promise<void>;
}

export interface PlaywrightBrowser {
  newPage(options?: { viewport?: { width: number; height: number } }): Promise<PlaywrightPage>;
  close(): Promise<void>;
}

type PlaywrightModule = {
  chromium: {
    launch(options: { args?: string[]; executablePath: string; headless: boolean }): Promise<PlaywrightBrowser>;
  };
};

function loadPlaywright(): Promise<PlaywrightModule> {
  return import("playwright-core") as unknown as Promise<PlaywrightModule>;
}

function isServerlessRuntime(): boolean {
  return Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
}

function localChromiumExecutablePath(): string | undefined {
  const override = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH;
  if (override && existsSync(override)) return override;

  const candidates = process.platform === "darwin"
    ? [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
      ]
    : process.platform === "win32"
      ? [
          "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
          "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
          "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
          "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
        ]
      : [
          "/usr/bin/google-chrome",
          "/usr/bin/google-chrome-stable",
          "/usr/bin/chromium",
          "/usr/bin/chromium-browser",
          "/usr/bin/microsoft-edge",
        ];

  return candidates.find((candidate) => existsSync(candidate));
}

export async function launchChromium(): Promise<PlaywrightBrowser> {
  const { chromium: playwrightChromium } = await loadPlaywright();

  if (!isServerlessRuntime()) {
    const executablePath = localChromiumExecutablePath();
    if (executablePath) return playwrightChromium.launch({ executablePath, headless: true });
    if (process.platform !== "linux") {
      throw new Error("Local browser rendering requires Google Chrome, Microsoft Edge, or Chromium. Install one, or set PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH.");
    }
  }

  return playwrightChromium.launch({
    args: chromium.args,
    executablePath: await chromium.executablePath(),
    headless: true,
  });
}
