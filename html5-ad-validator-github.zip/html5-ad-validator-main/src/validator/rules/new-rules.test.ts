import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { animationPolicyRule } from "./animation-policy";
import { hostedSizeRule } from "./hosted-size";
import { enablerRule } from "./enabler";

function context(files: Array<[string, string]>): CreativeContext {
  return { filename: "creative.zip", compressedSize: 1, files: new Map(files.map(([path, content]) => [path, { path, content, size: content.length, extension: path.split(".").pop() ?? "" }])) };
}

describe("new validation rules", () => {
  it("reports hosted package size and file count", async () => {
    const result = await hostedSizeRule.run(context([["index.html", "1234"], ["banner.js", "12"]]), { enabled: true, thresholds: { maxBytes: 5 } });
    expect(result.status).toBe("warning");
    expect(result.details).toMatchObject({ hostedBytes: 6, fileCount: 2, maxBytes: 5 });
  });

  it("detects infinite and excessive animation declarations", async () => {
    const result = await animationPolicyRule.run(context([["index.html", "<style>.ad { animation: pulse 20s infinite; animation-iteration-count: infinite; }</style>"]]), { enabled: true, severity: "warning", thresholds: { maxDurationMs: 10000 } });
    expect(result.status).toBe("warning");
    expect(result.details).toMatchObject({ infinite: ["index.html"] });
  });

  it("reports multiple library fingerprints", async () => {
    const result = await enablerRule.run(context([["index.html", "<script>gsap.to('.ad'); jQuery('.button');</script>"]]));
    expect(result.status).toBe("pass");
    expect(result.details).toEqual({ libraries: ["GreenSock (GSAP)", "jQuery"] });
  });
});
