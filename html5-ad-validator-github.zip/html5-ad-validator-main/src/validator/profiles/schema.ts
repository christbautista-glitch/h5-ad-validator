import { z } from "zod";

export const validationRuleProfileSchema = z.object({
  enabled: z.boolean(),
  severity: z.enum(["warning", "fail", "info"]).optional(),
  thresholds: z.record(z.string(), z.number().finite().nonnegative()).optional(),
});

export const validationProfileSchema = z.object({
  id: z.string().min(1),
  name: z.string().min(1),
  description: z.string().optional(),
  rules: z.record(z.string(), validationRuleProfileSchema),
});
