import type { ValidationReport, ValidationSummary } from "./report";
import { OPTIONAL_RULE_IDS, checklistLabel, checklistValue, statusLabel } from "./report-format";
import type { PdfBuildOptions, PdfReport } from "./pdf-report";
import type { ValidationResult, ValidationStatus } from "./types";

function escapeHtml(value: unknown): string {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function statusText(status: ValidationStatus): string {
  return status === "pass" ? "✓" : status === "warning" ? "!" : status === "fail" ? "×" : "i";
}

function overallStatus(summary: ValidationSummary): { label: string; status: ValidationStatus } {
  if (summary.fail > 0) return { label: `${summary.fail} test${summary.fail === 1 ? "" : "s"} failed`, status: "fail" };
  return { label: "Passed", status: "pass" };
}

function formatTimestamp(value: string | null | undefined): string {
  if (!value) return "Just now";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("en", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function checkRows(title: string, results: ValidationResult[]): string {
  if (!results.length) return "";
  return `<section class="checks"><h3>${escapeHtml(title)}</h3><div class="check-grid">${results.map((result) => {
    const value = checklistValue(result);
    return `<div class="check"><span class="status-icon ${result.status}">${statusText(result.status)}</span><span class="check-name">${escapeHtml(checklistLabel(result))}</span><strong class="check-value ${result.status}">${escapeHtml(value === "" ? statusLabel(result.status) : value)}</strong></div>`;
  }).join("")}</div></section>`;
}

function summaryCard(label: string, value: number, total: number, status: ValidationStatus): string {
  const percentage = total ? Math.round((value / total) * 100) : 0;
  return `<div class="summary-card"><span class="summary-icon ${status}">${statusText(status)}</span><div><strong class="summary-count ${status}">${value}</strong><span class="summary-label">${label}</span><span class="summary-detail">${percentage}% of checks</span></div></div>`;
}

function creativePage(creative: ValidationReport, options: PdfBuildOptions, index: number, logoDataUrl?: string): string {
  const metadata = creative.filename
    ? options.creativeMetadataByFilename?.[creative.filename] ?? (index === 0 ? options.metadata : undefined)
    : index === 0 ? options.metadata : undefined;
  const filename = creative.filename ?? metadata?.filename ?? "Creative";
  const dimensions = metadata?.dimensions ?? "-";
  const status = overallStatus(creative.summary);
  const standard = creative.results.filter((result) => !OPTIONAL_RULE_IDS.has(result.ruleId));
  const optional = creative.results.filter((result) => OPTIONAL_RULE_IDS.has(result.ruleId));
  const metadataRows = [
    ["Name", filename], ["File Size", metadata?.fileSize ?? "-"],
    ["Timestamp", formatTimestamp(metadata?.validatedAt ?? creative.generatedAt)], ["Dimensions", dimensions],
    ["Scanned By", "Local validator"], ["Creative Type", "HTML5 Zip"],
    ["Result", status.label], ["Profile", creative.profile?.name ?? metadata?.profile ?? "-"],
  ];
  const brand = logoDataUrl
    ? `<div class="app-brand"><img class="app-logo" src="${escapeHtml(logoDataUrl)}" alt=""><span>HTML5 Ad Validator</span></div>`
    : `<div class="app-brand"><span>HTML5 Ad Validator</span></div>`;
  return `<article class="report-page">
    <header class="report-header">${brand}</header>
    <section class="metadata"><div class="metadata-grid">${metadataRows.map(([label, value], rowIndex) => `<div class="metadata-cell"><span>${escapeHtml(label)}</span><strong class="${rowIndex === 6 ? status.status : ""}">${escapeHtml(value)}</strong></div>`).join("")}</div></section>
    <section class="results"><div class="section-heading"><span class="eyebrow">Validation results</span><h2>Checklist summary</h2></div>
      <div class="summary-grid">${summaryCard("Passed", creative.summary.pass, creative.summary.total, "pass")}${summaryCard("Warning", creative.summary.warning, creative.summary.total, "warning")}${summaryCard("Errors", creative.summary.fail, creative.summary.total, "fail")}${summaryCard("Info", creative.summary.info, creative.summary.total, "info")}</div>
      ${checkRows("Checklist", standard)}${checkRows("Additional checks", optional)}
    </section>
  </article>`;
}

export function renderValidationReportHtml(report: PdfReport, options: PdfBuildOptions = {}, logoDataUrl?: string): string {
  const creatives = "creatives" in report ? report.creatives : [report];
  const title = options.title ?? "HTML5 Ad Validation Report";
  return `<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>
    @page { size: A4; margin: 10mm; }
    * { box-sizing: border-box; }
    html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    body { margin: 0; background: #f6f7fb; color: #17192a; font-family: Arial, Helvetica, sans-serif; font-size: 10px; }
    .report-page { background: #fff; border: 1px solid #e2e6ee; border-radius: 14px; overflow: hidden; page-break-after: always; break-after: page; }
    .report-page:last-child { page-break-after: auto; break-after: auto; }
    .report-header { height: 58px; display: flex; align-items: center; justify-content: center; border-bottom: 1px solid #aeb4c0; } .app-brand { display: flex; align-items: center; gap: 8px; color: #17192a; font-size: 14px; font-weight: 800; white-space: nowrap; } .app-logo { width: 30px; height: 30px; object-fit: contain; }
    .eyebrow { display: block; color: #8b5cf6; font-weight: 800; font-size: 8px; letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 4px; }
    h1, h2, h3 { margin: 0; } h2 { font-size: 14px; font-weight: 600; } h3 { color: #697386; font-size: 8px; letter-spacing: 1.4px; text-transform: uppercase; margin: 0 0 6px; }
    .metadata, .results { margin: 10px 18px; }
    .metadata-grid { display: grid; grid-template-columns: 1fr 1fr; column-gap: 34px; }
    .metadata-cell { min-height: 31px; padding: 6px 0; border-bottom: 1px solid #e2e6ee; display: grid; grid-template-columns: 78px 1fr; align-items: center; gap: 8px; } .metadata-cell span { color: #7b8394; } .metadata-cell strong { min-width: 0; font-size: 9px; overflow-wrap: anywhere; }
    .section-heading { padding: 5px 0 8px; }
    .summary-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 7px; padding: 0 0 12px; }
    .summary-card { min-height: 49px; padding: 7px 9px; border: 1px solid #e2e6ee; border-radius: 8px; display: flex; align-items: center; gap: 8px; }
    .summary-icon, .status-icon { display: inline-flex; align-items: center; justify-content: center; flex: none; font-weight: 800; } .summary-icon { width: 27px; height: 27px; border-radius: 7px; font-size: 12px; } .status-icon { width: 14px; height: 14px; border-radius: 50%; font-size: 8px; }
    .summary-count, .summary-label, .summary-detail { display: block; } .summary-count { font-size: 15px; line-height: 1; } .summary-label { font-weight: 700; font-size: 9px; margin-top: 2px; } .summary-detail { color: #7b8394; margin-top: 2px; font-size: 7px; }
    .checks { padding: 0 0 10px; } .check-grid { display: grid; grid-template-columns: repeat(3,1fr); column-gap: 20px; }
    .check { min-height: 23px; border-bottom: 1px solid #e2e6ee; display: flex; align-items: center; gap: 6px; } .check-name { flex: 1; font-size: 8px; } .check-value { max-width: 42%; overflow-wrap: anywhere; text-align: right; font-size: 8px; }
    .pass { color: #15803d; } .warning { color: #b45309; } .fail { color: #dc2626; } .info { color: #1d4ed8; }
    .summary-icon.pass,.status-icon.pass { background: #dcfce7; } .summary-icon.warning,.status-icon.warning { background: #fef3c7; } .summary-icon.fail,.status-icon.fail { background: #fee2e2; } .summary-icon.info,.status-icon.info { background: #dbeafe; }
  </style></head><body>${creatives.map((creative, index) => creativePage(creative, options, index, logoDataUrl)).join("")}</body></html>`;
}
