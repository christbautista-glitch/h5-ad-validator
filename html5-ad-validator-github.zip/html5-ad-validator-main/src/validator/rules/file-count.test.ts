import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { validateCreative } from "../engine";
import { fileCountRule } from "./file-count";

function context(paths: string[]): CreativeContext {
  return {
    filename: "test.zip",
    compressedSize: 1,
    files: new Map(paths.map((path) => [path, {
      path,
      size: 1,
      extension: path.split(".").pop() ?? "",
      content: "",
    }])),
  };
}

describe("file count rule", () => {
  it("passes when file count is within the profile threshold", async () => {
    const result = await fileCountRule.run(context(["index.html", "main.js"]), {
      enabled: true,
      severity: "warning",
      thresholds: { maxFiles: 2 },
    });

    expect(result).toMatchObject({
      ruleId: "FILE001",
      status: "pass",
      actual: 2,
      expected: "<= 2",
    });
  });

  it("uses profile severity when file count exceeds the threshold", async () => {
    const result = await fileCountRule.run(context(["index.html", "main.js", "style.css"]), {
      enabled: true,
      severity: "warning",
      thresholds: { maxFiles: 2 },
    });

    expect(result.status).toBe("warning");
    expect(result.actual).toBe(3);
  });

  it("can be disabled by profile", async () => {
    const results = await validateCreative(context(["index.html"]), {
      id: "no-file-count",
      name: "No File Count",
      rules: {
        PKG001: { enabled: false },
        FILE001: { enabled: false },
        SIZE001: { enabled: false },
        HTML001: { enabled: false },
        HTML002: { enabled: false },
        HTML003: { enabled: false },
        MEDIA001: { enabled: false },
        MEDIA002: { enabled: false },
        ASSET003: { enabled: false },
        NET002: { enabled: false },
        ASSET004: { enabled: false },
        SEC001: { enabled: false },
        CLICK001: { enabled: false },
        GWD001: { enabled: false },
        GWD002: { enabled: false },
        RENDER001: { enabled: false },
        CODE001: { enabled: false },
        SIZE005: { enabled: false },
        ANIM002: { enabled: false },
        ANIM001: { enabled: false },
        ASSET005: { enabled: false },
        CODE002: { enabled: false },
        CODE003: { enabled: false },
      },
    });

    expect(results).toEqual([]);
  });
});
