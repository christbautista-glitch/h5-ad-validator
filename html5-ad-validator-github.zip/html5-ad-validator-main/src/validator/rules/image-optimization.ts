import type { CreativeFile } from "../context";
import type { ValidationRule } from "../types";

const IMAGE_EXTENSIONS = new Set(["gif", "jpeg", "jpg", "png", "svg", "webp"]);
const UNENFORCED_THRESHOLD = Number.MAX_SAFE_INTEGER;

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

function isImage(file: CreativeFile): boolean {
  return IMAGE_EXTENSIONS.has(file.extension.toLowerCase());
}

export const imageOptimizationRule: ValidationRule = {
  id: "ASSET003",
  name: "Images Optimized",
  description: "Checks packaged image files against the active profile image size threshold.",
  category: "asset",
  type: "static",

  async run(context, ruleProfile) {
    const maxImageBytes = ruleProfile?.thresholds?.maxImageBytes;

    if (maxImageBytes === undefined) {
      throw new Error("ASSET003 requires thresholds.maxImageBytes in the active validation profile.");
    }

    const images = Array.from(context.files.values()).filter(isImage);
    const thresholdConfigured = maxImageBytes < UNENFORCED_THRESHOLD;
    const oversizedImages = thresholdConfigured ? images.filter((file) => file.size > maxImageBytes) : [];
    const largestImage = images.reduce<CreativeFile | null>(
      (largest, file) => (!largest || file.size > largest.size ? file : largest),
      null,
    );

    return {
      ruleId: "ASSET003",
      title: "Images Optimized",
      category: "asset",
      status: oversizedImages.length ? ruleProfile?.severity ?? "warning" : "pass",
      actual: largestImage ? formatBytes(largestImage.size) : "No images",
      expected: thresholdConfigured ? `Each image <= ${formatBytes(maxImageBytes)}` : "No configured image size limit",
      files: oversizedImages.length ? oversizedImages.map((file) => file.path) : undefined,
      message: oversizedImages.length
        ? `${oversizedImages.length} image file(s) exceed the configured image size threshold.`
        : images.length
          ? thresholdConfigured
            ? `${images.length} packaged image file(s) are within the configured image size threshold.`
            : `${images.length} packaged image file(s) detected. No image size threshold is configured for this profile.`
          : "No packaged image files detected.",
      recommendation: oversizedImages.length
        ? "Compress or resize oversized image assets before packaging the creative."
        : undefined,
    };
  },
};
