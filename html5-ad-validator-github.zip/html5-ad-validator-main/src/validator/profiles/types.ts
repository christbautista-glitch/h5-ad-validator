import type { ValidationStatus } from "../types";

export type RuleId =
  | "ANIM001"
  | "ANIM002"
  | "PKG001"
  | "FILE001"
  | "SIZE001"
  | "HTML001"
  | "HTML002"
  | "HTML003"
  | "MEDIA001"
  | "MEDIA002"
  | "NET002"
  | "ASSET003"
  | "ASSET004"
  | "SEC001"
  | "CLICK001"
  | "GWD001"
  | "GWD002"
  | "NET001"
  | "JS001"
  | "RENDER001"
  | "VIS002"
  | "VIS001"
  | "ASSET002"
  | "SIZE002"
  | "SIZE003"
  | "SIZE004"
  | "SIZE005"
  | "PERF001"
  | "CLICK002"
  | "CODE001"
  | "ADBLOCK001"
  | "PERF002"
  | "CODE002"
  | "JS002"
  | "ASSET005"
  | "TRACK001"
  | "PERF003"
  | "NET003"
  | "RENDER002"
  | "CODE003";

export interface ValidationRuleProfile {
  enabled: boolean;
  severity?: Exclude<ValidationStatus, "pass">;
  thresholds?: Record<string, number>;
}

export interface ValidationProfile {
  id: string;
  name: string;
  description?: string;
  rules: Partial<Record<RuleId, ValidationRuleProfile>>;
}

export interface ValidationProfileMetadata {
  id: string;
  name: string;
  description?: string;
}
