import type { ValidationRule } from "../types";

const VIDEO_EXTENSIONS = [
  "mp4",
  "webm",
  "mov",
  "m4v",
  "ogv",
];

export const videoRule: ValidationRule = {
  id: "MEDIA002",

  name: "Video",

  description:
    "Checks whether the creative package contains video.",

  category: "media",

  type: "static",

  async run(context) {
    const videoFiles = Array.from(
      context.files.values()
    ).filter((file) =>
      VIDEO_EXTENSIONS.includes(file.extension)
    );

    const htmlHasVideo =
      context.indexHtml
        ?.toLowerCase()
        .includes("<video") ?? false;

    const detected =
      videoFiles.length > 0 || htmlHasVideo;

    return {
      ruleId: "MEDIA002",
      title: "Video",
      category: "media",
      status: "pass",

      actual: detected,

      message: detected
        ? `Video detected${
            videoFiles.length
              ? ` (${videoFiles.length} file(s)).`
              : "."
          }`
        : "No video detected.",

      files:
        videoFiles.length > 0
          ? videoFiles.map((file) => file.path)
          : undefined,
    };
  },
};