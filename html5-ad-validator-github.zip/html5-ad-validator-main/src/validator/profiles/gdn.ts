import { commonRuleProfiles } from "./shared";
import type { ValidationProfile } from "./types";

const KB = 1024;
export const GDN_PROFILE_ID = "gdn";

export const gdnProfile: ValidationProfile = {
  id: GDN_PROFILE_ID,
  name: "GDN",
  description: "Combined CM360 / Studio and Google Ads / DV360 validation profile.",
  rules: {
    ...commonRuleProfiles,
    SIZE001: { enabled: true, severity: "fail", thresholds: { maxBytes: 600 * KB } },
    GWD001: { enabled: true, severity: "fail", thresholds: { requireEnabler: 0 } },
    GWD002: { enabled: true, thresholds: { requireStudioHooks: 0 } },
    CLICK001: { enabled: true, severity: "warning" },
  },
};
