import type { BulkValidationReport, ValidationReport } from "./report";

export type PdfReport = ValidationReport | BulkValidationReport;

export interface PdfCreativeMetadata {
  filename?: string | null;
  fileSize?: string | null;
  dimensions?: string | null;
  profile?: string | null;
  validatedAt?: string | null;
}

export interface PdfBuildOptions {
  title?: string;
  metadata?: PdfCreativeMetadata;
  creativeMetadataByFilename?: Record<string, PdfCreativeMetadata>;
}

export function sanitizeReportFilename(filename: string | null | undefined, extension = "pdf"): string {
  const base = (filename ?? "creative")
    .replace(/\.zip$/i, "")
    .replace(/[^a-z0-9._-]+/gi, "-")
    .replace(/^-+|-+$/g, "") || "creative";
  return `${base}-validation-report.${extension}`;
}

export async function createValidationPdf(report: PdfReport, options: PdfBuildOptions = {}): Promise<ArrayBuffer> {
  const response = await fetch("/api/reports/pdf", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ report, options }),
  });

  if (!response.ok) {
    const payload = await response.json().catch(() => null) as { error?: string } | null;
    throw new Error(payload?.error ?? `PDF generation failed (${response.status}).`);
  }

  return response.arrayBuffer();
}
