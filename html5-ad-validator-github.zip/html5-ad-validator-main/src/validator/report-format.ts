import type { ValidationResult, ValidationStatus } from "./types";

export const OPTIONAL_RULE_IDS = new Set(["ADBLOCK001", "PERF002", "CODE002", "JS002", "ASSET005", "TRACK001", "PERF003", "NET003", "RENDER002", "CODE003"]);

const CHECKLIST_LABELS: Record<string, string> = {
  ASSET002: "Images Load Correctly",
  ASSET003: "Images Optimized",
  ASSET004: "Missing Assets",
  ANIM001: "Animation Duration",
  ANIM002: "Animation Policy",
  CLICK001: "Click Through",
  CLICK002: "Landing Page Working",
  CODE001: "Code Syntax",
  FILE001: "Hosted File Count",
  GWD001: "HTML5 Library",
  GWD002: "Studio / AdLib Policy",
  HTML001: "Dimensions",
  HTML002: "Meta tag ad.size",
  JS001: "Console Errors",
  MEDIA001: "Has Audio",
  MEDIA002: "Has Video",
  NET001: "404 File Error",
  NET002: "External Assets",
  PERF001: "Runtime Duration",
  PKG001: "Index File Check",
  RENDER001: "Creative Elements Displayed",
  SEC001: "SSL-Compatibility",
  SIZE001: "Compressed File Size",
  SIZE002: "Load Size: Initial",
  SIZE003: "Load Size: Subload",
  SIZE004: "Load Size: Total",
  SIZE005: "Hosted File Size",
  VIS001: "Creative Border",
  VIS002: "Visual Start",
};

export function checklistLabel(result: ValidationResult): string {
  return CHECKLIST_LABELS[result.ruleId] ?? result.title;
}

export function statusLabel(status: ValidationStatus): string {
  return status === "pass" ? "Passed" : status === "warning" ? "Warning" : status === "fail" ? "Error" : "Info";
}

export function checklistValue(result: ValidationResult): string | number | boolean {
  if (typeof result.actual === "boolean") {
    return result.actual ? "Yes" : "No";
  }

  if (result.actual !== undefined) {
    return result.actual;
  }

  if (result.files?.length) {
    return result.files.length;
  }

  return statusLabel(result.status);
}
