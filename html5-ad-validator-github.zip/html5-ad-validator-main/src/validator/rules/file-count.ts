import type { ValidationRule } from "../types";

export const fileCountRule: ValidationRule = {
  id: "FILE001",
  name: "File Count",
  description: "Checks how many package files are present in the creative ZIP.",
  category: "package",
  type: "static",

  async run(context, ruleProfile) {
    const maxFiles = ruleProfile?.thresholds?.maxFiles;

    if (maxFiles === undefined) {
      throw new Error("FILE001 requires thresholds.maxFiles in the active validation profile.");
    }

    const fileCount = context.files.size;
    const passed = fileCount <= maxFiles;

    return {
      ruleId: "FILE001",
      title: "File Count",
      category: "package",
      status: passed ? "pass" : ruleProfile?.severity ?? "warning",
      actual: fileCount,
      expected: `<= ${maxFiles}`,
      message: passed
        ? `${fileCount} package file(s) detected.`
        : `${fileCount} package file(s) detected, exceeding the configured ${maxFiles} file limit.`,
      recommendation: passed ? undefined : "Remove unused files from the ZIP package.",
    };
  },
};
