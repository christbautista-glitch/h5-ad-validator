import type {
  ValidationResult,
  ValidationRule,
} from "./types";

import type {
  CreativeContext,
} from "./context";
import type { ValidationProfile } from "./profiles/types";
import { getDefaultValidationProfile } from "./profiles/registry";
import { applySeverityOverride, resolveRuleProfile } from "./profiles/resolve-profile";

import {
  indexFileRule,
} from "./rules/index-file";
import { fileCountRule } from "./rules/file-count";

import {
  compressedSizeRule,
} from "./rules/compressed-size";

import {
  dimensionsRule,
} from "./rules/dimensions";

import {
  adSizeRule,
} from "./rules/ad-size";

import {
  audioRule,
} from "./rules/audio";

import {
  videoRule,
} from "./rules/video";
import { imageOptimizationRule } from "./rules/image-optimization";
import { externalAssetsRule, missingAssetsRule, sslCompatibilityRule } from "./rules/resources";
import { exitCodeRule } from "./rules/exit-code";
import { enablerRule } from "./rules/enabler";
import { codeSyntaxRule } from "./rules/code-syntax";
import { hostedSizeRule } from "./rules/hosted-size";
import { animationPolicyRule } from "./rules/animation-policy";
import { renderedRule } from "./rules/rendered";
import { studioHooksRule } from "./rules/studio-hooks";
import { allowedFileTypesRule, documentWriteRule, minifiedAssetsRule } from "./rules/checklist";

const rules: ValidationRule[] = [
  indexFileRule,
  fileCountRule,
  compressedSizeRule,
  dimensionsRule,
  adSizeRule,
  audioRule,
  videoRule,
  imageOptimizationRule,
  externalAssetsRule,
  missingAssetsRule,
  sslCompatibilityRule,
  exitCodeRule,
  enablerRule,
  studioHooksRule,
  codeSyntaxRule,
  hostedSizeRule,
  animationPolicyRule,
  renderedRule,
  allowedFileTypesRule,
  minifiedAssetsRule,
  documentWriteRule,
];

export async function validateCreative(
  context: CreativeContext,
  profile: ValidationProfile = getDefaultValidationProfile()
): Promise<ValidationResult[]> {
  const results: ValidationResult[] = [];

  for (const rule of rules) {
    const ruleProfile = resolveRuleProfile(profile, rule.id);

    if (!ruleProfile.enabled) {
      continue;
    }

    try {
      const result = applySeverityOverride(await rule.run(context, ruleProfile), ruleProfile);

      results.push(result);
    } catch (error) {
      results.push({
        ruleId: rule.id,
        title: rule.name,
        category: rule.category,
        status: "fail",

        message:
          error instanceof Error
            ? error.message
            : "Unknown validation error",
      });
    }
  }

  return results;
}
