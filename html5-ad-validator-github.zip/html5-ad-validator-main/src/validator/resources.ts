import type { CreativeContext, CreativeFile, CreativeResource, ResourceType } from "./context";

const ATTRIBUTES: Array<[string, ResourceType, string]> = [
  ["script", "script", "src"], ["img", "image", "src"], ["source", "other", "src"],
  ["video", "video", "src"], ["audio", "audio", "src"], ["iframe", "iframe", "src"],
  ["link", "stylesheet", "href"],
];

function clean(value: string) { return value.trim().replace(/^['"]|['"]$/g, ""); }
function classify(raw: string): { location: CreativeResource["location"], protocol: CreativeResource["protocol"] } {
  const value = raw.trim().toLowerCase();
  if (value.startsWith("data:")) return { location: "data", protocol: "data" };
  if (/^(?:https?:)?\/\//.test(value)) return { location: "external", protocol: value.startsWith("//") ? "protocol-relative" : value.startsWith("https:") ? "https" : "http" };
  if (/^(?:#|mailto:|javascript:|blob:)/.test(value)) return { location: "data", protocol: "local" };
  return { location: "local", protocol: "local" };
}
function resolvePath(raw: string, source: string): string | undefined {
  if (classify(raw).location !== "local") return undefined;
  const parts = [...source.split("/").slice(0, -1), ...raw.split("/")];
  const output: string[] = [];
  for (const part of parts) { if (!part || part === ".") continue; if (part === "..") output.pop(); else output.push(part); }
  return output.join("/");
}
function add(resources: CreativeResource[], raw: string, sourceFile: string, type: ResourceType, commented = false) {
  const value = clean(raw); if (!value) return;
  const classification = classify(value);
  if (classification.location === "data") return;
  resources.push({ raw: value, resolved: resolvePath(value, sourceFile), sourceFile, type, commented, ...classification });
}

function stripComments(text: string, extension: string): string {
  if (extension === "css") {
    return text.replace(/\/\*[\s\S]*?\*\//g, "");
  }

  return text.replace(/<!--[\s\S]*?-->/g, "");
}

function parseText(text: string, sourceFile: string, extension: string, resources: CreativeResource[], commented = false) {
  const commentPattern = extension === "css" ? /\/\*[\s\S]*?\*\//g : /<!--[\s\S]*?-->/g;
  for (const comment of text.matchAll(commentPattern)) {
    parseText(comment[0].replace(extension === "css" ? /^\/\*|\*\/$/g : /^<!--|-->$/g, ""), sourceFile, extension, resources, true);
  }
  text = stripComments(text, extension);

  if (extension === "css") {
    for (const match of text.matchAll(/(?:url\(\s*([^)]*)\s*\)|@import\s+(?:url\(\s*)?["']?([^\s"')]+)["']?)/gi)) add(resources, match[1] ?? match[2], sourceFile, "other", commented);
    return;
  }
  for (const [tag, type, attr] of ATTRIBUTES) for (const match of text.matchAll(new RegExp(`<${tag}\\b[^>]*\\b${attr}\\s*=\\s*["']([^"']+)["']`, "gi"))) add(resources, match[1], sourceFile, type, commented);
  for (const match of text.matchAll(/\bsrcset\s*=\s*["']([^"']+)["']/gi)) for (const item of match[1].split(",")) add(resources, item.trim().split(/\s+/)[0], sourceFile, "image", commented);
  for (const match of text.matchAll(/\bposter\s*=\s*["']([^"']+)["']/gi)) add(resources, match[1], sourceFile, "image", commented);
}

export function buildResourceGraph(context: CreativeContext): CreativeResource[] {
  const resources: CreativeResource[] = [];
  const visit = (file: CreativeFile) => { if (file.content !== undefined) parseText(file.content, file.path, file.extension, resources); };
  for (const file of context.files.values()) visit(file);
  return resources;
}

/** Returns the context's shared inventory, building it only once. */
export function getResourceGraph(context: CreativeContext): CreativeResource[] {
  if (!context.resources) {
    context.resources = buildResourceGraph(context);
  }

  return context.resources;
}
