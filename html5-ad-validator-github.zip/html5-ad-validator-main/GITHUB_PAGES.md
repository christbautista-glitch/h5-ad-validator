# GitHub Pages build

This branch is configured as a fully static Next.js export for GitHub Pages.

## What changed

- Validation runs in the browser using JSZip and the existing static validation engine.
- Server API routes and Playwright/Chromium runtime validation are excluded because GitHub Pages has no Node.js runtime.
- PDF generation is replaced by JSON report download. The original PDF implementation required a server-side Chromium process.
- Asset and share URLs honor the repository base path.
- `.github/workflows/deploy-pages.yml` builds and deploys `out/` automatically.

## Deploy

1. Push this project to a GitHub repository using the `main` branch.
2. In GitHub: Settings -> Pages -> Build and deployment -> Source, select **GitHub Actions**.
3. Push to `main` or run the **Deploy GitHub Pages** workflow manually.

For a user/organization site repository named `<owner>.github.io`, set `NEXT_PUBLIC_BASE_PATH` to an empty string in the workflow instead of `/${{ github.event.repository.name }}`.

## Feature difference from the server version

Static ZIP/content checks and previews work on GitHub Pages. Browser automation checks that require Playwright/Chromium are not run. Reports download as JSON instead of PDF.
