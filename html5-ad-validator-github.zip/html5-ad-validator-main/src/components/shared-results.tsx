"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

import type { BulkValidationReport, ValidationReport, ValidationSummary } from "@/validator/report";
import type { ValidationResult } from "@/validator/types";

type SharedReport = BulkValidationReport | ValidationReport;
const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

function isBulkReport(report: SharedReport): report is BulkValidationReport {
  return "creatives" in report;
}

export default function SharedResults() {
  const [report, setReport] = useState<SharedReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      try {
        const params = new URLSearchParams(window.location.hash.slice(1));
        const encodedReport = params.get("report");
        if (!encodedReport) {
          setError("No shared validation report was found in this link.");
          return;
        }
        setReport(JSON.parse(encodedReport) as SharedReport);
      } catch {
        setError("This shared validation report could not be opened.");
      }
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const reports = report ? isBulkReport(report) ? report.creatives : [report] : [];

  return (
    <div className={`${darkMode ? "app-shell dark" : "app-shell"} shared-results-shell`}>
      <div className="app-main">
        <header className="topbar">
          <Link className="mobile-brand app-brand" href="/" aria-label="HTML5 Ad Validator home">
            <img src={`${BASE_PATH}/branding/ad-validator-logo.png`} alt="" />
            <span>HTML5 Ad Validator</span>
          </Link>
          <nav className="top-links" aria-label="Section navigation">
            <Link href="/">Validate Ad</Link>
            <a className="current" href="#results">Shared Results</a>
          </nav>
          <div className="top-actions">
            <button type="button" className={`theme-switch ${darkMode ? "on" : ""}`} aria-label="Toggle dark mode" aria-pressed={darkMode} onClick={() => setDarkMode((value) => !value)}>
              <span className="theme-switch-icon"><ThemeIcon name={darkMode ? "sun" : "moon"} /></span>
              <span className="theme-switch-thumb" />
            </button>
          </div>
        </header>

        <main id="results" className="page-content shared-results-page">
          <section className="hero-panel shared-results-hero">
            <div className="hero-copy">
              <p className="eyebrow">Shared validation report</p>
              <h1>HTML5 Ad<br /><span>Results</span></h1>
              <p>{report ? `${reports.length} creative${reports.length === 1 ? "" : "s"} included in this shared report.` : "Open a shared validation report link."}</p>
            </div>
            <div className="hero-pattern" aria-hidden="true"><img src={`${BASE_PATH}/branding/smartly-pattern.png`} alt="" /></div>
          </section>

          {error && <div className="error-banner" role="alert">{error}</div>}

          {reports.map((creative, creativeIndex) => {
            const dimensions = getResultValue(creative.results, "HTML001") ?? getResultValue(creative.results, "HTML002") ?? "-";
            const failedCount = creative.summary.fail;
            const status = failedCount ? `${failedCount} tests failed` : "Passed";
            const tone = failedCount ? "fail" : "pass";
            const profileName = creative.profile?.name ?? report?.profile?.name ?? "Not specified";

            return (
              <details className="creative-accordion" key={`${creative.filename ?? "creative"}-${creativeIndex}`} open={creativeIndex === 0}>
                <summary className="creative-accordion__summary">
                  <span className="creative-accordion__title"><span className="eyebrow">Creative {reports.length > 1 ? creativeIndex + 1 : ""}</span>{creative.filename ?? "Creative"}</span>
                  <span className="creative-accordion__meta">{dimensions}</span>
                  <span className={`creative-accordion__status creative-accordion__status--${tone}`}>{status}</span>
                  <span className="creative-accordion__chevron" aria-hidden="true">⌄</span>
                </summary>

                <div className="creative-accordion__body">
                  <section className="results-card shared-metadata-card">
                    <div className="metadata-grid">
                      <MetadataRow label="Name" value={creative.filename ?? "Creative"} />
                      <MetadataRow label="Timestamp" value={formatTimestamp(creative.generatedAt)} />
                      <MetadataRow label="Dimensions" value={dimensions} />
                      <MetadataRow label="Scanned By" value="Local validator" />
                      <MetadataRow label="Creative Type" value="HTML5 Zip" />
                      <MetadataRow label="Result" value={status} tone={tone} />
                      <MetadataRow label="Profile" value={profileName} />
                      <MetadataRow label="Report" value="Shared validation result" />
                    </div>
                  </section>

                  <section className="results-card validation-results shared-validation-results">
                    <div className="section-heading"><div><p className="eyebrow">Validation results</p><h2>Checklist summary</h2></div><span className="pill">{creative.summary.total} checks</span></div>
                    <SummaryGrid summary={creative.summary} />
                    <div className="result-list">
                      {creative.results.map((result, resultIndex) => <SharedResultRow key={`${result.ruleId}-${resultIndex}`} result={result} />)}
                    </div>
                  </section>
                </div>
              </details>
            );
          })}
        </main>

        <footer className="app-footer">HTML5 Ad Validator <span>•</span> Shared creative validation results</footer>
      </div>
    </div>
  );
}

function SummaryGrid({ summary }: { summary: ValidationSummary }) {
  const percentage = (value: number) => summary.total ? Math.round((value / summary.total) * 100) : 0;
  return (
    <div className="summary-grid">
      <SummaryBox value={summary.pass} label="Passed" detail={`${percentage(summary.pass)}% of checks`} variant="pass" />
      <SummaryBox value={summary.warning} label="Warning" detail={`${percentage(summary.warning)}% of checks`} variant="warning" />
      <SummaryBox value={summary.fail} label="Errors" detail={`${percentage(summary.fail)}% of checks`} variant="fail" />
      <SummaryBox value={summary.info} label="Info" detail={`${percentage(summary.info)}% of checks`} variant="info" />
    </div>
  );
}

function SummaryBox({ value, label, detail, variant }: { value: number; label: string; detail: string; variant: ValidationResult["status"] }) {
  const styles = {
    pass: { text: "text-green-700", iconBackground: "bg-green-100", background: "bg-green-50", border: "border-green-100", icon: "✓" },
    warning: { text: "text-yellow-700", iconBackground: "bg-yellow-100", background: "bg-yellow-50", border: "border-yellow-100", icon: "!" },
    fail: { text: "text-red-700", iconBackground: "bg-red-100", background: "bg-red-50", border: "border-red-100", icon: "×" },
    info: { text: "text-[#181445]", iconBackground: "bg-blue-100", background: "bg-[#E9E5FF]", border: "border-[#CFC2D4]", icon: "i" },
  }[variant];
  return (
    <div className={`summary-box--${variant} flex items-center justify-center gap-4 border-r p-7 last:border-r-0 ${styles.background} ${styles.border}`}>
      <div className={`summary-box__icon flex h-11 w-11 items-center justify-center rounded-full text-xl font-bold ${styles.iconBackground} ${styles.text}`}>{styles.icon}</div>
      <div className="summary-copy"><div className={`summary-box__value text-3xl font-bold ${styles.text}`}>{value}</div><div className="summary-box__label text-sm font-medium text-[#6B7280]">{label}</div><div className="summary-detail">{detail}</div></div>
    </div>
  );
}

function MetadataRow({ label, value, tone = "neutral" }: { label: string; value: string; tone?: "neutral" | "pass" | "fail" }) {
  const toneClass = tone === "fail" ? "metadata-value--fail text-red-600" : tone === "pass" ? "metadata-value--pass text-green-700" : "metadata-value--neutral text-[#181445]";
  return <div className="grid grid-cols-[140px_1fr] border-b border-[#E5E0EA] px-3 py-2 last:border-b-0 md:[&:nth-last-child(-n+2)]:border-b-0"><dt className="text-[#181445]">{label}</dt><dd className={`metadata-value font-bold ${toneClass}`}>{value}</dd></div>;
}

function SharedResultRow({ result }: { result: ValidationResult }) {
  const styles = {
    pass: { icon: "✓", row: "bg-white", iconStyle: "bg-green-100 text-green-700", value: "text-[#181445]" },
    warning: { icon: "!", row: "bg-[#FCDF46]/20", iconStyle: "bg-yellow-100 text-yellow-700", value: "text-yellow-700" },
    fail: { icon: "×", row: "bg-red-50", iconStyle: "bg-red-100 text-red-700", value: "text-red-600" },
    info: { icon: "○", row: "bg-white", iconStyle: "text-[#7E7383]", value: "text-[#181445]" },
  }[result.status];
  const value = checklistValue(result);
  return (
    <details className={`result-row result-row--${result.status} group border-b border-[#E5E0EA] ${styles.row}`}>
      <summary className="flex cursor-pointer list-none items-center gap-2 px-2 py-2 text-sm marker:content-none"><span className={`result-row__icon flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-sm font-bold ${styles.iconStyle}`}>{styles.icon}</span><span className="result-row__label min-w-0 flex-1 truncate text-[#181445]">{checklistLabel(result)}</span><span className={`result-row__value min-w-0 font-bold ${styles.value}`} title={String(value)}>{String(value)}</span></summary>
      <div className="result-row__details px-9 pb-3 text-xs leading-5 text-[#6B7280]"><p>{result.message}</p>{result.expected !== undefined && <p className="mt-1">Expected: <span className="result-row__expected font-semibold text-[#181445]">{String(result.expected)}</span></p>}{result.recommendation && <p className="result-row__recommendation mt-2 text-[#726200]">{result.recommendation}</p>}{result.files && result.files.length > 0 && <p className="mt-2 font-mono">{result.files.slice(0, 4).join(", ")}{result.files.length > 4 ? "..." : ""}</p>}</div>
    </details>
  );
}

function checklistLabel(result: ValidationResult): string {
  const labels: Record<string, string> = {
    ASSET002: "Images Load Correctly", ASSET003: "Images Optimized", ASSET004: "Missing Assets", ANIM001: "Animation Duration", ANIM002: "Animation Policy", CLICK001: "Click Through", CLICK002: "Landing Page Working", CODE001: "Code Syntax", FILE001: "Hosted File Count", GWD001: "HTML5 Library", GWD002: "Studio / AdLib Policy", HTML001: "Dimensions", HTML002: "Meta tag ad.size", JS001: "Console Errors", MEDIA001: "Has Audio", MEDIA002: "Has Video", NET001: "404 File Error", NET002: "External Assets", PERF001: "Runtime Duration", PKG001: "Index File Check", RENDER001: "Creative Elements Displayed", SEC001: "SSL-Compatibility", SIZE001: "Compressed File Size", SIZE002: "Load Size: Initial", SIZE003: "Load Size: Subload", SIZE004: "Load Size: Total", SIZE005: "Hosted File Size", VIS001: "Creative Border", VIS002: "Visual Start",
  };
  return labels[result.ruleId] ?? result.title;
}

function checklistValue(result: ValidationResult): string | number | boolean {
  if (typeof result.actual === "boolean") return result.actual ? "Yes" : "No";
  if (result.actual !== undefined) return result.actual;
  if (result.files?.length) return result.files.length;
  return result.status === "pass" ? "Passed" : result.status === "fail" ? "Failed" : result.status === "warning" ? "Warning" : "Info";
}

function getResultValue(results: ValidationResult[], ruleId: string): string | undefined {
  const result = results.find((item) => item.ruleId === ruleId);
  return result?.actual === undefined ? undefined : String(result.actual);
}

function formatTimestamp(timestamp: string): string {
  const date = new Date(timestamp);
  return Number.isNaN(date.getTime()) ? timestamp : date.toLocaleString();
}

function ThemeIcon({ name }: { name: "sun" | "moon" }) {
  const path = name === "sun" ? "M12 3v2m0 14v2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4M3 12h2m14 0h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0" : "M20 15.3A8 8 0 0 1 8.7 4 8 8 0 1 0 20 15.3Z";
  return <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={path} /></svg>;
}
