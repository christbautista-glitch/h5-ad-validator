export type ValidationStatus =
  | "pass"
  | "warning"
  | "fail"
  | "info";

export type ValidationCategory =
  | "package"
  | "html"
  | "click"
  | "asset"
  | "media"
  | "network"
  | "javascript"
  | "animation"
  | "performance"
  | "security"
  | "visual"
  | "interaction";

export type ValidationType =
  | "static"
  | "runtime"
  | "visual";

export interface ValidationResult {
  ruleId: string;

  title: string;

  category: ValidationCategory;

  status: ValidationStatus;

  message: string;

  actual?: string | number | boolean;

  expected?: string | number | boolean;

  files?: string[];

  recommendation?: string;

  details?: Record<string, unknown>;
}

import type { CreativeContext } from "./context";
import type { ValidationRuleProfile } from "./profiles/types";

export interface ValidationRule {
  id: string;

  name: string;

  description: string;

  category: ValidationCategory;

  type: ValidationType;

  run(context: CreativeContext, ruleProfile?: ValidationRuleProfile): Promise<ValidationResult>;
}
