import { describe, expect, it } from "vitest";
import type { RuntimeContext } from "../runtime/types";
import { validateRuntime } from "../runtime/engine";
import { adBlockRule, cpuUsageRule, creativeBorderRule, imagesLoadRule, initialLoadSizeRule, memoryUsageRule, networkRequestsRule, notFoundRule, runtimeDurationRule, runtimeMeasurementPixelsRule, visualStartRule } from "./runtime";

const runtimeContext: RuntimeContext = {
  origin: "http://127.0.0.1:1",
  runtimeStatus: "available",
  consoleErrors: [],
  pageErrors: [],
  requests: [],
  responses: [],
  requestFailures: [],
  images: [],
  rendered: true,
  visual: {
    creativeBorder: {
      detected: true,
      method: "css-border",
      element: "div",
    },
  },
  navigationAttempts: [],
  popupAttempts: [],
  durationMs: 1,
  initialLoadBytes: 10,
  subloadBytes: 0,
  totalLoadBytes: 10,
};

describe("runtime profile configuration", () => {
  it("reports an AdBlock-style request failure as a warning", async () => {
    const result = await adBlockRule.run({ ...runtimeContext, adBlockAffected: true }, { enabled: true, severity: "warning" });
    expect(result).toMatchObject({ ruleId: "ADBLOCK001", status: "warning", actual: true, details: { adBlockAffected: true, measured: true } });
  });

  it("passes when no AdBlock-style blocking was detected", async () => {
    const result = await adBlockRule.run({ ...runtimeContext, adBlockAffected: false }, { enabled: true, severity: "fail" });
    expect(result).toMatchObject({ ruleId: "ADBLOCK001", status: "pass", actual: false, details: { adBlockAffected: false } });
  });

  it("reports AdBlock status as unavailable when no blocking signal exists", async () => {
    const result = await adBlockRule.run(runtimeContext, { enabled: true, severity: "warning" });
    expect(result).toMatchObject({ ruleId: "ADBLOCK001", status: "info", details: { measured: false } });
  });

  it("reports the measured time to first visual paint", async () => {
    const result = await visualStartRule.run({ ...runtimeContext, timeToVisualStartMs: 128 }, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "RENDER002", status: "pass", actual: "128 ms", details: { timeToVisualStartMs: 128, measured: true } });
  });

  it("reports visual start as unavailable when the browser provides no paint metric", async () => {
    const result = await visualStartRule.run(runtimeContext, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "RENDER002", status: "info", details: { measured: false } });
  });

  it("reports the number of runtime network requests", async () => {
    const result = await networkRequestsRule.run({ ...runtimeContext, requests: [
      { url: "/index.html", method: "GET" },
      { url: "/main.js", method: "GET" },
    ] }, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "NET003", status: "pass", actual: 2, details: { count: 2 } });
  });

  it("reports zero runtime network requests when none occurred", async () => {
    const result = await networkRequestsRule.run(runtimeContext, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "NET003", status: "pass", actual: 0, details: { count: 0 } });
  });

  it("reports measured JavaScript heap usage in megabytes", async () => {
    const result = await memoryUsageRule.run({ ...runtimeContext, memoryUsageMb: 12.5 }, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "PERF003", status: "pass", actual: "12.5 MB", details: { memoryUsageMb: 12.5, measured: true } });
  });

  it("reports memory usage as unavailable when the browser hides it", async () => {
    const result = await memoryUsageRule.run(runtimeContext, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "PERF003", status: "info", details: { measured: false } });
  });

  it("reports measured CPU time in milliseconds", async () => {
    const result = await cpuUsageRule.run({ ...runtimeContext, cpuTimeMs: 42 }, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "PERF002", status: "pass", actual: "42 ms", details: { cpuTimeMs: 42, measured: true } });
  });

  it("reports CPU usage as unavailable when the browser provides no measurement", async () => {
    const result = await cpuUsageRule.run(runtimeContext, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "PERF002", status: "info", details: { measured: false } });
  });

  it("reports the number of measurement pixels detected at runtime", async () => {
    const result = await runtimeMeasurementPixelsRule.run({ ...runtimeContext, measurementPixels: 3 }, { enabled: true, severity: "info" });
    expect(result).toMatchObject({ ruleId: "TRACK001", status: "pass", actual: 3, details: { count: 3 } });
  });

  it("uses profile thresholds for SIZE002", async () => {
    const result = await initialLoadSizeRule.run(runtimeContext, {
      enabled: true,
      severity: "fail",
      thresholds: { maxBytes: 5 },
    });

    expect(result.status).toBe("fail");
    expect(result.details).toMatchObject({ initialLoadBytes: 10, maxBytes: 5 });
  });

  it("uses severity overrides for violations", async () => {
    const warning = await notFoundRule.run({ ...runtimeContext, responses: [{ url: "/missing.png", status: 404 }] }, {
      enabled: true,
      severity: "warning",
    });
    const failure = await notFoundRule.run({ ...runtimeContext, responses: [{ url: "/missing.png", status: 404 }] }, {
      enabled: true,
      severity: "fail",
    });

    expect(warning.status).toBe("warning");
    expect(failure.status).toBe("fail");
  });

  it("keeps pass results as pass when severity is configured", async () => {
    const result = await initialLoadSizeRule.run(runtimeContext, {
      enabled: true,
      severity: "fail",
      thresholds: { maxBytes: 100 },
    });

    expect(result.status).toBe("pass");
  });

  it("uses profile thresholds for PERF001", async () => {
    const result = await runtimeDurationRule.run({ ...runtimeContext, durationMs: 250 }, {
      enabled: true,
      severity: "warning",
      thresholds: { maxDurationMs: 100 },
    });

    expect(result.status).toBe("warning");
    expect(result.details).toMatchObject({ durationMs: 250, maxDurationMs: 100 });
  });

  it("does not display the non-enforcing PERF001 threshold as a real limit", async () => {
    const result = await runtimeDurationRule.run(runtimeContext, {
      enabled: true,
      severity: "warning",
      thresholds: { maxDurationMs: Number.MAX_SAFE_INTEGER },
    });

    expect(result.status).toBe("pass");
    expect(result.message).toContain("No runtime duration threshold is configured");
  });

  it("keeps ASSET002 implementation available for future profiles", async () => {
    const result = await imagesLoadRule.run(runtimeContext, { enabled: true, severity: "fail" });

    expect(result.ruleId).toBe("ASSET002");
    expect(result.status).toBe("pass");
  });

  it("passes VIS001 when a border fact is detected", async () => {
    const result = await creativeBorderRule.run(runtimeContext, { enabled: true, severity: "warning" });

    expect(result).toMatchObject({
      ruleId: "VIS001",
      status: "pass",
      details: { detected: true, method: "css-border", element: "div" },
    });
  });

  it("warns VIS001 when no border is detected", async () => {
    const result = await creativeBorderRule.run({
      ...runtimeContext,
      visual: { creativeBorder: { detected: false, method: "unknown" } },
    }, { enabled: true, severity: "warning" });

    expect(result.status).toBe("warning");
  });

  it("reports VIS001 as info when visual facts are unavailable", async () => {
    const result = await creativeBorderRule.run({
      ...runtimeContext,
      visual: undefined,
    }, { enabled: true, severity: "warning" });

    expect(result.status).toBe("info");
  });

  it("does not execute runtime rules when they are disabled", async () => {
    const result = await validateRuntime({
      filename: "creative.zip",
      compressedSize: 1,
      files: new Map(),
    }, {
      id: "runtime-disabled",
      name: "Runtime Disabled",
      rules: {
        ANIM001: { enabled: false },
        NET001: { enabled: false },
        JS001: { enabled: false },
        RENDER001: { enabled: false },
        VIS002: { enabled: false },
        VIS001: { enabled: false },
        ASSET002: { enabled: false },
        MEDIA002: { enabled: false },
        SIZE002: { enabled: false },
        SIZE003: { enabled: false },
        SIZE004: { enabled: false },
        PERF001: { enabled: false },
        CLICK002: { enabled: false },
        ADBLOCK001: { enabled: false },
        JS002: { enabled: false },
        RENDER002: { enabled: false },
        PERF002: { enabled: false },
        PERF003: { enabled: false },
        NET003: { enabled: false },
        TRACK001: { enabled: false },
      },
    });

    expect(result.runtime).toBeNull();
    expect(result.results).toEqual([]);
  });
});
