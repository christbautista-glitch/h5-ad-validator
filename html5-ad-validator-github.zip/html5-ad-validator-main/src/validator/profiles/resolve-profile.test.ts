import { describe, expect, it } from "vitest";
import { applySeverityOverride } from "./resolve-profile";

describe("profile rule resolution", () => {
  const result = {
    ruleId: "TEST001",
    title: "Test Rule",
    category: "html" as const,
    status: "fail" as const,
    message: "Violation.",
  };

  it("applies severity overrides to violation results", () => {
    expect(applySeverityOverride(result, { enabled: true, severity: "warning" }).status).toBe("warning");
    expect(applySeverityOverride(result, { enabled: true, severity: "fail" }).status).toBe("fail");
  });

  it("preserves pass and info results", () => {
    expect(applySeverityOverride({ ...result, status: "pass" }, { enabled: true, severity: "fail" }).status).toBe("pass");
    expect(applySeverityOverride({ ...result, status: "info" }, { enabled: true, severity: "fail" }).status).toBe("info");
  });
});
