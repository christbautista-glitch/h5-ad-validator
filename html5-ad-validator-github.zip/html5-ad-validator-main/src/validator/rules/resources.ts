import type { ValidationRule } from "../types";
import { getResourceGraph } from "../resources";

export const externalAssetsRule: ValidationRule = { id: "NET002", name: "External Assets", description: "Detects resources loaded from external URLs.", category: "network", type: "static", async run(context) {
  const resources = getResourceGraph(context).filter((r) => r.location === "external");
  const urls = resources.map((r) => r.raw);
  return { ruleId: "NET002", title: "External Assets", category: "network", status: urls.length ? "warning" : "pass", actual: urls.length, message: urls.length ? `${urls.length} external resource(s) detected.` : "No external resources detected.", files: [...new Set(resources.map((r) => r.sourceFile))], details: { resources: urls } };
} };

export const missingAssetsRule: ValidationRule = { id: "ASSET004", name: "Missing Assets", description: "Checks local resource references against package files.", category: "asset", type: "static", async run(context) {
  const missing = getResourceGraph(context).filter((r) => r.location === "local" && r.resolved && !context.files.has(r.resolved));
  const paths = [...new Set(missing.filter((r) => !r.commented).map((r) => r.resolved!))];
  const commentedPaths = [...new Set(missing.filter((r) => r.commented).map((r) => r.resolved!))];
  const status = paths.length ? "fail" : "pass";
  return { ruleId: "ASSET004", title: "Missing Assets", category: "asset", status, actual: paths.length, message: paths.length ? `${paths.length} active missing local asset(s) detected.` : commentedPaths.length ? `No active missing assets detected. ${commentedPaths.length} commented-out asset reference(s) were ignored.` : "All active local resource references resolve to packaged files.", details: { resources: paths, commentedResources: commentedPaths }, recommendation: paths.length ? "Package the actively referenced files or remove their active references." : undefined };
} };

export const sslCompatibilityRule: ValidationRule = { id: "SEC001", name: "SSL Compatibility", description: "Detects insecure HTTP resources.", category: "security", type: "static", async run(context) {
  const paths = [...new Set(getResourceGraph(context).filter((r) => r.protocol === "http").map((r) => r.raw))];
  return { ruleId: "SEC001", title: "SSL Compatibility", category: "security", status: paths.length ? "warning" : "pass", actual: paths.length, message: paths.length ? `${paths.length} insecure HTTP resource(s) detected.` : "No insecure HTTP resources detected.", details: { resources: paths }, recommendation: paths.length ? "Use HTTPS for externally loaded resources." : undefined };
} };
