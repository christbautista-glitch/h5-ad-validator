import { afterEach, describe, expect, it, vi } from "vitest";

import { createValidationReport } from "./report";
import { createValidationPdf, sanitizeReportFilename } from "./pdf-report";
import { renderValidationReportHtml } from "./pdf-report-html";
import type { ValidationResult } from "./types";

function result(index: number, status: ValidationResult["status"] = "pass"): ValidationResult {
  return {
    ruleId: `RULE${index.toString().padStart(3, "0")}`,
    title: `Validation Rule ${index}`,
    category: index % 2 === 0 ? "asset" : "visual",
    status,
    actual: index,
    expected: `<= ${index + 1}`,
    message: `Validation message ${index} with enough text to exercise PDF wrapping without overflowing the page.`,
    recommendation: status === "pass" ? undefined : "Review the creative and update the affected asset.",
    files: [`file-${index}.js`],
  };
}

describe("PDF validation reports", () => {
  afterEach(() => vi.restoreAllMocks());

  it("renders the complete report as print-ready HTML", () => {
    const report = createValidationReport("creative.zip", [
      result(1, "pass"),
      result(2, "warning"),
      result(3, "fail"),
      result(4, "info"),
    ], "2026-08-18T15:45:00.000Z", { id: "gdn", name: "GDN" });

    const html = renderValidationReportHtml(report, {
      metadata: {
        filename: "creative.zip",
        dimensions: "300x250",
        profile: "GDN",
        validatedAt: "2026-08-18T15:45:00.000Z",
      },
    }, "data:image/png;base64,bG9nbw==");

    expect(html).toContain("creative.zip");
    expect(html).toContain("Checklist summary");
    expect(html).toContain("Validation Rule 3");
    expect(html).toContain("@page");
    expect(html).not.toContain("<iframe");
    expect(html).not.toContain("preview-stage");
    expect(html).toContain("HTML5 Ad Validator");
    expect(html).toContain("data:image/png;base64,bG9nbw==");
    expect(html).toContain('class="report-header"');
    expect(html).not.toContain('class="creative-header"');
  });

  it("downloads PDF bytes from the server route", async () => {
    const report = createValidationReport("creative.zip", [result(1)]);
    const expected = new TextEncoder().encode("%PDF-server-output");
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response(expected, { status: 200, headers: { "Content-Type": "application/pdf" } }));
    const pdfBytes = await createValidationPdf(report);

    expect(new TextDecoder().decode(new Uint8Array(pdfBytes).slice(0, 4))).toBe("%PDF");
    expect(fetchMock).toHaveBeenCalledWith("/api/reports/pdf", expect.objectContaining({ method: "POST" }));
  });

  it("sanitizes PDF filenames", () => {
    expect(sanitizeReportFilename("summer sale / 300x250.zip")).toBe("summer-sale-300x250-validation-report.pdf");
    expect(sanitizeReportFilename(null)).toBe("creative-validation-report.pdf");
  });
});
