import { describe, expect, it } from "vitest";
import type { CreativeContext, CreativeFile } from "../context";
import { renderedRule } from "./rendered";

function context(indexHtml: string, files: Array<[string, string]> = []): CreativeContext {
  const creativeFiles = new Map<string, CreativeFile>();
  creativeFiles.set("index.html", { path: "index.html", size: indexHtml.length, extension: "html", content: indexHtml });
  for (const [path, extension] of files) {
    creativeFiles.set(path, { path, size: 1, extension });
  }

  return {
    filename: "creative.zip",
    compressedSize: 1,
    indexHtml,
    files: creativeFiles,
    resources: [],
  };
}

describe("RENDER001 static creative elements check", () => {
  it("passes when the package contains visual assets", async () => {
    const result = await renderedRule.run(context("<html><body></body></html>", [["images/hero.png", "png"]]));

    expect(result).toMatchObject({
      ruleId: "RENDER001",
      title: "Creative Elements Displayed",
      status: "pass",
      actual: true,
      details: { visualFileCount: 1 },
    });
  });

  it("passes when index.html contains renderable markup", async () => {
    const result = await renderedRule.run(context("<html><body><canvas id=\"stage\"></canvas></body></html>"));

    expect(result.status).toBe("pass");
    expect(result.details).toMatchObject({ hasRenderableMarkup: true });
  });

  it("uses configured severity when no static creative elements are detected", async () => {
    const result = await renderedRule.run(context("<html><body></body></html>"), { enabled: true, severity: "warning" });

    expect(result).toMatchObject({
      ruleId: "RENDER001",
      status: "warning",
      actual: false,
      expected: true,
      message: "No static creative elements were detected in the package.",
    });
  });
});
