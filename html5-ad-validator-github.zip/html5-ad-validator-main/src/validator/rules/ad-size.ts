import type { ValidationRule } from "../types";

function extractAdSize(
  html: string
): { width: number; height: number } | null {
  const metaPattern =
    /<meta[^>]*name=["']ad\.size["'][^>]*content=["'][^"']*width\s*=\s*(\d+)\s*,\s*height\s*=\s*(\d+)[^"']*["'][^>]*>/i;

  const match = html.match(metaPattern);

  if (!match) {
    return null;
  }

  return {
    width: Number(match[1]),
    height: Number(match[2]),
  };
}

export const adSizeRule: ValidationRule = {
  id: "HTML002",

  name: "Meta Tag Ad Size",

  description:
    "Checks whether index.html contains a valid meta ad.size tag.",

  category: "html",

  type: "static",

  async run(context) {
    if (!context.indexHtml) {
      return {
        ruleId: "HTML002",
        title: "Meta Tag Ad Size",
        category: "html",
        status: "fail",

        message:
          "Cannot check ad.size because index.html was not found.",
      };
    }

    const size = extractAdSize(context.indexHtml);

    if (!size) {
      return {
        ruleId: "HTML002",
        title: "Meta Tag Ad Size",
        category: "html",
        status: "fail",

        actual: "Not detected",
        expected:
          '<meta name="ad.size" content="width=300,height=250">',

        message:
          "No valid meta ad.size tag was detected.",

        recommendation:
          "Add a valid meta ad.size tag inside the document head.",
      };
    }

    const dimensions = `${size.width}x${size.height}`;

    return {
      ruleId: "HTML002",
      title: "Meta Tag Ad Size",
      category: "html",
      status: "pass",

      actual: dimensions,

      message:
        `Meta ad.size declares ${dimensions}.`,
    };
  },
};