import type { ValidationRule } from "../types";

const VISUAL_ASSET_TYPES = new Set(["image", "video"]);
const VISUAL_FILE_EXTENSIONS = new Set([
  "apng",
  "avif",
  "gif",
  "jpg",
  "jpeg",
  "mp4",
  "png",
  "svg",
  "webm",
  "webp",
]);

export const renderedRule: ValidationRule = {
  id: "RENDER001",
  name: "Creative Elements Displayed",
  description: "Checks whether the creative package contains elements that can load and display visually.",
  category: "visual",
  type: "static",

  async run(context, ruleProfile) {
    const html = context.indexHtml?.toLowerCase() ?? "";
    const visualResources = (context.resources ?? []).filter((resource) => VISUAL_ASSET_TYPES.has(resource.type));
    const visualFiles = Array.from(context.files.values()).filter((file) => VISUAL_FILE_EXTENSIONS.has(file.extension));
    const hasRenderableMarkup = /<(img|video|canvas|svg|picture)\b/.test(html);
    const hasStyledContent = /<(div|section|main|article|span|button|a)\b/.test(html)
      && /(background|background-image|color|border|opacity|transform|animation|transition|width|height)\s*:/.test(html);
    const detected = Boolean(context.indexHtml) && (
      visualResources.length > 0
      || visualFiles.length > 0
      || hasRenderableMarkup
      || hasStyledContent
    );

    return {
      ruleId: "RENDER001",
      title: "Creative Elements Displayed",
      category: "visual",
      status: detected ? "pass" : ruleProfile?.severity ?? "fail",
      actual: detected,
      expected: true,
      message: detected
        ? "Creative elements were detected in the package and can be displayed by the browser."
        : "No static creative elements were detected in the package.",
      files: visualFiles.length > 0 ? visualFiles.map((file) => file.path) : undefined,
      details: {
        visualResourceCount: visualResources.length,
        visualFileCount: visualFiles.length,
        hasRenderableMarkup,
        hasStyledContent,
      },
    };
  },
};
