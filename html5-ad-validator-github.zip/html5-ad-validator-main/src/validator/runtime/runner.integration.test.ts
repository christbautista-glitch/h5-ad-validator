import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { runRuntimeAnalysis } from "./runner";

describe("Chromium runtime analysis", () => {
  it("loads a creative once and collects runtime facts", async () => {
    const html = `<!doctype html><html><body><img src="missing.png"><script>console.error("runtime test");</script><main>Rendered</main></body></html>`;
    const context: CreativeContext = {
      filename: "runtime-test.zip",
      compressedSize: html.length,
      files: new Map([
        ["index.html", { path: "index.html", size: html.length, extension: "html", content: html }],
      ]),
    };

    const result = await runRuntimeAnalysis(context);

    expect(result.origin).toMatch(/^http:\/\/127\.0\.0\.1:\d+$/);
    expect(result.rendered).toBe(true);
    expect(result.consoleErrors).toContain("runtime test");
    expect(result.responses.some((response) => response.status === 404 && response.url.endsWith("/missing.png"))).toBe(true);
    expect(result.initialLoadBytes).toBeGreaterThan(0);
    expect(result.totalLoadBytes).toBeGreaterThan(0);
    expect(result.images).toEqual([{ url: `${result.origin}/missing.png`, complete: true, naturalWidth: 0, naturalHeight: 0 }]);
  }, 20_000);
});
