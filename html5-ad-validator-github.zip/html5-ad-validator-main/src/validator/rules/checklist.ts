import type { ValidationRule } from "../types";

const ALLOWED_EXTENSIONS = new Set([
  "html", "htm", "css", "js", "json", "svg", "png", "jpg", "jpeg", "gif", "webp", "avif",
  "mp4", "webm", "mp3", "wav", "ogg", "woff", "woff2", "ttf", "otf",
]);

function staticResult(ruleId: string, title: string, category: "asset" | "javascript", status: "pass" | "warning" | "fail", actual: boolean | number, message: string, files?: string[]) {
  return { ruleId, title, category, status, actual, message, files };
}

export const allowedFileTypesRule: ValidationRule = { id: "ASSET005", name: "Allowed File Types", description: "Checks that packaged files use supported creative file types.", category: "asset", type: "static", async run(context) {
  const invalid = [...context.files.values()].filter((file) => !ALLOWED_EXTENSIONS.has(file.extension));
  return { ...staticResult("ASSET005", "Allowed File Types", "asset", invalid.length ? "fail" : "pass", invalid.length === 0, invalid.length ? `${invalid.length} unsupported file type(s) detected.` : "All packaged file types are allowed.", invalid.map((file) => file.path)), details: { allowedExtensions: [...ALLOWED_EXTENSIONS] } };
} };

function looksMinified(source: string): boolean {
  const withoutComments = source.replace(/\/\*[\s\S]*?\*\//g, "").replace(/(^|\s)\/\/.*$/gm, "$1").trim();
  if (!withoutComments) return true;
  const whitespace = (withoutComments.match(/\s/g) ?? []).length;
  const hasReadableSpacing = /\s(?:=>|===|!==|\+|[-*\/])\s/.test(withoutComments) || /[{;][ \t]+\S/.test(withoutComments);
  return whitespace / withoutComments.length < 0.16 && !hasReadableSpacing && !/\r?\n/.test(withoutComments);
}

export const minifiedAssetsRule: ValidationRule = { id: "CODE002", name: "CSS/JS Minified", description: "Checks CSS and JavaScript source for common unminified formatting.", category: "javascript", type: "static", async run(context) {
  const files = [...context.files.values()].filter((file) => (file.extension === "css" || file.extension === "js") && file.content !== undefined);
  const unminified = files.filter((file) => !looksMinified(file.content ?? ""));
  return { ...staticResult("CODE002", "CSS/JS Minified", "javascript", unminified.length ? "warning" : "pass", unminified.length === 0, unminified.length ? `${unminified.length} CSS/JavaScript file(s) appear unminified.` : "CSS and JavaScript files appear minified.", unminified.map((file) => file.path)), details: { checkedFiles: files.length } };
} };

export const documentWriteRule: ValidationRule = { id: "CODE003", name: "Uses document.write()", description: "Detects document.write() calls in creative source.", category: "javascript", type: "static", async run(context) {
  const files = [...context.files.values()].filter((file) => ["html", "htm", "js"].includes(file.extension) && file.content !== undefined && /\bdocument\s*\.\s*write\s*\(/i.test(file.content));
  return { ...staticResult("CODE003", "Uses document.write()", "javascript", files.length ? "fail" : "pass", files.length === 0, files.length ? "document.write() usage was detected." : "No document.write() usage detected.", files.map((file) => file.path)), recommendation: files.length ? "Use DOM APIs instead of document.write()." : undefined };
} };
