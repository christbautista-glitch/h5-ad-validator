"use client";

import JSZip from "jszip";
import { useEffect, useRef, useState } from "react";

import type { ValidationResult } from "@/validator/types";
import type { ValidationProfileMetadata } from "@/validator/profiles/types";
import type { PdfCreativeMetadata } from "@/validator/pdf-report";
import { createBulkValidationReport, createValidationReport, summarizeResults } from "@/validator/report";
import { OPTIONAL_RULE_IDS, checklistLabel, checklistValue } from "@/validator/report-format";
import { sanitizeReportFilename } from "@/validator/pdf-report";
import { loadCreativeZip } from "@/validator/zip-loader";
import { validateCreative } from "@/validator/engine";
import { getValidationProfile } from "@/validator/profiles/registry";
import { profileMetadata } from "@/validator/profiles/resolve-profile";

const MAX_BULK_UPLOADS = 10;
const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH ?? "";
interface CreativePreview {
  html: string;
  width?: number;
  height?: number;
}

interface PreviewBorderResult {
  detected: boolean;
  method: "css-border" | "unknown";
  element?: string;
}

interface CreativeValidationItem {
  id: string;
  file: File;
  filename: string;
  results: ValidationResult[];
  preview: CreativePreview | null;
  previewBorder: PreviewBorderResult | null;
  previewError: string | null;
  loading: boolean;
  error: string | null;
}

function createCreativeValidationItem(file: File): CreativeValidationItem {
  return {
    id: `${file.name}-${file.size}-${file.lastModified}-${crypto.randomUUID()}`,
    file,
    filename: file.name,
    results: [],
    preview: null,
    previewBorder: null,
    previewError: null,
    loading: false,
    error: null,
  };
}

export default function CreativeUpload({
  validationProfiles,
}: {
  validationProfiles: ValidationProfileMetadata[];
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const previewIframeRefs = useRef(new Map<string, HTMLIFrameElement>());
  const [creatives, setCreatives] = useState<CreativeValidationItem[]>([]);
  const [profile, setProfile] = useState<ValidationProfileMetadata>(validationProfiles[0] ?? { id: "html5-standard", name: "HTML5 Standard" });
  const [error, setError] = useState<string | null>(null);
  const [shareStatus, setShareStatus] = useState<string | null>(null);
  const [generatingReportId, setGeneratingReportId] = useState<string | null>(null);
  const [darkMode, setDarkMode] = useState(false);

  const activeCreative = creatives[0] ?? null;
  const selectedFile = activeCreative?.file ?? null;
  const filename = activeCreative?.filename ?? null;
  const results = activeCreative?.results ?? [];
  const preview = activeCreative?.preview ?? null;
  const previewBorder = activeCreative?.previewBorder ?? null;
  const previewError = activeCreative?.previewError ?? null;
  const loading = creatives.some((creative) => creative.loading);
  const validatedCreatives = creatives.filter((creative) => creative.results.length > 0);
  const hasBulkValidation = validatedCreatives.length > 1;
  const selectedCount = creatives.length;
  const uploadLabel = selectedCount > 1 ? `${selectedCount} ZIP files selected` : filename;
  const summary = summarizeResults(results);
  const failedCount = results.filter((result) => result.status === "fail").length;
  const displayDimensions = getResultValue(results, "HTML001") ?? getResultValue(results, "HTML002") ?? formatDimensions(preview);

  function updateCreative(creativeId: string, update: Partial<CreativeValidationItem>) {
    setCreatives((current) => current.map((creative) => creative.id === creativeId ? { ...creative, ...update } : creative));
  }

  function setPreviewIframeRef(creativeId: string) {
    return (node: HTMLIFrameElement | null) => {
      if (node) {
        previewIframeRefs.current.set(creativeId, node);
      } else {
        previewIframeRefs.current.delete(creativeId);
      }
    };
  }

  useEffect(() => {
    function handlePreviewMessage(event: MessageEvent) {
      if (!event.data || event.data.source !== "html5-ad-validator-preview") {
        return;
      }

      if (event.data.type === "preview-border") {
        const sourceEntry = Array.from(previewIframeRefs.current.entries())
          .find(([, iframe]) => iframe.contentWindow === event.source);

        if (!sourceEntry) {
          return;
        }

        const [creativeId] = sourceEntry;
        setCreatives((current) => current.map((creative) => creative.id === creativeId
          ? { ...creative, previewBorder: event.data.detail as PreviewBorderResult }
          : creative));
      }
    }

    window.addEventListener("message", handlePreviewMessage);
    return () => window.removeEventListener("message", handlePreviewMessage);
  }, []);

  function handleSelectFiles(files: FileList | File[]) {
    setError(null);
    setShareStatus(null);
    const nextFiles = Array.from(files);

    if (nextFiles.length === 0) {
      return;
    }

    if (nextFiles.length > MAX_BULK_UPLOADS) {
      setError(`You can upload up to ${MAX_BULK_UPLOADS} ZIP archives at a time.`);
      return;
    }

    const invalidFile = nextFiles.find((file) => !file.name.toLowerCase().endsWith(".zip"));

    if (invalidFile) {
      setError(`Only ZIP archives are supported. "${invalidFile.name}" is not a ZIP file.`);
      return;
    }

    const nextCreatives = nextFiles.map(createCreativeValidationItem);
    setCreatives(nextCreatives);
    for (const creative of nextCreatives) {
      void createPreview(creative.id, creative.file);
    }
  }

  async function runValidation() {
    if (creatives.length === 0) {
      inputRef.current?.click();
      return;
    }

    setError(null);

    for (const creative of creatives) {
      await validateCreativeItem(creative);
    }
  }

  async function validateCreativeItem(creative: CreativeValidationItem) {
    try {
      updateCreative(creative.id, { loading: true, error: null, results: [] });

      if (creative.file.size === 0) throw new Error("The uploaded ZIP archive is empty.");
      if (creative.file.size > MAX_UPLOAD_BYTES) throw new Error("The ZIP archive exceeds the 10 MB upload limit.");
      const selectedProfile = getValidationProfile(profile.id);
      if (!selectedProfile) throw new Error(`Unknown validation profile: ${profile.id}`);
      const context = await loadCreativeZip(creative.file);
      const nextResults = await validateCreative(context, selectedProfile);
      updateCreative(creative.id, { results: nextResults });
      setProfile(profileMetadata(selectedProfile));
    } catch (err) {
      console.error(err);
      updateCreative(creative.id, { error: "The ZIP archive could not be processed." });
    } finally {
      updateCreative(creative.id, { loading: false });
    }
  }

  async function downloadReport(creative: CreativeValidationItem | null = activeCreative) {
    if (!creative) {
      return;
    }

    try {
      setGeneratingReportId(creative.id);
      const generatedAt = new Date().toISOString();
      const filename = sanitizeReportFilename(creative.filename);
      const report = createValidationReport(creative.filename, creative.results, generatedAt, profile);
      await downloadPdf(report, filename, {
        filename: creative.filename,
        fileSize: formatBytes(creative.file.size),
        dimensions: getResultValue(creative.results, "HTML001") ?? getResultValue(creative.results, "HTML002") ?? formatDimensions(creative.preview),
        profile: profile.name,
        validatedAt: generatedAt,
      });
    } catch (reportError) {
      console.error("PDF report generation failed", reportError);
      setShareStatus("PDF report could not be generated.");
    } finally {
      setGeneratingReportId(null);
    }
  }

  async function downloadBulkReport() {
    const report = createBulkReportPayload();
    if (!report) {
      return;
    }

    try {
      setGeneratingReportId("bulk");
      const creativeMetadataByFilename = Object.fromEntries(
        await Promise.all(validatedCreatives.map(async (creative) => [
          creative.filename,
          {
            filename: creative.filename,
            fileSize: formatBytes(creative.file.size),
            dimensions: getResultValue(creative.results, "HTML001") ?? getResultValue(creative.results, "HTML002") ?? formatDimensions(creative.preview),
            profile: profile.name,
            validatedAt: new Date().toISOString(),
          },
        ] as const)),
      );
      await downloadPdf(report, "bulk-validation-report.pdf", undefined, creativeMetadataByFilename);
    } catch (reportError) {
      console.error("Bulk PDF report generation failed", reportError);
      setShareStatus("Bulk PDF report could not be generated.");
    } finally {
      setGeneratingReportId(null);
    }
  }

  async function downloadPdf(report: ReturnType<typeof createValidationReport> | ReturnType<typeof createBulkValidationReport>, filename: string, _metadata?: PdfCreativeMetadata, _creativeMetadataByFilename?: Record<string, PdfCreativeMetadata>) {
    // GitHub Pages has no server runtime for Chromium-based PDF rendering.
    // Export the complete report as JSON instead so validation remains fully static.
    const jsonFilename = filename.replace(/\.pdf$/i, ".json");
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = jsonFilename;
    link.click();
    URL.revokeObjectURL(url);
    setShareStatus("GitHub Pages mode: report downloaded as JSON (PDF requires a server runtime).");
  }

  function createBulkReportPayload() {
    const generatedAt = new Date().toISOString();
    const reports = validatedCreatives.map((creative) => createValidationReport(creative.filename, creative.results, generatedAt, profile));

    if (reports.length === 0) {
      return null;
    }

    return reports.length === 1 ? reports[0] : createBulkValidationReport(reports, generatedAt, profile);
  }

  async function shareResults() {
    const report = createBulkReportPayload();

    if (!report) {
      setShareStatus("Run validation before sharing results.");
      return;
    }

    const encodedReport = encodeURIComponent(JSON.stringify(report));
    const shareUrl = `${window.location.origin}${BASE_PATH}/share/#report=${encodedReport}`;
    await navigator.clipboard.writeText(shareUrl);
    setShareStatus("Share link copied.");
  }

  function handleDrop(event: React.DragEvent<HTMLDivElement>) {
    event.preventDefault();

    handleSelectFiles(event.dataTransfer.files);
  }

  async function createPreview(creativeId: string, file: File) {
    try {
      const nextPreview = await buildZipPreview(file);
      setCreatives((current) => current.map((creative) => creative.id === creativeId ? { ...creative, preview: nextPreview } : creative));
    } catch (previewBuildError) {
      console.error(previewBuildError);
      setCreatives((current) => current.map((creative) => creative.id === creativeId ? { ...creative, previewError: "Preview unavailable for this ZIP." } : creative));
    }
  }

  const hasValidation = results.length > 0;
  const validationScore = hasValidation ? Math.round((summary.pass / summary.total) * 100) : null;

  // The legacy result sections below remain available to the workflow; this shell only
  // changes presentation and continues to call the same upload and validation handlers.
  return (
    <div className={darkMode ? "app-shell dark" : "app-shell"}>
      <aside className="app-sidebar">
        <div className="brand-mark"><img src={darkMode ? `${BASE_PATH}/branding/smartly-dark.png` : `${BASE_PATH}/branding/smartly-light.png`} alt="Smartly" /></div>
        <nav aria-label="Primary navigation" className="sidebar-nav">
          <p className="nav-label">Overview</p>
          <a className="nav-item active" href="#validate"><Icon name="grid" />Dashboard</a>
          <p className="nav-label">Validation</p>
          <a className="nav-item active" href="#validate"><Icon name="upload" />Validate Ad</a>
          <a className="nav-item" href="#history"><Icon name="clock" />History</a>
          <p className="nav-label">Settings</p>
          <a className="nav-item" href="#settings"><Icon name="settings" />Settings</a>
          <a className="nav-item" href="#integrations"><Icon name="link" />Integrations</a>
          <a className="nav-item" href="#team"><Icon name="users" />Team</a>
        </nav>
        <div className="sidebar-footer"><span className="status-dot" />Validator ready</div>
      </aside>

      <div className="app-main">
        <header className="topbar">
          <a className="mobile-brand app-brand" href="#validate" aria-label="HTML5 Ad Validator home">
            <img src={`${BASE_PATH}/branding/ad-validator-logo.png`} alt="" />
            <span>HTML5 Ad Validator</span>
          </a>
          <nav className="top-links" aria-label="Section navigation">
            <a className="current" href="#validate">Validate Ad</a>
          </nav>
          <div className="top-actions">
            <button type="button" className={`theme-switch ${darkMode ? "on" : ""}`} aria-label="Toggle dark mode" aria-pressed={darkMode} onClick={() => setDarkMode((value) => !value)}><span className="theme-switch-icon"><Icon name={darkMode ? "sun" : "moon"} /></span><span className="theme-switch-thumb" /></button>
          </div>
        </header>

        <main id="validate" className="page-content">
          <section className="hero-panel">
            <div className="hero-copy"><p className="eyebrow">Creative quality platform</p><h1>Validate Your<br /><span>HTML5 Ad</span></h1><p>Upload your HTML5 package to run a comprehensive validation.</p></div>
            <div className="hero-pattern" aria-hidden="true"><img src={`${BASE_PATH}/branding/smartly-pattern.png`} alt="" /></div>
            <div className="hero-upload" onDrop={handleDrop} onDragOver={(event) => event.preventDefault()} onClick={() => inputRef.current?.click()}>
              <input ref={inputRef} type="file" accept=".zip,application/zip" multiple className="hidden" onChange={(event) => { if (event.target.files) handleSelectFiles(event.target.files); }} />
              <div className="upload-cloud"><Icon name="upload" /></div><strong>{uploadLabel ?? `Drag & drop up to ${MAX_BULK_UPLOADS} ZIPs`}</strong><span>or choose files from your computer</span>
              <button type="button" className="hero-button" onClick={(event) => { event.stopPropagation(); inputRef.current?.click(); }}>Choose ZIP files</button><small>Maximum 10 ZIPs, 10 MB each</small>
            </div>
          </section>

          {error && <div className="error-banner" role="alert">{error}</div>}

          <section className="info-grid">
            <div className="info-card upload-card"><div className="step-number">01</div><h2>Upload</h2><p>Choose up to ten HTML5 ZIP packages to get started.</p><button type="button" className="secondary-button" onClick={() => inputRef.current?.click()}><Icon name="folder" /> Browse files</button></div>
            <div className="info-card"><div className="step-number">02</div><h2>Validation Options</h2><p>Choose the profile that matches your delivery environment.</p><label className="field-label" htmlFor="validation-profile">Environment</label><select id="validation-profile" value={profile.id} onChange={(event) => { const nextProfile = validationProfiles.find((item) => item.id === event.target.value); if (nextProfile) setProfile(nextProfile); }} className="styled-select">{validationProfiles.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select><div className="option-list"><span><Icon name="check" /> Performance checks</span><span><Icon name="check" /> HTTPS validation</span><span><Icon name="check" /> ClickTag validation</span></div></div>
            <div className="info-card"><div className="step-number">03</div><h2>Supported Specifications</h2><p>Built for the formats and standards you use every day.</p><div className="spec-list"><span><b>ZIP</b> Package format</span><span><b>HTML5</b> Creative type</span><span><b>IAB</b> Industry standards</span><span><b>10 MB</b> Maximum upload size</span></div></div>
          </section>

          <section className="action-panel"><div><p className="eyebrow">Ready when you are</p><h2>{selectedCount > 1 ? `${selectedCount} creatives are ready to validate` : filename ? "Your creative is ready to validate" : "Start your validation"}</h2><p>{shareStatus ?? profile.description ?? "Run package, asset, runtime, and delivery checks in one pass."}</p></div><div className="action-buttons"><button type="button" className="primary-button large validation-cta" onClick={() => void runValidation()} disabled={loading}>{loading ? "Validating..." : "Start Validation"}<Icon name="arrow" /></button>{validatedCreatives.length > 0 && <button type="button" className="secondary-button action-secondary" onClick={() => void shareResults()}><Icon name="link" /> Share results</button>}{hasBulkValidation && <button type="button" className="secondary-button action-secondary" onClick={() => void downloadBulkReport()} disabled={generatingReportId === "bulk"}>{generatingReportId === "bulk" ? "Generating PDF..." : "Download bulk PDF"}</button>}</div></section>

          {creatives.map((creative, creativeIndex) => {
            const creativeSummary = summarizeResults(creative.results);
            const creativeFailedCount = creative.results.filter((result) => result.status === "fail").length;
            const creativeHasValidation = creative.results.length > 0;
            const creativeDimensions = getResultValue(creative.results, "HTML001") ?? getResultValue(creative.results, "HTML002") ?? formatDimensions(creative.preview);
            const creativeStatus = creative.loading ? "Validating..." : creative.error ? "Validation failed" : creativeHasValidation ? (creativeFailedCount ? `${creativeFailedCount} tests failed` : "Passed") : "Not scanned";
            const creativeTone = creative.error || (creativeHasValidation && creativeFailedCount) ? "fail" : creativeHasValidation ? "pass" : "neutral";
            const standardResults = creative.results.filter((result) => !OPTIONAL_RULE_IDS.has(result.ruleId));
            const optionalResults = creative.results.filter((result) => OPTIONAL_RULE_IDS.has(result.ruleId));

            return (
              <details className="creative-accordion" key={creative.id} open={creativeIndex === 0}>
                <summary className="creative-accordion__summary">
                  <span className="creative-accordion__title"><span className="eyebrow">Creative {creatives.length > 1 ? creativeIndex + 1 : ""}</span>{creative.filename}</span>
                  <span className="creative-accordion__meta">{creativeDimensions ?? "Dimensions pending"}</span>
                  <span className={`creative-accordion__status creative-accordion__status--${creativeTone}`}>{creativeStatus}</span>
                  <span className="creative-accordion__chevron" aria-hidden="true">⌄</span>
                </summary>

                <div className="creative-accordion__body">
                  <section className="results-card">
                    <div className="metadata-grid"><MetadataRow label="Name" value={creative.filename} /><MetadataRow label="File Size" value={formatBytes(creative.file.size)} /><MetadataRow label="Timestamp" value="Just now" /><MetadataRow label="Dimensions" value={creativeDimensions ?? "-"} /><MetadataRow label="Scanned By" value="Local validator" /><MetadataRow label="Creative Type" value="HTML5 Zip" /><MetadataRow label="Result" value={creativeStatus} tone={creativeTone} /><MetadataRow label="Profile" value={profile.name} /></div>
                  </section>

                  {creative.loading && <section className="loading-card" aria-live="polite" aria-busy="true"><div className="spinner" /><h2>Running validation checks...</h2><p>Inspecting {creative.filename} for package files, resources, runtime requests, rendering, and landing-page behavior.</p></section>}
                  {creative.error && <div className="error-banner" role="alert">{creative.error}</div>}
                  {!creative.loading && creativeHasValidation && <section className="results-card validation-results"><div className="section-heading"><div><p className="eyebrow">Validation results</p><h2>Checklist summary</h2></div><button type="button" className="secondary-button" onClick={() => void downloadReport(creative)} disabled={generatingReportId === creative.id}>{generatingReportId === creative.id ? "Generating PDF..." : "Download PDF"}</button></div><div className="preview-stage result-preview-stage"><CreativePreviewFrame preview={creative.preview} previewBorder={creative.previewBorder} previewError={creative.previewError} iframeRef={setPreviewIframeRef(creative.id)} /></div><div className="summary-grid"><SummaryBox value={creativeSummary.pass} label="Passed" detail={`${Math.round((creativeSummary.pass / creativeSummary.total) * 100)}% of checks`} variant="pass" /><SummaryBox value={creativeSummary.warning} label="Warning" detail={`${Math.round((creativeSummary.warning / creativeSummary.total) * 100)}% of checks`} variant="warning" /><SummaryBox value={creativeSummary.fail} label="Errors" detail={`${Math.round((creativeSummary.fail / creativeSummary.total) * 100)}% of checks`} variant="fail" /><SummaryBox value={creativeSummary.info} label="Info" detail={`${Math.round((creativeSummary.info / creativeSummary.total) * 100)}% of checks`} variant="info" /></div><div className="result-columns"><div className="result-column"><h3>Checklist</h3><div className="result-list">{standardResults.map((result, index) => <ChecklistResultRow key={validationResultKey(result, index)} result={result} />)}</div></div><div className="result-column"><h3>Additional checks</h3><div className="result-list">{optionalResults.map((result, index) => <ChecklistResultRow key={validationResultKey(result, index)} result={result} />)}</div></div></div></section>}
                </div>
              </details>
            );
          })}
        </main>
        <footer className="app-footer">HTML5 Ad Validator <span>•</span> Secure, local-first creative validation</footer>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white px-5 py-10 text-[#181445]">
      <div className="mx-auto max-w-[1210px]">
        <header className="mb-10 border-b border-[#CFC2D4] pb-8">
          <h1 className="max-w-3xl text-4xl font-semibold leading-[0.98] text-[#181445] md:text-5xl">HTML5 Ad Validator</h1>
          <p className="mt-5 max-w-xl text-lg leading-7 text-[#6B7280]">Check your HTML5 ad creative for package, asset, runtime, and delivery issues.</p>
        </header>

        <section className="mb-6 rounded-lg bg-[#DAD6FF] p-4 shadow-[0_12px_30px_rgba(24,20,69,0.06)]">
          <label htmlFor="validation-profile" className="text-xs font-bold uppercase tracking-[0.16em] text-[#500088]">
            Validation Profile
          </label>
          <div className="mt-3 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <select
              id="validation-profile"
              value={profile.id}
              onChange={(event) => {
                const nextProfile = validationProfiles.find((item) => item.id === event.target.value);
                if (nextProfile) setProfile(nextProfile);
              }}
              className="w-full rounded-md border border-[#6B7280] bg-white px-4 py-3 text-sm font-semibold text-[#181445] disabled:cursor-not-allowed disabled:text-[#7E7383] md:max-w-xs"
            >
              {validationProfiles.map((item) => (
                <option key={item.id} value={item.id}>{item.name}</option>
              ))}
            </select>
            {profile.description && (
              <p className="text-sm leading-6 text-[#6B7280]">
                {profile.description}
              </p>
            )}
          </div>
        </section>

        {/* Upload Area */}
        <section className="mt-4 rounded-lg bg-[#DAD6FF] p-4 shadow-[0_18px_45px_rgba(24,20,69,0.08)]">
          <div
            onDrop={handleDrop}
            onDragOver={(event) => event.preventDefault()}
            onClick={() => inputRef.current?.click()}
            className="flex min-h-[420px] cursor-pointer flex-col items-center justify-center rounded-md border-2 border-dashed border-[#6B7280] bg-[#E9E5FF] px-6 text-center transition hover:border-[#500088]"
          >
            <input
              ref={inputRef}
              type="file"
              accept=".zip,application/zip"
              multiple
              className="hidden"
              onChange={(event) => {
                if (event.target.files) {
                  handleSelectFiles(event.target.files);
                }
              }}
            />

            <UploadIcon />

            <h2 className="mt-8 text-3xl font-semibold text-[#181445] md:text-4xl">
              {filename ?? "Drop your HTML5 creatives here"}
            </h2>

            <p className="mt-3 text-base text-[#6B7280]">
              Drop a ZIP archive · Maximum size 10 MB
            </p>

            {filename && (
              <p className="mt-2 text-sm text-[#7E7383]">
                Click here to choose another ZIP file
              </p>
            )}

            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                void runValidation();
              }}
              disabled={loading}
              className="mt-8 rounded-full bg-[#FCDF46] px-9 py-4 text-lg font-bold text-[#726200] shadow-[0_14px_30px_rgba(80,0,136,0.16)] transition hover:bg-[#f4d51f] focus:outline-none focus:ring-4 focus:ring-[#500088]/25 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? "Validating..." : "Run Validation"}
            </button>
          </div>
        </section>

        {/* Error */}
        {error && (
          <div className="mt-6 rounded-md border border-red-200 bg-red-50 p-4 text-red-700 shadow-[0_12px_28px_rgba(24,20,69,0.06)]">
            {error}
          </div>
        )}

        {selectedFile && (
          <section className="mt-8 overflow-hidden rounded-lg bg-white shadow-[0_18px_45px_rgba(24,20,69,0.08)]">
            <div className="grid border-b border-[#CFC2D4] text-sm md:grid-cols-2">
              <MetadataRow label="Name" value={filename ?? "-"} />
              <MetadataRow label="File Size" value={formatBytes(selectedFile?.size ?? 0)} />
              <MetadataRow label="Timestamp" value="Just now" />
              <MetadataRow label="Dimensions" value={displayDimensions ?? "-"} />
              <MetadataRow label="Scanned By" value="Local validator" />
              <MetadataRow label="Creative Type" value="HTML5 Zip" />
              <MetadataRow
                label="Result"
                value={results.length ? failedCount ? `${failedCount} TEST${failedCount === 1 ? "" : "S"} FAILED` : "PASSED" : "Not scanned"}
                tone={results.length ? failedCount ? "fail" : "pass" : "neutral"}
              />
              <MetadataRow label="Profile" value={profile.name} />
            </div>

          </section>
        )}

        {/* Loading Results */}
        {loading && (
          <section
            className="mt-12 overflow-hidden rounded-lg bg-[#DAD6FF] shadow-[0_18px_45px_rgba(24,20,69,0.08)]"
            aria-live="polite"
            aria-busy="true"
          >
            <div className="border-b border-[#CFC2D4] px-7 py-6">
              <p className="text-sm font-bold uppercase tracking-[0.16em] text-[#500088]">
                Validation in progress
              </p>

              <h2 className="mt-2 text-3xl font-semibold text-[#181445]">
                {filename ?? "Preparing creative"}
              </h2>
            </div>

            <div className="flex flex-col items-center justify-center gap-5 bg-[#E9E5FF] px-6 py-14 text-center">
              <div className="h-14 w-14 animate-spin rounded-full border-4 border-[#CFC2D4] border-t-[#500088]" />

              <div>
                <p className="text-lg font-semibold text-[#181445]">
                  Running validation checks...
                </p>

                <p className="mt-2 max-w-xl text-sm leading-6 text-[#6B7280]">
                  Inspecting package files, shared resources, runtime requests, console errors, rendering, and landing-page behavior.
                </p>
              </div>

              <div className="grid w-full max-w-3xl gap-3 text-left md:grid-cols-3">
                <LoadingStep label="Static rules" />
                <LoadingStep label="Runtime analysis" />
                <LoadingStep label="Report summary" />
              </div>
            </div>
          </section>
        )}

        {/* Validation Results */}
        {!loading && results.length > 0 && (
          <section className="mt-12 overflow-hidden rounded-lg bg-[#DAD6FF] shadow-[0_18px_45px_rgba(24,20,69,0.08)]">

            {/* Result Header */}
            <div className="border-b border-[#CFC2D4] px-7 py-6">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="text-sm font-bold uppercase tracking-[0.16em] text-[#500088]">
                    HTML5 Validation Results
                  </p>

                  <h2 className="mt-2 text-3xl font-semibold text-[#181445]">
                    {filename}
                  </h2>
                </div>

                <div className="rounded-full bg-[#E9E5FF] px-4 py-2 text-sm font-semibold text-[#6B7280]">
                  {summary.total} checks completed
                </div>
                <button type="button" onClick={() => void downloadReport()} className="rounded-full border border-[#6B7280] bg-[#E9E5FF] px-4 py-2 text-sm font-semibold text-[#181445] transition hover:border-[#500088] hover:text-[#500088] focus:outline-none focus:ring-2 focus:ring-[#500088]/30">
                  Download PDF
                </button>
              </div>
            </div>

            <div className="bg-[linear-gradient(45deg,#f5f5f5_25%,transparent_25%),linear-gradient(-45deg,#f5f5f5_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#f5f5f5_75%),linear-gradient(-45deg,transparent_75%,#f5f5f5_75%)] bg-[length:20px_20px] bg-[position:0_0,0_10px,10px_-10px,-10px_0] px-6 py-10">
              <CreativePreviewFrame preview={preview} previewBorder={previewBorder} previewError={previewError} />
            </div>

            {/* Summary */}
            <div className="grid grid-cols-1 gap-0 border-b border-[#CFC2D4] sm:grid-cols-2 lg:grid-cols-4">
              <SummaryBox
                value={summary.pass}
                label="Passed"
                variant="pass"
              />

              <SummaryBox
                value={summary.warning}
                label="Warnings"
                variant="warning"
              />

              <SummaryBox
                value={summary.fail}
                label="Failed"
                variant="fail"
              />

              <SummaryBox value={summary.info} label="Info" variant="info" />
            </div>

            {/* Results */}
            <div className="grid gap-x-6 bg-white p-4 md:grid-cols-2 xl:grid-cols-3">
              {results.map((result, index) => (
                <ChecklistResultRow
                  key={validationResultKey(result, index)}
                  result={result}
                />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function UploadIcon() {
  return (
    <div className="relative flex h-28 w-40 items-center justify-center">
      <div className="absolute left-2 top-8 h-16 w-11 -rotate-[10deg] rounded-md border-[6px] border-[#181445] bg-[#DAD6FF]" />

      <div className="absolute right-2 top-8 h-16 w-11 rotate-[10deg] rounded-md border-[6px] border-[#181445] bg-[#DAD6FF]" />

      <div className="relative z-10 flex h-28 w-24 items-center justify-center rounded-lg border-[9px] border-[#181445] bg-[#DAD6FF] shadow-[0_18px_32px_rgba(24,20,69,0.10)]">
        <span className="text-6xl font-bold leading-none text-[#500088]">
          +
        </span>
      </div>
    </div>
  );
}

function Icon({ name }: { name: string }) {
  const paths: Record<string, string> = { grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z", upload: "M12 16V4m0 0L7 9m5-5 5 5M4 20h16", clock: "M12 7v5l3 2m6-2a9 9 0 1 1-18 0 9 9 0 0 1 18 0", settings: "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm7.4-3.5 1.1-.8-1.8-3-1.3.5a7 7 0 0 0-1.2-.7L16 6.6h-3.5l-.2 1.4c-.4.2-.8.4-1.2.7l-1.3-.5-1.8 3 1.1.8a7 7 0 0 0 0 1.4l-1.1.8 1.8 3 1.3-.5c.4.3.8.5 1.2.7l.2 1.4H16l.2-1.4c.4-.2.8-.4 1.2-.7l1.3.5 1.8-3-1.1-.8a7 7 0 0 0 0-1.4Z", link: "M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1.2 1.2M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1.2-1.2", users: "M16 20v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m8-10a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm6-3a3 3 0 0 1 0 6m4 7v-2a4 4 0 0 0-3-3", moon: "M20 15.3A8 8 0 0 1 8.7 4 8 8 0 1 0 20 15.3Z", sun: "M12 3v2m0 14v2M4.2 4.2l1.4 1.4m12.8 12.8 1.4 1.4M3 12h2m14 0h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0", help: "M9.1 9a3 3 0 1 1 5.7 1.3c-.8 1-2.8 1.4-2.8 3.2M12 17h.01M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0", plus: "M12 5v14M5 12h14", folder: "M3 6h6l2 2h10v10H3z", check: "m5 12 4 4L19 6", arrow: "M5 12h14m-6-6 6 6-6 6" };
  return <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name] ?? paths.help} /></svg>;
}

function PatternIcon() {
  return <svg viewBox="0 0 360 300" className="pattern-icon" aria-hidden="true"><path d="M40 30h75v75H40zM155 30h75v75h-75zM270 30h75v75h-75zM98 145h75v75H98zM213 145h75v75h-75zM40 260h75v75H40zM270 260h75v75h-75z" fill="none" stroke="currentColor" strokeWidth="2" /><path d="m115 105 38 40m75-40-38 40m-77 75 38 40m77-40-38 40m77-40 38 40" stroke="currentColor" strokeWidth="2" /></svg>;
}

function SummaryBox({
  value,
  label,
  detail,
  variant,
}: {
  value: number;
  label: string;
  detail?: string;
  variant: "pass" | "warning" | "fail" | "info";
}) {
  const styles = {
    pass: {
      text: "text-green-700",
      iconBackground: "bg-green-100",
      background: "bg-green-50",
      border: "border-green-100",
      semantic: "summary-box--pass",
      icon: "✓",
    },

    warning: {
      text: "text-yellow-700",
      iconBackground: "bg-yellow-100",
      background: "bg-yellow-50",
      border: "border-yellow-100",
      semantic: "summary-box--warning",
      icon: "!",
    },

    fail: {
      text: "text-red-700",
      iconBackground: "bg-red-100",
      background: "bg-red-50",
      border: "border-red-100",
      semantic: "summary-box--fail",
      icon: "×",
    },

    info: {
      text: "text-[#181445]",
      iconBackground: "bg-blue-100",
      background: "bg-[#E9E5FF]",
      border: "border-[#CFC2D4]",
      semantic: "summary-box--info",
      icon: "i",
    },
  };

  const style = styles[variant];

  return (
    <div
      className={`
        flex
        items-center
        justify-center
        gap-4
        border-r
        p-7
        last:border-r-0
        ${style.background}
        ${style.border}
        ${style.semantic}
      `}
    >
      <div
        className={`
          summary-box__icon
          flex
          h-11
          w-11
          items-center
          justify-center
          rounded-full
          ${style.iconBackground}
          text-xl
          font-bold
          shadow-sm
          ${style.text}
        `}
      >
        {style.icon}
      </div>

      <div className="summary-copy">
        <div
          className={`
            summary-box__value
            text-3xl
            font-bold
            ${style.text}
          `}
        >
          {value}
        </div>

        <div className="summary-box__label text-sm font-medium text-[#6B7280]">
          {label}
        </div>

        {detail && <div className="summary-detail">{detail}</div>}
      </div>
    </div>
  );
}

function LoadingStep({ label }: { label: string }) {
  return (
    <div className="rounded-md bg-white/70 px-4 py-3 shadow-[0_8px_20px_rgba(24,20,69,0.04)]">
      <div className="mb-3 h-1.5 overflow-hidden rounded-full bg-[#CFC2D4]">
        <div className="h-full w-1/2 animate-pulse rounded-full bg-[#FCDF46]" />
      </div>

      <p className="text-sm font-semibold text-[#181445]">
        {label}
      </p>
    </div>
  );
}

function MetadataRow({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "pass" | "fail";
}) {
  const toneClass = tone === "fail" ? "metadata-value--fail text-red-600" : tone === "pass" ? "metadata-value--pass text-green-700" : "metadata-value--neutral text-[#181445]";

  return (
    <div className="grid grid-cols-[140px_1fr] border-b border-[#E5E0EA] px-3 py-2 last:border-b-0 md:[&:nth-last-child(-n+2)]:border-b-0">
      <dt className="text-[#181445]">
        {label}
      </dt>
      <dd className={`metadata-value font-bold ${toneClass}`}>
        {value}
      </dd>
    </div>
  );
}

function CreativePreviewFrame({
  preview,
  previewBorder,
  previewError,
  iframeRef,
}: {
  preview: CreativePreview | null;
  previewBorder: PreviewBorderResult | null;
  previewError: string | null;
  iframeRef?: (node: HTMLIFrameElement | null) => void;
}) {
  const width = preview?.width ?? 300;
  const height = preview?.height ?? 250;

  return (
    <div className="mx-auto flex max-w-4xl flex-col items-center">
      <div className="grid grid-cols-[auto_1fr] items-end gap-x-4">
        <div className="hidden w-10 md:block" />

        <div
          className="preview-measure preview-measure--width relative mb-4 grid grid-cols-[1fr_auto_1fr] items-center gap-3 text-sm font-bold text-[#181445]"
          style={{ width }}
        >
          <span className="preview-measure__cap absolute left-0 top-1/2 h-5 -translate-y-1/2 border-l border-[#6B7280]" />
          <span className="preview-measure__line h-px border-t border-dashed border-[#6B7280]" />
          <span>{width} px</span>
          <span className="preview-measure__line h-px border-t border-dashed border-[#6B7280]" />
          <span className="preview-measure__cap absolute right-0 top-1/2 h-5 -translate-y-1/2 border-l border-[#6B7280]" />
        </div>

        <div
          className="relative hidden w-10 flex-col items-center justify-center md:flex"
          style={{ height }}
        >
          <span className="preview-measure__cap absolute left-1/2 top-0 w-5 -translate-x-1/2 border-t border-[#6B7280]" />
          <span className="preview-measure__line flex-1 border-l border-dashed border-[#6B7280]" />
          <span className="preview-measure my-2 text-sm font-bold leading-tight text-[#181445]">{height}<br />px</span>
          <span className="preview-measure__line flex-1 border-l border-dashed border-[#6B7280]" />
          <span className="preview-measure__cap absolute bottom-0 left-1/2 w-5 -translate-x-1/2 border-t border-[#6B7280]" />
        </div>

        <div
          className="overflow-hidden bg-white shadow-[0_12px_28px_rgba(24,20,69,0.16)]"
          style={{
            width,
            height,
          }}
        >
          {preview ? (
            <iframe
              ref={iframeRef}
              title="Uploaded creative preview"
              srcDoc={preview.html}
              sandbox="allow-popups allow-popups-to-escape-sandbox allow-scripts"
              className="origin-top-left border-0"
              style={{
                width,
                height,
              }}
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center px-6 text-center text-sm font-semibold text-[#6B7280]">
              {previewError ?? "Preparing preview..."}
            </div>
          )}
        </div>
      </div>

      {preview && (
        <div className={`mt-4 rounded-full px-4 py-2 text-sm font-semibold ${previewBorder?.detected ? "bg-green-50 text-green-700" : "bg-yellow-50 text-yellow-700"}`}>
          {previewBorder
            ? previewBorder.detected
              ? `Preview border detected${previewBorder.element ? ` on ${previewBorder.element}` : ""}.`
              : "No preview border detected inside the iframe."
            : "Checking preview border..."}
        </div>
      )}
    </div>
  );
}

function ChecklistResultRow({
  result,
}: {
  result: ValidationResult;
}) {
  const styles = {
    pass: {
      icon: "✓",
      row: "bg-white",
      iconStyle: "bg-green-100 text-green-700",
      value: "text-[#181445]",
      semantic: "result-row--pass",
    },

    warning: {
      icon: "!",
      row: "bg-[#FCDF46]/20",
      iconStyle: "bg-yellow-100 text-yellow-700",
      value: "text-yellow-700",
      semantic: "result-row--warning",
    },

    fail: {
      icon: "×",
      row: "bg-red-50",
      iconStyle: "bg-red-100 text-red-700",
      value: "text-red-600",
      semantic: "result-row--fail",
    },

    info: {
      icon: "○",
      row: "bg-white",
      iconStyle: "text-[#7E7383]",
      value: "text-[#181445]",
      semantic: "result-row--info",
    },
  };

  const style = styles[result.status];
  const label = checklistLabel(result);
  const value = checklistValue(result);

  return (
    <details className={`result-row group border-b border-[#E5E0EA] ${style.row} ${style.semantic}`}>
      <summary className="flex cursor-pointer list-none items-center gap-2 px-2 py-2 text-sm marker:content-none">
        <span className={`result-row__icon flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-sm font-bold ${style.iconStyle}`}>
          {style.icon}
        </span>
        <span className="result-row__label min-w-0 flex-1 truncate text-[#181445]">
          {label}
        </span>
        <span className={`result-row__value min-w-0 font-bold ${style.value}`} title={String(value)}>
          {String(value)}
        </span>
      </summary>

      <div className="result-row__details px-9 pb-3 text-xs leading-5 text-[#6B7280]">
        <p>{result.message}</p>
        {result.expected !== undefined && (
          <p className="mt-1">Expected: <span className="result-row__expected font-semibold text-[#181445]">{String(result.expected)}</span></p>
        )}
        {result.recommendation && (
          <p className="result-row__recommendation mt-2 text-[#726200]">{result.recommendation}</p>
        )}
        {result.files && result.files.length > 0 && (
          <p className="mt-2 font-mono">{result.files.slice(0, 4).join(", ")}{result.files.length > 4 ? "..." : ""}</p>
        )}
      </div>
    </details>
  );
}

function validationResultKey(result: ValidationResult, index: number): string {
  return `${result.ruleId}-${index}`;
}

async function buildZipPreview(file: File): Promise<CreativePreview> {
  const zip = await JSZip.loadAsync(file);
  const entries = Object.values(zip.files).filter((entry) => !entry.dir && !isIgnoredPreviewPath(entry.name));
  const indexEntry = entries.find((entry) => entry.name.toLowerCase() === "index.html")
    ?? entries.find((entry) => entry.name.toLowerCase().endsWith("/index.html"))
    ?? entries.find((entry) => entry.name.toLowerCase().endsWith(".html"));

  if (!indexEntry) {
    throw new Error("No HTML file found in ZIP.");
  }

  const indexPath = normalizeZipPath(indexEntry.name);
  const assetUrls = new Map<string, string>();
  const cssEntries: Array<{ path: string; content: string }> = [];
  const jsEntries: Array<{ path: string; content: string }> = [];

  for (const entry of entries) {
    const path = normalizeZipPath(entry.name);

    if (path === indexPath) {
      continue;
    }

    if (path.toLowerCase().endsWith(".css")) {
      cssEntries.push({ path, content: await entry.async("text") });
    } else if (/\.m?js$/i.test(path)) {
      jsEntries.push({ path, content: await entry.async("text") });
    } else {
      const base64 = await entry.async("base64");
      assetUrls.set(path, `data:${mimeTypeFor(path)};base64,${base64}`);
    }
  }

  for (const cssEntry of cssEntries) {
    const resolveUrl = createPreviewResolver(assetUrls, cssEntry.path);
    const rewrittenCss = rewriteCssUrls(cssEntry.content, resolveUrl, getDirectory(cssEntry.path));
    assetUrls.set(cssEntry.path, `data:text/css;charset=utf-8,${encodeURIComponent(rewrittenCss)}`);
  }

  for (const jsEntry of jsEntries) {
    const resolveUrl = createPreviewResolver(assetUrls, jsEntry.path);
    const rewrittenJs = rewriteJsUrls(jsEntry.content, resolveUrl, getDirectory(jsEntry.path));
    assetUrls.set(jsEntry.path, `data:text/javascript;charset=utf-8,${encodeURIComponent(rewrittenJs)}`);
  }

  const html = await indexEntry.async("text");
  const dimensions = detectHtmlDimensions(html);
  const rewrittenHtml = prepareHtmlForPreview(html, indexPath, assetUrls);

  return {
    html: rewrittenHtml,
    width: dimensions?.width,
    height: dimensions?.height,
  };
}

function prepareHtmlForPreview(html: string, entryPath: string, assetUrls: Map<string, string>): string {
  const documentNode = new DOMParser().parseFromString(html, "text/html");
  const resolveUrl = createPreviewResolver(assetUrls, entryPath);

  documentNode
    .querySelectorAll('meta[http-equiv="content-security-policy" i]')
    .forEach((element) => element.remove());

  for (const attribute of ["src", "href", "poster", "data"]) {
    documentNode.querySelectorAll<HTMLElement>(`[${attribute}]`).forEach((element) => {
      const value = element.getAttribute(attribute);
      if (value) element.setAttribute(attribute, resolveUrl(value));
    });
  }

  documentNode.querySelectorAll<HTMLElement>("[srcset]").forEach((element) => {
    const value = element.getAttribute("srcset");
    if (value) element.setAttribute("srcset", rewriteSrcSet(value, resolveUrl));
  });

  documentNode.querySelectorAll<HTMLStyleElement>("style").forEach((element) => {
    element.textContent = rewriteCssUrls(element.textContent ?? "", resolveUrl, getDirectory(entryPath));
  });

  documentNode.querySelectorAll<HTMLElement>("[style]").forEach((element) => {
    const value = element.getAttribute("style");
    if (value) element.setAttribute("style", rewriteCssUrls(value, resolveUrl, getDirectory(entryPath)));
  });

  const resetStyle = documentNode.createElement("style");
  resetStyle.dataset.creativePreview = "reset";
  resetStyle.textContent = "html,body{width:100%;height:100%;margin:0;overflow:hidden;}";
  documentNode.head.prepend(resetStyle);

  const runtimeBridge = documentNode.createElement("script");
  runtimeBridge.dataset.creativePreview = "runtime";
  runtimeBridge.textContent = buildPreviewRuntimeBridge(assetUrls, entryPath);
  documentNode.head.prepend(runtimeBridge);

  return `<!DOCTYPE html>\n${documentNode.documentElement.outerHTML}`;
}

function createPreviewResolver(assetUrls: Map<string, string>, entryPath: string) {
  const entryDirectory = getDirectory(entryPath);
  const caseInsensitiveAssetUrls = new Map<string, string>();

  assetUrls.forEach((url, path) => {
    const normalizedPath = path.toLowerCase();
    if (!caseInsensitiveAssetUrls.has(normalizedPath)) {
      caseInsensitiveAssetUrls.set(normalizedPath, url);
    }
  });

  return (value: string, baseDirectory = entryDirectory): string => {
    const trimmed = value.trim();
    if (!trimmed || isExternalOrSpecialUrl(trimmed)) {
      return value;
    }

    const [path, suffix] = splitPreviewUrlSuffix(trimmed);
    const resolvedPath = resolvePreviewPath(path, baseDirectory);
    const directPath = resolvePreviewPath(path, "");
    const resolvedUrl = assetUrls.get(resolvedPath)
      ?? assetUrls.get(directPath)
      ?? caseInsensitiveAssetUrls.get(resolvedPath.toLowerCase())
      ?? caseInsensitiveAssetUrls.get(directPath.toLowerCase());

    if (!resolvedUrl) {
      return value;
    }

    return `${resolvedUrl}${getSafePreviewSuffix(suffix)}`;
  };
}

function rewriteCssUrls(css: string, resolveUrl: (value: string, baseDirectory?: string) => string, baseDirectory: string): string {
  return css.replace(/url\(\s*(['"]?)(.*?)\1\s*\)/gi, (match, _quote: string, value: string) => {
    const resolved = resolveUrl(value, baseDirectory);
    return resolved === value ? match : `url("${resolved}")`;
  });
}

function rewriteSrcSet(srcSet: string, resolveUrl: (value: string) => string): string {
  return srcSet
    .split(",")
    .map((candidate) => {
      const [url, ...descriptor] = candidate.trim().split(/\s+/);
      return [resolveUrl(url), ...descriptor].join(" ");
    })
    .join(", ");
}

function rewriteJsUrls(source: string, resolveUrl: (value: string, baseDirectory?: string) => string, baseDirectory: string): string {
  return source.replace(/(['"])([^'"\r\n]+)\1/g, (match, quote: string, value: string) => {
    const resolved = resolveUrl(value, baseDirectory);
    return resolved === value ? match : `${quote}${resolved}${quote}`;
  });
}

function buildPreviewRuntimeBridge(assetUrls: Map<string, string>, entryPath: string): string {
  const assetMap = Object.fromEntries(assetUrls);
  const caseInsensitiveAssetMap = Object.fromEntries(Array.from(assetUrls, ([path, url]) => [path.toLowerCase(), url]));
  const serializedAssets = JSON.stringify(assetMap).replaceAll("<", "\\u003c");
  const serializedCaseInsensitiveAssets = JSON.stringify(caseInsensitiveAssetMap).replaceAll("<", "\\u003c");
  const serializedEntryDirectory = JSON.stringify(getDirectory(entryPath)).replaceAll("<", "\\u003c");

  return `
    (() => {
      const assets = ${serializedAssets};
      const caseInsensitiveAssets = ${serializedCaseInsensitiveAssets};
      const entryDirectory = ${serializedEntryDirectory};
      const externalUrl = /^(?:[a-z][a-z\\d+.-]*:|\\/\\/|#)/i;
      const cleanDataUrl = (value) => {
        if (typeof value !== "string" || !value.toLowerCase().startsWith("data:")) return value;
        const queryIndex = value.indexOf("?");
        if (queryIndex < 0) return value;
        const fragmentIndex = value.indexOf("#", queryIndex);
        return value.slice(0, queryIndex) + (fragmentIndex < 0 ? "" : value.slice(fragmentIndex));
      };
      const normalize = (path) => {
        try {
          return decodeURIComponent(new URL(path, "https://preview.invalid/").pathname.slice(1));
        } catch {
          return path;
        }
      };
      const resolveAsset = (value) => {
        if (typeof value !== "string" || !value) return value;
        if (value.toLowerCase().startsWith("data:")) return cleanDataUrl(value);
        if (externalUrl.test(value)) return value;
        const suffixIndex = value.search(/[?#]/);
        const path = suffixIndex < 0 ? value : value.slice(0, suffixIndex);
        const suffix = suffixIndex < 0 ? "" : value.slice(suffixIndex);
        const resolvedPath = normalize(entryDirectory + path);
        const directPath = normalize(path);
        const asset = assets[resolvedPath] || assets[directPath] || caseInsensitiveAssets[resolvedPath.toLowerCase()] || caseInsensitiveAssets[directPath.toLowerCase()];
        if (!asset) {
          return value;
        }
        const fragmentIndex = suffix.indexOf("#");
        return asset + (fragmentIndex < 0 ? "" : suffix.slice(fragmentIndex));
      };
      const resolveCssUrls = (value) => typeof value === "string"
        ? value.replace(/url\\(\\s*(['"]?)(.*?)\\1\\s*\\)/gi, (match, _quote, url) => {
            const resolved = resolveAsset(url);
            return resolved === url ? match : 'url("' + resolved + '")';
          })
        : value;
      const patchProperty = (prototype, property, transform = resolveAsset) => {
        if (!prototype) return;
        const descriptor = Object.getOwnPropertyDescriptor(prototype, property);
        if (!descriptor || !descriptor.set) return;
        Object.defineProperty(prototype, property, {
          ...descriptor,
          set(value) { descriptor.set.call(this, transform(value)); },
        });
      };
      [
        [window.HTMLImageElement && window.HTMLImageElement.prototype, "src"],
        [window.HTMLScriptElement && window.HTMLScriptElement.prototype, "src"],
        [window.HTMLSourceElement && window.HTMLSourceElement.prototype, "src"],
        [window.HTMLMediaElement && window.HTMLMediaElement.prototype, "src"],
        [window.HTMLVideoElement && window.HTMLVideoElement.prototype, "poster"],
        [window.HTMLLinkElement && window.HTMLLinkElement.prototype, "href"],
      ].forEach(([prototype, property]) => patchProperty(prototype, property));
      ["background", "backgroundImage", "cssText"].forEach((property) =>
        patchProperty(window.CSSStyleDeclaration && window.CSSStyleDeclaration.prototype, property, resolveCssUrls)
      );
      const nativeSetProperty = window.CSSStyleDeclaration && window.CSSStyleDeclaration.prototype.setProperty;
      if (nativeSetProperty) {
        window.CSSStyleDeclaration.prototype.setProperty = function(property, value, priority) {
          return nativeSetProperty.call(this, property, resolveCssUrls(value), priority);
        };
      }
      const nativeSetAttribute = Element.prototype.setAttribute;
      Element.prototype.setAttribute = function(name, value) {
        const normalizedName = String(name).toLowerCase();
        const nextValue = normalizedName === "style"
          ? resolveCssUrls(String(value))
          : ["src", "href", "poster", "data"].includes(normalizedName)
            ? resolveAsset(String(value))
            : value;
        return nativeSetAttribute.call(this, name, nextValue);
      };
      const report = (type, detail) => window.parent.postMessage({
        source: "html5-ad-validator-preview",
        type,
        detail,
      }, "*");
      const detectBorder = () => {
        const candidates = [
          document.querySelector("#exitButton"),
          document.body,
          document.documentElement,
          document.querySelector("#ad"),
          document.querySelector("#container"),
          document.querySelector("#main"),
          document.querySelector("#mainContent"),
          document.querySelector(".ad"),
          document.querySelector(".container"),
          document.querySelector(".main"),
          document.querySelector(".mainContent"),
        ].filter(Boolean);
        for (const element of candidates) {
          const style = getComputedStyle(element);
          const widths = [
            style.borderTopWidth,
            style.borderRightWidth,
            style.borderBottomWidth,
            style.borderLeftWidth,
          ].map((value) => Number.parseFloat(value));
          const styles = [
            style.borderTopStyle,
            style.borderRightStyle,
            style.borderBottomStyle,
            style.borderLeftStyle,
          ];
          const detected = widths.some((width) => width > 0)
            && styles.some((borderStyle) => borderStyle !== "none" && borderStyle !== "hidden");
          if (detected) {
            return {
              detected: true,
              method: "css-border",
              element: element === document.documentElement ? "html" : element === document.body ? "body" : element.tagName.toLowerCase(),
            };
          }
        }
        return { detected: false, method: "unknown" };
      };
      const reportBorder = () => report("preview-border", detectBorder());
      if (document.readyState === "complete" || document.readyState === "interactive") {
        reportBorder();
      } else {
        window.addEventListener("DOMContentLoaded", reportBorder, { once: true });
      }
      window.addEventListener("load", () => window.setTimeout(reportBorder, 250), { once: true });
      window.setTimeout(reportBorder, 1000);
    })();
  `;
}

function detectHtmlDimensions(html: string): { width: number; height: number } | null {
  const adSizeMatch = html.match(/content=["'][^"']*width\s*=\s*(\d+)\s*,\s*height\s*=\s*(\d+)/i);

  if (adSizeMatch) {
    return { width: Number(adSizeMatch[1]), height: Number(adSizeMatch[2]) };
  }

  const cssSizeMatch = html.match(/width\s*:\s*(\d+)px[\s\S]*?height\s*:\s*(\d+)px/i);

  if (cssSizeMatch) {
    return { width: Number(cssSizeMatch[1]), height: Number(cssSizeMatch[2]) };
  }

  return null;
}

function resolvePreviewPath(value: string, baseDirectory: string): string {
  const [path] = splitPreviewUrlSuffix(value);
  const parts = `${baseDirectory}${path}`.split("/");
  const resolved: string[] = [];

  for (const part of parts) {
    if (!part || part === ".") {
      continue;
    }

    if (part === "..") {
      resolved.pop();
      continue;
    }

    resolved.push(part);
  }

  return resolved.join("/");
}

function splitPreviewUrlSuffix(value: string): [string, string] {
  const suffixIndex = value.search(/[?#]/);
  return suffixIndex < 0 ? [value, ""] : [value.slice(0, suffixIndex), value.slice(suffixIndex)];
}

function getSafePreviewSuffix(suffix: string): string {
  const fragmentIndex = suffix.indexOf("#");
  return fragmentIndex < 0 ? "" : suffix.slice(fragmentIndex);
}

function normalizeZipPath(path: string): string {
  return path.replace(/\\/g, "/").replace(/^\/+/, "");
}

function getDirectory(path: string): string {
  const index = path.lastIndexOf("/");

  return index >= 0 ? `${path.slice(0, index)}/` : "";
}

function isExternalOrSpecialUrl(value: string): boolean {
  return /^(?:[a-z][a-z\d+.-]*:|\/\/|#)/i.test(value);
}

function isIgnoredPreviewPath(path: string): boolean {
  const normalizedPath = normalizeZipPath(path);
  return normalizedPath.startsWith("__MACOSX/")
    || normalizedPath.split("/").some((part) => part === ".DS_Store" || part.startsWith("._"));
}

function mimeTypeFor(path: string): string {
  const extension = path.split(".").pop()?.toLowerCase();
  const mimeTypes: Record<string, string> = {
    css: "text/css",
    gif: "image/gif",
    html: "text/html",
    jpeg: "image/jpeg",
    jpg: "image/jpeg",
    js: "text/javascript",
    json: "application/json",
    mp3: "audio/mpeg",
    mp4: "video/mp4",
    otf: "font/otf",
    png: "image/png",
    svg: "image/svg+xml",
    webm: "video/webm",
    woff: "font/woff",
    woff2: "font/woff2",
  };

  return extension ? mimeTypes[extension] ?? "application/octet-stream" : "application/octet-stream";
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) {
    return `${bytes} B`;
  }

  if (bytes < 1024 * 1024) {
    return `${(bytes / 1024).toFixed(1)} KB`;
  }

  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

function formatDimensions(preview: CreativePreview | null): string | null {
  if (!preview?.width || !preview.height) {
    return null;
  }

  return `${preview.width}x${preview.height}`;
}

function getResultValue(results: ValidationResult[], ruleId: string): string | undefined {
  const value = results.find((result) => result.ruleId === ruleId)?.actual;

  return value === undefined ? undefined : String(value);
}
