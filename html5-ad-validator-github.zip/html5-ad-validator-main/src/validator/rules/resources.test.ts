import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { externalAssetsRule, missingAssetsRule, sslCompatibilityRule } from "./resources";

function context(html: string, files: Array<[string, string]> = [["index.html", html]]): CreativeContext {
  return {
    filename: "test.zip",
    compressedSize: 1,
    files: new Map(files.map(([path, content]) => [path, {
      path,
      content,
      size: content.length,
      extension: path.split(".").pop() ?? "",
    }])),
  };
}

describe("resource validation rules", () => {
  it("reports external resources as warnings and lists their source files", async () => {
    const result = await externalAssetsRule.run(context(
      '<script src="https://cdn.example.test/app.js"></script>',
    ));

    expect(result.status).toBe("warning");
    expect(result.details).toEqual({ resources: ["https://cdn.example.test/app.js"] });
    expect(result.files).toEqual(["index.html"]);
  });

  it("reports missing local assets resolved from HTML and CSS", async () => {
    const result = await missingAssetsRule.run(context(
      '<link rel="stylesheet" href="css/theme.css"><img src="images/missing.png">',
      [
        ["index.html", '<link rel="stylesheet" href="css/theme.css"><img src="images/missing.png">'],
        ["css/theme.css", "body { background: url(../fonts/missing.woff2); }"],
      ],
    ));

    expect(result.status).toBe("fail");
    expect(result.details).toEqual({ resources: ["images/missing.png", "fonts/missing.woff2"], commentedResources: [] });
  });

  it("reports only insecure HTTP resources", async () => {
    const result = await sslCompatibilityRule.run(context(
      '<script src="http://cdn.example.test/app.js"></script><img src="https://cdn.example.test/app.png">',
    ));

    expect(result.status).toBe("warning");
    expect(result.details).toEqual({ resources: ["http://cdn.example.test/app.js"] });
  });

  it("shares one cached inventory between rules", async () => {
    const creative = context('<img src="missing.png"><script src="http://cdn.example.test/app.js"></script>');

    await externalAssetsRule.run(creative);
    const inventory = creative.resources;
    await missingAssetsRule.run(creative);

    expect(creative.resources).toBe(inventory);
  });

  it("passes and ignores missing assets referenced only in comments", async () => {
    const result = await missingAssetsRule.run(context("<!-- <img src='old-banner.png'> -->"));

    expect(result.status).toBe("pass");
    expect(result.actual).toBe(0);
    expect(result.message).toContain("commented-out asset reference(s) were ignored");
    expect(result.details).toEqual({ resources: [], commentedResources: ["old-banner.png"] });
  });

  it("still fails active missing assets when commented references are also present", async () => {
    const result = await missingAssetsRule.run(context(
      "<img src='missing.png'><!-- <img src='old-banner.png'> -->",
    ));

    expect(result.status).toBe("fail");
    expect(result.actual).toBe(1);
    expect(result.details).toEqual({ resources: ["missing.png"], commentedResources: ["old-banner.png"] });
  });
});
