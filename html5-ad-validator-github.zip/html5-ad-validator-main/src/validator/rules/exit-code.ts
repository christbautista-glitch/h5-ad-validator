import type { ValidationRule } from "../types";

const EXIT_PATTERNS = [
  ["clickTag", /\bclickTag\b/i],
  ["window.clickTag", /\bwindow\.clickTag\b/i],
  ["Enabler.exit()", /\bEnabler\.exit\s*\(/i],
  ["Enabler.exitOverride()", /\bEnabler\.exitOverride\s*\(/i],
  ["window.open()", /\bwindow\.open\s*\(/i],
] as const;

export const exitCodeRule: ValidationRule = {
  id: "CLICK001",
  name: "Exit Code",
  description: "Detects common click-through and exit implementations.",
  category: "click",
  type: "static",
  async run(context) {
    const source = [...context.files.values()]
      .filter((file) => ["html", "htm", "js"].includes(file.extension))
      .map((file) => file.content ?? "")
      .join("\n");
    const detected = EXIT_PATTERNS.filter(([, pattern]) => pattern.test(source)).map(([name]) => name);

    return {
      ruleId: "CLICK001",
      title: "Exit Code",
      category: "click",
      status: detected.length ? "pass" : "warning",
      actual: detected.length ? detected.join(", ") : "Not detected",
      message: detected.length
        ? `Detected click implementation(s): ${detected.join(", ")}.`
        : "No common click or exit implementation was detected.",
      details: { implementations: detected },
      recommendation: detected.length ? undefined : "Add a platform-appropriate click-through implementation.",
    };
  },
};
