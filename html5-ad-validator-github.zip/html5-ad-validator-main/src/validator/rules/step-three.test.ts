import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { enablerRule } from "./enabler";
import { exitCodeRule } from "./exit-code";

function context(content: string): CreativeContext {
  return {
    filename: "test.zip",
    compressedSize: 1,
    files: new Map([["index.html", { path: "index.html", size: content.length, extension: "html", content }]]),
  };
}

describe("Step 3 rules", () => {
  it("reports common exit implementations without requiring one specific platform", async () => {
    const result = await exitCodeRule.run(context("<script>window.clickTag = 'https://example.test'; window.open(clickTag);</script>"));
    expect(result.status).toBe("pass");
    expect(result.details).toEqual({ implementations: ["clickTag", "window.clickTag", "window.open()"] });
  });

  it("warns when no exit implementation is found", async () => {
    const result = await exitCodeRule.run(context("<div>Creative</div>"));
    expect(result.status).toBe("warning");
  });

  it("does not fail creatives that do not use Enabler", async () => {
    const result = await enablerRule.run(context("<div>Creative</div>"));
    expect(result.status).toBe("info");
  });

  it("detects Enabler usage", async () => {
    const result = await enablerRule.run(context("<script>Enabler.exit('button');</script>"));
    expect(result.status).toBe("pass");
  });

  it("requires Enabler when configured by profile", async () => {
    const result = await enablerRule.run(context('<script src="https://s0.2mdn.net/ads/studio/Enabler.js"></script>'), {
      enabled: true,
      severity: "fail",
      thresholds: { requireEnabler: 1 },
    });

    expect(result.status).toBe("pass");
    expect(result.expected).toBe("index.html loads the Studio Enabler.js");
  });

  it("rejects Enabler when forbidden by profile", async () => {
    const result = await enablerRule.run(context('<script src="https://s0.2mdn.net/ads/studio/Enabler.js"></script>'), {
      enabled: true,
      severity: "fail",
      thresholds: { requireEnabler: 0 },
    });

    expect(result.status).toBe("fail");
    expect(result.expected).toBe("index.html does not load Enabler.js");
  });

  it("does not treat an Enabler API mention as an index.html script load", async () => {
    const result = await enablerRule.run(context("<script>Enabler.exit('button');</script>"), {
      enabled: true,
      severity: "fail",
      thresholds: { requireEnabler: 0 },
    });

    expect(result.status).toBe("pass");
  });

  it("reports a landing destination when runtime navigation is observed", async () => {
    const { landingPageRule } = await import("./runtime");
    const result = await landingPageRule.run({
      origin: "http://127.0.0.1:1234",
      runtimeStatus: "available", consoleErrors: [], pageErrors: [], requests: [], responses: [{ url: "https://landing.example.test", status: 200 }], requestFailures: [], images: [],
      rendered: true, navigationAttempts: ["https://landing.example.test"], popupAttempts: [], durationMs: 1,
    });
    expect(result.status).toBe("pass");
    expect(result.details).toMatchObject({ destinations: ["https://landing.example.test"], destinationStatuses: [{ url: "https://landing.example.test", status: 200 }] });
  });

  it("explains when no supported click target is available", async () => {
    const { landingPageRule } = await import("./runtime");
    const result = await landingPageRule.run({
      origin: "http://127.0.0.1:1234", runtimeStatus: "available", consoleErrors: [], pageErrors: [], requests: [], responses: [], requestFailures: [], images: [],
      rendered: true, navigationAttempts: [], popupAttempts: [], clickTargetFound: false, durationMs: 1,
    });
    expect(result.message).toContain("No supported clickable target");
  });
});
