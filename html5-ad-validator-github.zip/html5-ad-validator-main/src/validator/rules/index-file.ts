import type { ValidationRule } from "../types";

export const indexFileRule: ValidationRule = {
  id: "PKG001",

  name: "Index File Check",

  description:
    "Checks whether index.html exists at the root of the creative ZIP.",

  category: "package",

  type: "static",

  async run(context) {
    const indexFile = context.files.get("index.html");

    if (!indexFile) {
      return {
        ruleId: "PKG001",
        title: "Index File Check",
        category: "package",
        status: "fail",
        actual: false,
        expected: true,

        message:
          "index.html was not found at the root of the creative ZIP.",

        recommendation:
          "Add index.html to the root directory of the ZIP package."
      };
    }

    return {
      ruleId: "PKG001",
      title: "Index File Check",
      category: "package",
      status: "pass",
      actual: true,
      expected: true,

      message:
        "index.html was found at the root of the creative ZIP."
    };
  }
};