import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { studioHooksRule } from "./studio-hooks";

function context(files: Array<[string, string]>): CreativeContext {
  return {
    filename: "test.zip",
    compressedSize: 1,
    files: new Map(files.map(([path, content]) => [
      path,
      { path, size: content.length, extension: path.split(".").pop() ?? "", content },
    ])),
  };
}

const html5Files: Array<[string, string]> = [
  ["js/invocation.js", "var devDynamicContent = {}; AdLib.assignInvocationCode();"],
  ["vendor/adlib.min.js", "function localTimeline(){} function localTesting(){}"],
];

const html5Profile = {
  enabled: true,
  severity: "fail" as const,
  thresholds: { requireStudioHooks: 1 },
};

const gdnProfile = {
  enabled: true,
  severity: "fail" as const,
  thresholds: { requireStudioHooks: 0 },
};

describe("Studio / AdLib policy rule", () => {
  it("passes HTML5 Standard when the required hooks are in their expected files", async () => {
    const result = await studioHooksRule.run(context(html5Files), html5Profile);

    expect(result.status).toBe("pass");
  });

  it("fails HTML5 Standard when a required hook is missing", async () => {
    const result = await studioHooksRule.run(context([
      ["invocation.js", "var devDynamicContent = {}; AdLib.assignInvocationCode();"],
      ["adlib.min.js", "function localTimeline(){}"],
    ]), html5Profile);

    expect(result.status).toBe("fail");
    expect(result.message).toContain("localTesting in adlib.min.js");
  });

  it("passes GDN when Studio hooks and trace are absent", async () => {
    const result = await studioHooksRule.run(context([
      ["invocation.js", "function startCreative() {}"],
      ["adlib.min.js", "function start() {}"],
    ]), gdnProfile);

    expect(result.status).toBe("pass");
  });

  it("passes GDN with an internal runtime devDynamicContent reference and no trace", async () => {
    const result = await studioHooksRule.run(context([
      ["runtime.js", "window.devDynamicContent = window.devDynamicContent || {};"],
    ]), gdnProfile);

    expect(result.status).toBe("pass");
    expect(result.message).toContain("runtime.js contains an internal devDynamicContent reference");
    expect(result.message).toContain("No trace was found");
  });

  it("fails GDN when invocation.js contains prohibited Studio hooks", async () => {
    const result = await studioHooksRule.run(context([
      ["invocation.js", "var devDynamicContent = {}; AdLib.assignInvocationCode();"],
    ]), gdnProfile);

    expect(result.status).toBe("fail");
    expect(result.message).toContain("devDynamicContent in invocation.js");
    expect(result.message).toContain("AdLib.assignInvocationCode() in invocation.js");
  });

  it("fails GDN when trace is found in the checked files", async () => {
    const result = await studioHooksRule.run(context([
      ["runtime.js", "const trace = true;"],
    ]), gdnProfile);

    expect(result.status).toBe("fail");
    expect(result.message).toContain("Trace was found");
  });
});
