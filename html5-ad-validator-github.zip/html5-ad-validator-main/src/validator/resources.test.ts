import { describe, expect, it } from "vitest";
import { buildResourceGraph } from "./resources";
import type { CreativeContext } from "./context";

function context(files: Array<[string, string]>): CreativeContext {
  return { filename: "test.zip", compressedSize: 1, files: new Map(files.map(([path, content]) => [path, { path, content, size: content.length, extension: path.split(".").pop()! }])) };
}

describe("resource graph", () => {
  it("resolves relative HTML paths", () => {
    const resources = buildResourceGraph(context([["index.html", '<img src="images/photo.png">'], ["images/photo.png", ""]]));
    expect(resources[0].resolved).toBe("images/photo.png");
    expect(resources[0].location).toBe("local");
  });
  it("resolves parent paths from nested CSS", () => {
    const resources = buildResourceGraph(context([["css/theme.css", "body{background:url(../images/bg.jpg)}"], ["images/bg.jpg", "" ]]));
    expect(resources[0].resolved).toBe("images/bg.jpg");
  });
  it("classifies HTTP, HTTPS and protocol-relative URLs", () => {
    const resources = buildResourceGraph(context([["index.html", '<script src="http://a.test/a.js"></script><img src="https://a.test/a.png"><img src="//cdn.test/a.png">']]));
    expect(resources.map((r) => [r.location, r.protocol])).toEqual([["external", "http"], ["external", "https"], ["external", "protocol-relative"]]);
  });
  it("ignores data URLs, anchors and non-assets", () => {
    const resources = buildResourceGraph(context([["index.html", '<img src="data:image/png;base64,abc"><img src="#hero"><a href="http://landing.test">go</a>']]));
    expect(resources).toHaveLength(0);
  });

  it("retains resources inside HTML and CSS comments as commented references", () => {
    const resources = buildResourceGraph(context([
      ["index.html", "<!-- <img src='missing-html.png'> --><link rel='stylesheet' href='css/theme.css'>"],
      ["css/theme.css", "/* background: url(missing-css.png); */ body { color: black; }"]
    ]));

    expect(resources.map((resource) => [resource.resolved, resource.commented])).toEqual([
      ["missing-html.png", true],
      ["css/theme.css", false],
      ["css/missing-css.png", true],
    ]);
  });
});
