import { gdnProfile, GDN_PROFILE_ID } from "./gdn";
import { html5StandardProfile, HTML5_STANDARD_PROFILE_ID } from "./html5-standard";
import { validationProfileSchema } from "./schema";
import type { ValidationProfile, ValidationProfileMetadata } from "./types";

const validationProfiles: Record<string, ValidationProfile> = {
  [HTML5_STANDARD_PROFILE_ID]: html5StandardProfile,
  [GDN_PROFILE_ID]: gdnProfile,
};

for (const profile of Object.values(validationProfiles)) {
  validationProfileSchema.parse(profile);
}

export function getValidationProfile(id = HTML5_STANDARD_PROFILE_ID): ValidationProfile | undefined {
  return validationProfiles[id];
}

export function requireValidationProfile(id = HTML5_STANDARD_PROFILE_ID): ValidationProfile {
  const profile = getValidationProfile(id);

  if (!profile) {
    throw new Error(`Unknown validation profile: ${id}`);
  }

  return profile;
}

export function listValidationProfiles(): ValidationProfileMetadata[] {
  return Object.values(validationProfiles).map(({ id, name, description }) => ({ id, name, description }));
}

export function getDefaultValidationProfile(): ValidationProfile {
  return requireValidationProfile(HTML5_STANDARD_PROFILE_ID);
}
