export interface RuntimeRequest {
  url: string;
  method: string;
  resourceType?: string;
}

export interface RuntimeResponse {
  url: string;
  status: number;
  contentLength?: number;
  transferredBytes?: number;
  resourceType?: string;
  phase?: "initial" | "subload";
}

export interface RuntimeImageResult {
  url: string;
  complete: boolean;
  naturalWidth: number;
  naturalHeight: number;
}

export interface RuntimeContext {
  origin: string;
  runtimeStatus: "available" | "unavailable";
  consoleErrors: string[];
  consoleWarnings?: string[];
  pageErrors: string[];
  requests: RuntimeRequest[];
  responses: RuntimeResponse[];
  requestFailures: Array<{ url: string; errorText?: string; resourceType?: string; method?: string }>;
  dialogs?: Array<{ type: string; message: string }>;
  externalUrls?: string[];
  insecureUrls?: string[];
  images: RuntimeImageResult[];
  videos?: Array<{ url: string; paused: boolean; readyState: number; currentTime: number; error?: string; muted: boolean; autoplay: boolean }>;
  transferredBytes?: number;
  initialLoadBytes?: number;
  subloadBytes?: number;
  totalLoadBytes?: number;
  error?: string;
  rendered: boolean;
  navigationAttempts: string[];
  navigationResponses?: Array<{ url: string; status: number; isFinal?: boolean }>;
  popupAttempts: string[];
  clickTargetFound?: boolean;
  clickTarget?: string;
  visual?: {
    painted?: boolean;
    visualStartMs?: number;
    screenshotCaptured?: boolean;
    screenshotBytes?: number;
    creativeBorder?: {
      detected: boolean;
      method: "css-border" | "edge-pixels" | "unknown";
      element?: string;
    };
  };
  durationMs: number;
  animationDurationMs?: number;
  adBlockAffected?: boolean;
  cpuTimeMs?: number;
  memoryUsageMb?: number;
  measurementPixels?: number;
  timeToVisualStartMs?: number;
}

export interface RuntimeRule {
  id: string;
  name: string;
  category: "network" | "javascript" | "visual" | "click" | "performance" | "asset";
  run(context: RuntimeContext, ruleProfile?: ValidationRuleProfile): Promise<import("../types").ValidationResult>;
}
import type { ValidationRuleProfile } from "../profiles/types";
