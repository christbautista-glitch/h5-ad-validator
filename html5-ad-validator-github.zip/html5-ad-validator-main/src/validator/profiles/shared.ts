import type { ValidationProfile } from "./types";

const MB = 1024 * 1024;
const UNENFORCED_FILE_COUNT = Number.MAX_SAFE_INTEGER;
const UNENFORCED_IMAGE_BYTES = Number.MAX_SAFE_INTEGER;
const UNENFORCED_RUNTIME_DURATION_MS = Number.MAX_SAFE_INTEGER;
const UNENFORCED_RUNTIME_BYTES = Number.MAX_SAFE_INTEGER;

export const commonRuleProfiles = {
  ANIM001: { enabled: true, severity: "warning" },
  ANIM002: { enabled: true, severity: "warning", thresholds: { maxDurationMs: 10000 } },
  PKG001: { enabled: true },
  FILE001: { enabled: true, severity: "warning", thresholds: { maxFiles: UNENFORCED_FILE_COUNT } },
  SIZE001: { enabled: true, severity: "fail", thresholds: { maxBytes: 100 * MB } },
  HTML001: { enabled: true },
  HTML002: { enabled: true },
  HTML003: { enabled: true },
  MEDIA001: { enabled: true },
  MEDIA002: { enabled: true },
  NET002: { enabled: true, severity: "warning" },
  ASSET003: { enabled: true, severity: "warning", thresholds: { maxImageBytes: UNENFORCED_IMAGE_BYTES } },
  ASSET004: { enabled: true, severity: "fail" },
  SEC001: { enabled: true, severity: "warning" },
  CLICK001: { enabled: true, severity: "warning" },
  GWD001: { enabled: false },
  GWD002: { enabled: false },
  NET001: { enabled: true, severity: "fail" },
  JS001: { enabled: true, severity: "fail" },
  RENDER001: { enabled: true, severity: "fail" },
  VIS002: { enabled: true, severity: "warning" },
  VIS001: { enabled: true, severity: "warning" },
  ASSET002: { enabled: false },
  SIZE002: { enabled: true, severity: "fail", thresholds: { maxBytes: UNENFORCED_RUNTIME_BYTES } },
  SIZE003: { enabled: true, severity: "fail", thresholds: { maxBytes: UNENFORCED_RUNTIME_BYTES } },
  SIZE004: { enabled: true, severity: "fail", thresholds: { maxBytes: UNENFORCED_RUNTIME_BYTES } },
  SIZE005: { enabled: true, severity: "warning", thresholds: { maxBytes: Number.MAX_SAFE_INTEGER } },
  PERF001: { enabled: true, severity: "warning", thresholds: { maxDurationMs: UNENFORCED_RUNTIME_DURATION_MS } },
  CLICK002: { enabled: true, severity: "warning" },
  CODE001: { enabled: true, severity: "fail" },
  ADBLOCK001: { enabled: true, severity: "warning" },
  PERF002: { enabled: true, severity: "info" },
  CODE002: { enabled: true, severity: "warning" },
  JS002: { enabled: true, severity: "warning" },
  ASSET005: { enabled: true, severity: "fail" },
  TRACK001: { enabled: true, severity: "info" },
  PERF003: { enabled: true, severity: "info" },
  NET003: { enabled: true, severity: "info" },
  RENDER002: { enabled: true, severity: "info" },
  CODE003: { enabled: true, severity: "fail" },
} satisfies ValidationProfile["rules"];
