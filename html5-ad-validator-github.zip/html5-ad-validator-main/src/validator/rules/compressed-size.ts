import type { ValidationRule } from "../types";

function formatBytes(bytes: number): string {
  if (bytes < 1024) {
    return `${bytes} B`;
  }

  if (bytes < 1024 * 1024) {
    return `${(bytes / 1024).toFixed(2)} KB`;
  }

  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export const compressedSizeRule: ValidationRule = {
  id: "SIZE001",

  name: "Compressed File Size",

  description:
    "Checks the compressed size of the uploaded ZIP archive.",

  category: "performance",

  type: "static",

  async run(context, ruleProfile) {
    const actualSize = context.compressedSize;
    const maxBytes = ruleProfile?.thresholds?.maxBytes;

    if (maxBytes === undefined) {
      throw new Error("SIZE001 requires thresholds.maxBytes in the active validation profile.");
    }

    const passed = actualSize <= maxBytes;
    const severity = ruleProfile?.severity ?? "fail";

    return {
      ruleId: "SIZE001",
      title: "Compressed File Size",
      category: "performance",
      status: passed ? "pass" : severity,

      actual: formatBytes(actualSize),
      expected: `<= ${formatBytes(maxBytes)}`,

      message: passed
        ? `Compressed ZIP size is ${formatBytes(actualSize)}.`
        : `Compressed ZIP size is ${formatBytes(
            actualSize
          )}, which exceeds the ${formatBytes(maxBytes)} limit.`,

      recommendation: passed
        ? undefined
        : "Reduce asset sizes or remove unnecessary files.",
    };
  },
};
