import { describe, expect, it } from "vitest";
import type { CreativeContext } from "../context";
import { validateCreative } from "../engine";
import { imageOptimizationRule } from "./image-optimization";

function context(files: Array<[string, number]>): CreativeContext {
  return {
    filename: "test.zip",
    compressedSize: 1,
    files: new Map(files.map(([path, size]) => [path, {
      path,
      size,
      extension: path.split(".").pop() ?? "",
      content: "",
    }])),
  };
}

describe("image optimization rule", () => {
  it("passes when packaged images are within the profile threshold", async () => {
    const result = await imageOptimizationRule.run(context([["index.html", 1], ["hero.png", 100]]), {
      enabled: true,
      severity: "warning",
      thresholds: { maxImageBytes: 100 },
    });

    expect(result).toMatchObject({
      ruleId: "ASSET003",
      status: "pass",
      actual: "100 B",
      expected: "Each image <= 100 B",
    });
  });

  it("uses profile severity when images exceed the threshold", async () => {
    const result = await imageOptimizationRule.run(context([["hero.png", 101], ["logo.svg", 20]]), {
      enabled: true,
      severity: "warning",
      thresholds: { maxImageBytes: 100 },
    });

    expect(result.status).toBe("warning");
    expect(result.files).toEqual(["hero.png"]);
  });

  it("does not display the non-enforcing placeholder threshold as a file size", async () => {
    const result = await imageOptimizationRule.run(context([["hero.png", 101]]), {
      enabled: true,
      severity: "warning",
      thresholds: { maxImageBytes: Number.MAX_SAFE_INTEGER },
    });

    expect(result.status).toBe("pass");
    expect(result.expected).toBe("No configured image size limit");
    expect(result.message).toContain("No image size threshold is configured");
  });

  it("can be disabled by profile", async () => {
    const results = await validateCreative(context([["index.html", 1], ["hero.png", 101]]), {
      id: "no-image-optimization",
      name: "No Image Optimization",
      rules: {
        PKG001: { enabled: false },
        FILE001: { enabled: false },
        SIZE001: { enabled: false },
        HTML001: { enabled: false },
        HTML002: { enabled: false },
        HTML003: { enabled: false },
        MEDIA001: { enabled: false },
        MEDIA002: { enabled: false },
        ASSET003: { enabled: false },
        NET002: { enabled: false },
        ASSET004: { enabled: false },
        SEC001: { enabled: false },
        CLICK001: { enabled: false },
        GWD001: { enabled: false },
        GWD002: { enabled: false },
        RENDER001: { enabled: false },
        CODE001: { enabled: false },
        SIZE005: { enabled: false },
        ANIM002: { enabled: false },
        ANIM001: { enabled: false },
        ASSET005: { enabled: false },
        CODE002: { enabled: false },
        CODE003: { enabled: false },
      },
    });

    expect(results).toEqual([]);
  });
});
