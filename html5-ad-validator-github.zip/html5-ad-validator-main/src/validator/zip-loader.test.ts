import { describe, expect, it } from "vitest";
import { loadCreativeZip } from "./zip-loader";

describe("ZIP loading hardening", () => {
  it("rejects malformed ZIP archives", async () => {
    const malformed = new File(["not a zip"], "creative.zip", { type: "application/zip" });
    await expect(loadCreativeZip(malformed)).rejects.toThrow();
  });
});
