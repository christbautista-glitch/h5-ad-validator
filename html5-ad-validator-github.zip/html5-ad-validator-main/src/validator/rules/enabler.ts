import type { ValidationRule } from "../types";

const LIBRARY_FINGERPRINTS = [
  { name: "Google Studio Enabler", patterns: [/\bEnabler\b/i, /\bstudio\.Enabler\b/i] },
  { name: "GreenSock (GSAP)", patterns: [/\bgsap\b/i, /\bTweenMax\b/i, /\bTimelineMax\b/i] },
  { name: "CreateJS", patterns: [/\bcreatejs\b/i, /\b(?:createjs\.)?Stage\b/i, /\bcreatejs\.Ticker\b/i] },
  { name: "Google Web Designer", patterns: [/\bgwd-page\b/i, /\bgwd-gen-\w+/i, /\bgoogle-web-designer\b/i] },
  { name: "jQuery", patterns: [/\bjQuery\b/, /\$\s*\(/] },
];

const STUDIO_ENABLER_SCRIPT = /<script\b[^>]*\bsrc\s*=\s*["']https:\/\/s0\.2mdn\.net\/ads\/studio\/Enabler\.js(?:[?#][^"']*)?["'][^>]*>/i;
const ANY_ENABLER_SCRIPT = /<script\b[^>]*\bsrc\s*=\s*["'][^"']*\bEnabler\.js(?:[?#][^"']*)?["'][^>]*>/i;

export const enablerRule: ValidationRule = {
  id: "GWD001",
  name: "Enabler",
  description: "Validates Google Studio Enabler usage based on the active profile.",
  category: "javascript",
  type: "static",
  async run(context, ruleProfile) {
    const source = [...context.files.values()]
      .filter((file) => ["html", "htm", "js"].includes(file.extension))
      .map((file) => file.content ?? "")
      .join("\n");
    const detectedLibraries = LIBRARY_FINGERPRINTS
      .filter((library) => library.patterns.some((pattern) => pattern.test(source)))
      .map((library) => library.name);
    const indexHtml = context.indexHtml ?? context.files.get("index.html")?.content ?? "";
    const studioEnablerLoaded = STUDIO_ENABLER_SCRIPT.test(indexHtml);
    const enablerScriptLoaded = ANY_ENABLER_SCRIPT.test(indexHtml);
    const requireEnabler = ruleProfile?.thresholds?.requireEnabler;
    const severity = ruleProfile?.severity ?? "fail";
    const configured = requireEnabler === 0 || requireEnabler === 1;
    const detected = detectedLibraries.length > 0;
    const passed = configured ? (requireEnabler === 1 ? studioEnablerLoaded : !enablerScriptLoaded) : detected;

    return {
      ruleId: "GWD001",
      title: "Enabler Policy",
      category: "javascript",
      status: configured ? (passed ? "pass" : severity) : detected ? "pass" : "info",
      actual: configured ? (requireEnabler === 1 ? studioEnablerLoaded : enablerScriptLoaded) : detected,
      expected: configured ? (requireEnabler === 1 ? "index.html loads the Studio Enabler.js" : "index.html does not load Enabler.js") : "No Enabler policy configured",
      message: passed
        ? requireEnabler === 1
          ? "index.html loads the required Google Studio Enabler.js script."
          : requireEnabler === 0
            ? "index.html does not load Enabler.js, as required."
            : detectedLibraries.length
              ? `Detected library fingerprint(s): ${detectedLibraries.join(", ")}.`
              : "No supported library fingerprints were detected."
        : requireEnabler === 1
          ? "index.html must load https://s0.2mdn.net/ads/studio/Enabler.js for this profile."
          : "index.html must not load Enabler.js for this profile.",
      files: configured ? ["index.html"] : undefined,
      details: configured ? { libraries: detectedLibraries, studioEnablerLoaded, enablerScriptLoaded, requireEnabler } : { libraries: detectedLibraries },
      recommendation: passed ? undefined : requireEnabler === 1 ? "Load the required Studio Enabler.js script from index.html." : "Remove the Enabler.js script tag from index.html.",
    };
  },
};
