import { createServer, type Server } from "node:http";
import type { CreativeContext } from "../context";
import type { RuntimeContext, RuntimeResponse } from "./types";
import { PNG } from "pngjs";
import { launchChromium, type PlaywrightBrowser, type PlaywrightPage } from "./chromium";

const RUNTIME_TIMEOUT_MS = 10_000;
const MAX_RUNTIME_REQUESTS = 1_000;
const ANIMATION_SAMPLE_MS = 100;
const ANIMATION_STABLE_SAMPLES = 3;
const ANIMATION_TIMEOUT_MS = 10_000;
const POST_LOAD_OBSERVATION_MS = 1_000;

export function analyzeScreenshot(bytes: Uint8Array): { nonBlankPixels: number; edgeContrast: boolean } {
  try {
    const image = PNG.sync.read(Buffer.from(bytes));
    const background = [image.data[0], image.data[1], image.data[2]];
    let nonBlankPixels = 0;
    let edgeContrast = false;
    for (let y = 0; y < image.height; y += 1) {
      for (let x = 0; x < image.width; x += 1) {
        const index = (y * image.width + x) * 4;
        const difference = Math.abs(image.data[index] - background[0]) + Math.abs(image.data[index + 1] - background[1]) + Math.abs(image.data[index + 2] - background[2]);
        if (difference > 30) {
          nonBlankPixels += 1;
          if (x < 3 || y < 3 || x >= image.width - 3 || y >= image.height - 3) edgeContrast = true;
        }
      }
    }
    return { nonBlankPixels, edgeContrast };
  } catch {
    return { nonBlankPixels: 0, edgeContrast: false };
  }
}

function declaredAnimationDurationMs(context: CreativeContext): number | undefined {
  const durations: number[] = [];
  const durationPattern = /(?:animation-duration|transition-duration|duration|animationDuration)\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*(ms|s)?/gi;
  const gsapDurationPattern = /\.to\s*\([^)]*\{[^}]*\bduration\s*:\s*([0-9]+(?:\.[0-9]+)?)/gi;

  for (const file of context.files.values()) {
    if (!file.content || !["js", "css", "html", "htm"].includes(file.extension)) continue;
    const source = file.content;
    for (const match of source.matchAll(durationPattern)) {
      const value = Number(match[1]);
      if (!Number.isFinite(value) || value <= 0) continue;
      durations.push((match[2]?.toLowerCase() === "s" ? value * 1000 : value));
    }
    if (file.extension === "js") {
      for (const match of source.matchAll(gsapDurationPattern)) {
        const value = Number(match[1]);
        if (Number.isFinite(value) && value > 0) durations.push(value * 1000);
      }
    }
  }

  return durations.length ? Math.round(Math.max(...durations)) : undefined;
}

export function processRuntimeFacts(facts: RuntimeContext): RuntimeContext {
  return {
    ...facts,
    consoleErrors: [...new Set(facts.consoleErrors)],
    consoleWarnings: [...new Set(facts.consoleWarnings ?? [])],
    pageErrors: [...new Set(facts.pageErrors)],
    navigationAttempts: [...new Set(facts.navigationAttempts)],
    popupAttempts: [...new Set(facts.popupAttempts)],
  };
}

async function measureAnimationDuration(page: PlaywrightPage): Promise<number> {
  const started = Date.now();
  let previous = "";
  let stableSamples = 0;
  let animationStartedAt: number | undefined;
  while (Date.now() - started < ANIMATION_TIMEOUT_MS) {
    const current = await page.evaluate(() => Array.from(document.querySelectorAll<HTMLElement>("body *"))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
      })
      .slice(0, 200)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return [element.tagName, rect.x, rect.y, rect.width, rect.height, style.opacity, style.transform].join(":");
      }).join("|"));
    if (current === previous) {
      stableSamples += 1;
    } else {
      animationStartedAt ??= Date.now();
      stableSamples = 0;
    }
    if (animationStartedAt !== undefined && stableSamples >= ANIMATION_STABLE_SAMPLES) return Math.max(0, Date.now() - animationStartedAt - (ANIMATION_STABLE_SAMPLES * ANIMATION_SAMPLE_MS));
    if (animationStartedAt === undefined && stableSamples >= ANIMATION_STABLE_SAMPLES) return 0;
    previous = current;
    await page.waitForTimeout(ANIMATION_SAMPLE_MS);
  }
  return -1;
}

async function measureAnimationLifecycle(page: PlaywrightPage): Promise<number | undefined> {
  return page.evaluate(() => new Promise<number | undefined>((resolve) => {
    const main = document.querySelector<HTMLElement>("#main");
    if (!main) { resolve(undefined); return; }
    const started = performance.now();
    let animationEndCalled = false;
    const original = (window as Window & { animationEnd?: () => void }).animationEnd;
    (window as Window & { animationEnd?: () => void }).animationEnd = () => {
      animationEndCalled = true;
      original?.();
      resolve(Math.round(performance.now() - started));
    };
    const checkOpacity = () => {
      const opacity = Number.parseFloat(getComputedStyle(main).opacity);
      if (opacity >= 1 && !animationEndCalled) {
        setTimeout(() => { if (!animationEndCalled) resolve(Math.round(performance.now() - started)); }, 50);
      } else if (!animationEndCalled) requestAnimationFrame(checkOpacity);
    };
    requestAnimationFrame(checkOpacity);
    setTimeout(() => { if (!animationEndCalled) resolve(undefined); }, 2_000);
  }));
}

function startCreativeServer(context: CreativeContext): Promise<{ server: Server; origin: string }> {
  return new Promise((resolve, reject) => {
    const server = createServer((request, response) => {
      let pathname: string;
      try {
        pathname = decodeURIComponent((request.url ?? "/").split("?")[0]);
      } catch {
        response.writeHead(400); response.end("Bad request"); return;
      }
      const path = pathname === "/" ? "index.html" : pathname.replace(/^\//, "");
      if (path.includes("..") || path.startsWith("/")) { response.writeHead(400); response.end("Bad request"); return; }
      const file = context.files.get(path);
      if (!file) { response.writeHead(404); response.end("Not found"); return; }
      const body = file.contentBytes ?? file.content ?? Buffer.alloc(file.size);
      const bodyBytes = typeof body === "string" ? Buffer.byteLength(body) : body.byteLength;
      response.writeHead(200, { "content-type": contentType(file.extension), "content-length": String(bodyBytes), "cache-control": "no-store" });
      response.end(body);
    });
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      if (!address || typeof address === "string") { reject(new Error("Could not determine runtime server address.")); return; }
      resolve({ server, origin: `http://127.0.0.1:${address.port}` });
    });
  });
}

function contentType(extension: string): string {
  return ({ html: "text/html", htm: "text/html", css: "text/css", js: "text/javascript", json: "application/json", svg: "image/svg+xml", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", mp4: "video/mp4", mp3: "audio/mpeg" } as Record<string, string>)[extension] ?? "application/octet-stream";
}


export async function runRuntimeAnalysis(context: CreativeContext): Promise<RuntimeContext> {
  const { server, origin } = await startCreativeServer(context);
  const facts: RuntimeContext = { origin, runtimeStatus: "available", consoleErrors: [], consoleWarnings: [], pageErrors: [], requests: [], responses: [], requestFailures: [], dialogs: [], images: [], videos: [], externalUrls: [], insecureUrls: [], rendered: false, navigationAttempts: [], navigationResponses: [], popupAttempts: [], durationMs: 0 };
  const started = Date.now();
  let browser: PlaywrightBrowser | undefined;
  let page: PlaywrightPage | undefined;
  let subloadStarted = false;
  let requestLimitReached = false;
  let timeoutHandle: ReturnType<typeof setTimeout> | undefined;
  try {
    browser = await launchChromium();
    page = await browser.newPage();
    await page.route("**/*", async (route) => {
      if (facts.requests.length >= MAX_RUNTIME_REQUESTS) {
        requestLimitReached = true;
        await route.abort("blockedbyclient");
        return;
      }
      await route.continue();
    });
    page.on("console", (message: { type: () => string; text: () => string }) => { if (message.type() === "error") facts.consoleErrors.push(message.text()); else if (message.type() === "warning") facts.consoleWarnings?.push(message.text()); });
    page.on("pageerror", (error: Error) => facts.pageErrors.push(error.message));
    page.on("dialog", async (dialog: { type: () => string; message: () => string; dismiss: () => Promise<void> }) => { facts.dialogs?.push({ type: dialog.type(), message: dialog.message() }); await dialog.dismiss(); });
    page.on("domcontentloaded", () => { subloadStarted = true; });
    page.on("request", (request: { url: () => string; method: () => string; resourceType: () => string }) => facts.requests.push({ url: request.url(), method: request.method(), resourceType: request.resourceType() }));
    page.on("response", async (response: { url: () => string; status: () => number; request: () => { resourceType: () => string }; headers: () => Record<string, string>; body: () => Promise<Uint8Array> }) => {
      const contentLength = Number(response.headers()["content-length"]);
      const item: RuntimeResponse = { url: response.url(), status: response.status(), contentLength: Number.isFinite(contentLength) && contentLength >= 0 ? contentLength : undefined, resourceType: response.request().resourceType(), phase: subloadStarted ? "subload" : "initial" };
      facts.responses.push(item);
      if (item.contentLength === undefined) {
        try { item.transferredBytes = (await response.body()).byteLength; } catch { /* response body unavailable */ }
      } else item.transferredBytes = item.contentLength;
    });
    page.on("requestfailed", (request: { url: () => string; method: () => string; resourceType: () => string; failure?: () => { errorText?: string } | null }) => facts.requestFailures.push({ url: request.url(), method: request.method(), resourceType: request.resourceType(), errorText: request.failure?.()?.errorText }));
    page.on("framenavigated", (frame: { url: () => string }) => { const url = frame.url(); if (url !== `${origin}/index.html`) facts.navigationAttempts.push(url); });
    page.on("response", (response: { url: () => string; status: () => number; request: () => { resourceType: () => string } }) => {
      if (response.request().resourceType() === "document" && response.url() !== `${origin}/index.html`) facts.navigationResponses?.push({ url: response.url(), status: response.status() });
    });
    page.on("popup", (popup: { url: () => string }) => facts.popupAttempts.push(popup.url()));
    await Promise.race([
      page.goto(`${origin}/index.html`, { waitUntil: "load", timeout: RUNTIME_TIMEOUT_MS }),
      new Promise<never>((_, reject) => { timeoutHandle = setTimeout(() => reject(new Error("Runtime validation timed out.")), RUNTIME_TIMEOUT_MS); }),
    ]);
    facts.images = await page.evaluate(() => Array.from(document.images).map((image) => ({ url: image.currentSrc || image.src, complete: image.complete, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight })));
    facts.videos = await page.evaluate(() => Array.from(document.querySelectorAll<HTMLVideoElement>("video")).map((video) => ({ url: video.currentSrc || video.src, paused: video.paused, readyState: video.readyState, currentTime: video.currentTime, error: video.error?.message, muted: video.muted, autoplay: video.autoplay })));
    const paintFacts = await page.evaluate(() => {
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      const visibleElement = Array.from(document.querySelectorAll<HTMLElement>("body *")).some((element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0
          && rect.height > 0
          && style.display !== "none"
          && style.visibility !== "hidden"
          && Number.parseFloat(style.opacity) > 0
          && rect.bottom > 0
          && rect.right > 0
          && rect.left < viewportWidth
          && rect.top < viewportHeight;
      });
      const sampledPoint = document.elementFromPoint(viewportWidth / 2, viewportHeight / 2);
      const sampledContent = Boolean(sampledPoint && sampledPoint !== document.body && sampledPoint !== document.documentElement);
      const paints = performance.getEntriesByType("paint").map((entry) => ({ name: entry.name, startTime: entry.startTime }));
      const firstPaint = paints.find((entry) => entry.name === "first-paint") ?? paints.find((entry) => entry.name === "first-contentful-paint");
      return { painted: visibleElement || sampledContent, visualStartMs: firstPaint?.startTime };
    });
    const screenshot = await page.screenshot({ type: "png" });
    const screenshotAnalysis = analyzeScreenshot(screenshot);
    facts.animationDurationMs = declaredAnimationDurationMs(context) ?? await measureAnimationLifecycle(page) ?? await measureAnimationDuration(page);
    const cssBorder = await page.evaluate(() => {
      const candidates = ["#exitButton", "#ad", "#container", "#main", "#mainContent", ".ad", ".container", ".main", ".mainContent"]
        .map((selector) => document.querySelector<HTMLElement>(selector)).filter((element): element is HTMLElement => Boolean(element));
      return candidates.some((element) => {
        const style = getComputedStyle(element);
        return [style.borderTopWidth, style.borderRightWidth, style.borderBottomWidth, style.borderLeftWidth].some((width) => Number.parseFloat(width) > 0);
      });
    });
    facts.visual = {
      painted: paintFacts.painted && screenshotAnalysis.nonBlankPixels > 0,
      visualStartMs: paintFacts.visualStartMs ?? (paintFacts.painted ? Date.now() - started : undefined),
      screenshotCaptured: screenshot.byteLength > 0,
      screenshotBytes: screenshot.byteLength,
      creativeBorder: await page.evaluate(() => {
        const candidates = [
          document.querySelector<HTMLElement>("#exitButton"),
          document.body,
          document.documentElement,
          document.querySelector<HTMLElement>("#ad"),
          document.querySelector<HTMLElement>("#container"),
          document.querySelector<HTMLElement>("#main"),
          document.querySelector<HTMLElement>("#mainContent"),
          document.querySelector<HTMLElement>(".ad"),
          document.querySelector<HTMLElement>(".container"),
          document.querySelector<HTMLElement>(".main"),
          document.querySelector<HTMLElement>(".mainContent"),
        ].filter((element): element is HTMLElement => Boolean(element));

        for (const element of candidates) {
          const style = getComputedStyle(element);
          const borders = [
            style.borderTopWidth,
            style.borderRightWidth,
            style.borderBottomWidth,
            style.borderLeftWidth,
          ].map((value) => Number.parseFloat(value));
          const styles = [
            style.borderTopStyle,
            style.borderRightStyle,
            style.borderBottomStyle,
            style.borderLeftStyle,
          ];
          const hasVisibleBorder = borders.some((width) => width > 0)
            && styles.some((borderStyle) => borderStyle !== "none" && borderStyle !== "hidden");

          if (hasVisibleBorder) {
            return {
              detected: true,
              method: "css-border" as const,
              element: element === document.documentElement ? "html" : element === document.body ? "body" : element.tagName.toLowerCase(),
            };
          }
        }

        return { detected: false, method: "unknown" as const };
      }),
    };
    if (screenshotAnalysis.edgeContrast && facts.visual.creativeBorder && !facts.visual.creativeBorder.detected) {
      facts.visual.creativeBorder = { detected: true, method: "edge-pixels" };
    } else if (cssBorder && facts.visual.creativeBorder && !facts.visual.creativeBorder.detected) {
      facts.visual.creativeBorder = { detected: true, method: "css-border" };
    }
    facts.rendered = facts.visual.painted ?? false;
    const clickTarget = await page.evaluate(() => {
      const clickable = document.querySelector<HTMLElement>("a[href], [onclick], [data-click], [data-clicktag], button");
      if (!clickable) return undefined;
      clickable.click();
      return clickable.outerHTML.slice(0, 500);
    }).catch(() => undefined);
    facts.clickTargetFound = Boolean(clickTarget);
    facts.clickTarget = clickTarget;
    await page.waitForTimeout(POST_LOAD_OBSERVATION_MS);
    const navigationUrls = new Set([...(facts.navigationAttempts), ...(facts.popupAttempts)]);
    for (const response of facts.navigationResponses ?? []) response.isFinal = navigationUrls.has(response.url);
    facts.initialLoadBytes = facts.responses.filter((response) => response.phase === "initial").reduce((total, response) => total + (response.transferredBytes ?? 0), 0) || undefined;
    facts.subloadBytes = facts.responses.filter((response) => response.phase === "subload").reduce((total, response) => total + (response.transferredBytes ?? 0), 0);
    facts.totalLoadBytes = facts.responses.reduce((total, response) => total + (response.transferredBytes ?? 0), 0) || undefined;
    facts.transferredBytes = facts.totalLoadBytes;
    facts.externalUrls = [...new Set(facts.requests.map((request) => request.url).filter((url) => { try { return new URL(url).origin !== origin; } catch { return false; } }))];
    facts.insecureUrls = [...new Set(facts.requests.map((request) => request.url).filter((url) => url.startsWith("http://")))];
    if (requestLimitReached) {
      facts.pageErrors.push(`Runtime request limit of ${MAX_RUNTIME_REQUESTS} was reached.`);
    }
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
    facts.durationMs = Date.now() - started;
    await page?.close().catch(() => undefined);
    await browser?.close().catch(() => undefined);
    await new Promise<void>((resolve) => {
      if (!server.listening) { resolve(); return; }
      server.close(() => resolve());
    });
  }
  return processRuntimeFacts(facts);
}
