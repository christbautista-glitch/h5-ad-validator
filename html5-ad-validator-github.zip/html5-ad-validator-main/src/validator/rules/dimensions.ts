import type { ValidationRule } from "../types";

interface Dimensions {
  width: number;
  height: number;
}

function detectDimensions(
  html: string
): Dimensions | null {
  const adSizeMatch = html.match(
    /content=["'][^"']*width\s*=\s*(\d+)\s*,\s*height\s*=\s*(\d+)/i
  );

  if (adSizeMatch) {
    return {
      width: Number(adSizeMatch[1]),
      height: Number(adSizeMatch[2]),
    };
  }

  const cssSizeMatch = html.match(
    /width\s*:\s*(\d+)px[\s\S]*?height\s*:\s*(\d+)px/i
  );

  if (cssSizeMatch) {
    return {
      width: Number(cssSizeMatch[1]),
      height: Number(cssSizeMatch[2]),
    };
  }

  const elementSizeMatch = html.match(
    /width=["'](\d+)["'][^>]*height=["'](\d+)["']/i
  );

  if (elementSizeMatch) {
    return {
      width: Number(elementSizeMatch[1]),
      height: Number(elementSizeMatch[2]),
    };
  }

  return null;
}

export const dimensionsRule: ValidationRule = {
  id: "HTML001",

  name: "Creative Dimension",

  description:
    "Attempts to determine the creative width and height.",

  category: "html",

  type: "static",

  async run(context) {
    if (!context.indexHtml) {
      return {
        ruleId: "HTML001",
        title: "Creative Dimension",
        category: "html",
        status: "fail",

        message:
          "Cannot determine dimensions because index.html is missing.",
      };
    }

    const dimensions =
      detectDimensions(context.indexHtml);

    if (!dimensions) {
      return {
        ruleId: "HTML001",
        title: "Creative Dimension",
        category: "html",
        status: "warning",

        actual: "Unknown",

        message:
          "Creative dimensions could not be determined statically.",

        recommendation:
          "Declare the creative size using meta ad.size or explicit width and height values.",
      };
    }

    const value =
      `${dimensions.width}x${dimensions.height}`;

    return {
      ruleId: "HTML001",
      title: "Creative Dimension",
      category: "html",
      status: "pass",

      actual: value,

      message:
        `Creative dimensions detected as ${value}.`,
    };
  },
};