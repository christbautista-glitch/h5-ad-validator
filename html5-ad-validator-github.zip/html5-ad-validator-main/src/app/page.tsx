import CreativeUpload from "@/components/creative-upload";
import { listValidationProfiles } from "@/validator/profiles/registry";

export default function Home() {
  return <CreativeUpload validationProfiles={listValidationProfiles()} />;
}
