import type { ValidationRule } from "../types";

function formatBytes(bytes: number): string {
  return bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(2)} KB` : `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export const hostedSizeRule: ValidationRule = {
  id: "SIZE005",
  name: "Hosted File Size",
  description: "Checks the uncompressed size of files served by the creative.",
  category: "performance",
  type: "static",
  async run(context, ruleProfile) {
    const actualBytes = [...context.files.values()].reduce((total, file) => total + file.size, 0);
    const maxBytes = ruleProfile?.thresholds?.maxBytes;
    const enforced = maxBytes !== undefined && maxBytes < Number.MAX_SAFE_INTEGER;
    const exceeds = enforced && actualBytes > maxBytes;
    return {
      ruleId: "SIZE005",
      title: "Hosted File Size",
      category: "performance",
      status: exceeds ? ruleProfile?.severity ?? "warning" : "pass",
      actual: formatBytes(actualBytes),
      expected: enforced ? `<= ${formatBytes(maxBytes)}` : undefined,
      message: exceeds ? `Hosted file size is ${formatBytes(actualBytes)}, exceeding the ${formatBytes(maxBytes)} limit.` : `Hosted file size is ${formatBytes(actualBytes)} across ${context.files.size} file(s).`,
      details: { hostedBytes: actualBytes, fileCount: context.files.size, maxBytes: enforced ? maxBytes : undefined },
    };
  },
};
