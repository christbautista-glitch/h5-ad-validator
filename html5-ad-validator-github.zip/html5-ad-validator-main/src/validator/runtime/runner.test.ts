import { describe, expect, it } from "vitest";
import { processRuntimeFacts } from "./runner";

describe("runtime result processing", () => {
  it("deduplicates repeated runtime facts", () => {
    const result = processRuntimeFacts({ origin: "http://127.0.0.1:1", runtimeStatus: "available", consoleErrors: ["boom", "boom"], pageErrors: ["page", "page"], requests: [], responses: [], requestFailures: [], images: [], rendered: true, navigationAttempts: ["/a", "/a"], popupAttempts: ["/b", "/b"], durationMs: 1 });
    expect(result.consoleErrors).toEqual(["boom"]);
    expect(result.pageErrors).toEqual(["page"]);
    expect(result.navigationAttempts).toEqual(["/a"]);
    expect(result.popupAttempts).toEqual(["/b"]);
  });

  it("preserves phase-aware transfer sizes", () => {
    const result = processRuntimeFacts({ origin: "http://127.0.0.1:1", runtimeStatus: "available", consoleErrors: [], pageErrors: [], requests: [], responses: [
      { url: "http://127.0.0.1:1/index.html", status: 200, contentLength: 100, phase: "initial" },
      { url: "http://127.0.0.1:1/lazy.png", status: 200, contentLength: 50, phase: "subload" },
    ], requestFailures: [], images: [], rendered: true, navigationAttempts: [], popupAttempts: [], initialLoadBytes: 100, subloadBytes: 50, totalLoadBytes: 150, durationMs: 1 });
    expect(result.initialLoadBytes).toBe(100);
    expect(result.subloadBytes).toBe(50);
    expect(result.totalLoadBytes).toBe(150);
  });
});
