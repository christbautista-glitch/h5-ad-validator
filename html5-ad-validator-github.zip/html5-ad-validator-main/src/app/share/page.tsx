import SharedResults from "@/components/shared-results";

export default function SharePage() {
  return <SharedResults />;
}
