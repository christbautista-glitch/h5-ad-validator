import type { ValidationProfile } from "./types";
import { commonRuleProfiles } from "./shared";

const MB = 1024 * 1024;

export const HTML5_STANDARD_PROFILE_ID = "html5-standard";

export const html5StandardProfile: ValidationProfile = {
  id: HTML5_STANDARD_PROFILE_ID,
  name: "HTML5 Standard",
  description: "Platform-neutral HTML5 creative validation profile.",
  rules: {
    ...commonRuleProfiles,
    SIZE001: { enabled: true, severity: "fail", thresholds: { maxBytes: 4 * MB } },
    GWD001: { enabled: true, severity: "fail", thresholds: { requireEnabler: 1 } },
    GWD002: { enabled: true, thresholds: { requireStudioHooks: 1 } },
  },
};
