import type { CreativeContext } from "../context";
import type { ValidationRule } from "../types";

const durationPattern = /(?:animation-duration|transition-duration|duration|animationDuration)\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)\s*(ms|s)?/gi;

export const animationPolicyRule: ValidationRule = {
  id: "ANIM002",
  name: "Animation Policy",
  description: "Checks animation declarations for infinite loops and excessive duration.",
  category: "animation",
  type: "static",
  async run(context: CreativeContext, ruleProfile) {
    const sources = [...context.files.values()].filter((file) => ["html", "htm", "css", "js"].includes(file.extension)).map((file) => ({ path: file.path, source: file.content ?? "" }));
    const infinite = sources.filter(({ source }) => /animation-iteration-count\s*:\s*infinite|repeat\s*\(\s*infinite|repeat:\s*infinite/i.test(source)).map(({ path }) => path);
    const durations = sources.flatMap(({ path, source }) => [...source.matchAll(durationPattern)].map((match) => ({ path, durationMs: Number(match[1]) * (match[2]?.toLowerCase() === "s" ? 1000 : 1) }))).filter(({ durationMs }) => Number.isFinite(durationMs) && durationMs > 0);
    const maxDurationMs = ruleProfile?.thresholds?.maxDurationMs;
    const excessive = maxDurationMs !== undefined && maxDurationMs < Number.MAX_SAFE_INTEGER ? durations.filter(({ durationMs }) => durationMs > maxDurationMs) : [];
    const issues = [...infinite, ...excessive.map(({ path }) => path)];
    const uniqueIssues = [...new Set(issues)];
    return {
      ruleId: "ANIM002",
      title: "Animation Policy",
      category: "animation",
      status: uniqueIssues.length ? ruleProfile?.severity ?? "warning" : "pass",
      actual: uniqueIssues.length,
      expected: maxDurationMs !== undefined && maxDurationMs < Number.MAX_SAFE_INTEGER ? `<= ${maxDurationMs} ms and no infinite loops` : "No infinite animation loops",
      message: uniqueIssues.length ? `${uniqueIssues.length} animation policy issue(s) detected.` : "No infinite animation loops or excessive animation durations detected.",
      files: uniqueIssues,
      details: { infinite, excessive, durations },
    };
  },
};
