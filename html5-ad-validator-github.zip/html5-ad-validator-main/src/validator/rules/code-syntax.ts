import type { CreativeFile } from "../context";
import type { ValidationRule } from "../types";
import { parse } from "acorn";
import { parse as parseHtml } from "parse5";

interface SyntaxIssue {
  file: string;
  message: string;
}

function lineNumber(source: string, index: number): number {
  return source.slice(0, index).split("\n").length;
}

function balancedDelimiters(source: string): number | null {
  const pairs: Record<string, string> = { "(": ")", "[": "]", "{": "}" };
  const stack: Array<{ character: string; index: number }> = [];
  let quote: string | null = null;
  let escaped = false;

  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];

    if (quote) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === quote) quote = null;
      continue;
    }

    if (character === "\"" || character === "'" || character === "`") {
      quote = character;
    } else if (pairs[character]) {
      stack.push({ character, index });
    } else if (Object.values(pairs).includes(character)) {
      const opening = stack.pop();
      if (!opening || pairs[opening.character] !== character) return index;
    }
  }

  return quote || stack.length ? (quote ? source.length - 1 : stack[stack.length - 1].index) : null;
}

function checkHtml(file: CreativeFile): SyntaxIssue[] {
  const source = file.content ?? "";
  const issues: SyntaxIssue[] = [];
  parseHtml(source, {
    onParseError: (error) => {
      const line = error?.startLine ?? 1;
      const column = error?.startCol ?? 1;
      issues.push({ file: file.path, message: `HTML parser error (${error.code}) at line ${line}, column ${column}.` });
    },
  });
  return issues;
}

function checkCss(file: CreativeFile): SyntaxIssue | null {
  const source = file.content ?? "";
  const delimiter = balancedDelimiters(source);
  return delimiter === null ? null : { file: file.path, message: `Unbalanced CSS delimiters near line ${lineNumber(source, delimiter)}.` };
}

function checkJavaScript(file: CreativeFile): SyntaxIssue | null {
  const source = file.content ?? "";
  try {
    parse(source, { ecmaVersion: "latest", sourceType: "script", allowAwaitOutsideFunction: true });
    return null;
  } catch (error) {
    try {
      parse(source, { ecmaVersion: "latest", sourceType: "module", allowAwaitOutsideFunction: true });
      return null;
    } catch (moduleError) {
      return { file: file.path, message: moduleError instanceof Error ? moduleError.message : error instanceof Error ? error.message : "JavaScript syntax error detected." };
    }
  }
}

export const codeSyntaxRule: ValidationRule = {
  id: "CODE001",
  name: "Code Syntax",
  description: "Checks HTML, CSS, and JavaScript files for syntax errors.",
  category: "javascript",
  type: "static",
  async run(context) {
    const issues: SyntaxIssue[] = [];
    for (const file of context.files.values()) {
      if (!file.content) continue;
      const issue = file.extension === "html" || file.extension === "htm"
        ? checkHtml(file)
        : file.extension === "css" ? checkCss(file)
          : file.extension === "js" ? checkJavaScript(file) : null;
      if (Array.isArray(issue)) issues.push(...issue);
      else if (issue) issues.push(issue);
    }

    const issueMessage = issues.map((issue) => `${issue.file}: ${issue.message}`).join(" ");

    return {
      ruleId: "CODE001",
      title: "Code Syntax",
      category: "javascript",
      status: issues.length ? "fail" : "pass",
      actual: issues.length,
      expected: 0,
      message: issues.length ? `${issues.length} syntax error(s) detected. ${issueMessage}` : "No HTML, CSS, or JavaScript syntax errors detected.",
      files: issues.map((issue) => issue.file),
      details: { issues },
      recommendation: issues.length ? "Fix the reported syntax errors before uploading the creative." : undefined,
    };
  },
};
