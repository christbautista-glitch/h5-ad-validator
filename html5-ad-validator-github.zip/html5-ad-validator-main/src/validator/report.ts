import type { ValidationResult, ValidationStatus } from "./types";
import type { ValidationProfileMetadata } from "./profiles/types";

export interface ValidationSummary {
  total: number;
  pass: number;
  warning: number;
  fail: number;
  info: number;
}

export interface ValidationReport {
  filename: string | null;
  generatedAt: string;
  profile?: ValidationProfileMetadata;
  summary: ValidationSummary;
  results: ValidationResult[];
}

export interface BulkValidationReport {
  generatedAt: string;
  profile?: ValidationProfileMetadata;
  summary: ValidationSummary;
  creatives: ValidationReport[];
}

export function summarizeResults(results: ValidationResult[]): ValidationSummary {
  const summary: ValidationSummary = { total: results.length, pass: 0, warning: 0, fail: 0, info: 0 };
  for (const result of results) summary[result.status] += 1;
  return summary;
}

export function createValidationReport(filename: string | null, results: ValidationResult[], generatedAt = new Date().toISOString(), profile?: ValidationProfileMetadata): ValidationReport {
  return { filename, generatedAt, profile, summary: summarizeResults(results), results };
}

export function createBulkValidationReport(reports: ValidationReport[], generatedAt = new Date().toISOString(), profile?: ValidationProfileMetadata): BulkValidationReport {
  return {
    generatedAt,
    profile,
    summary: reports.reduce<ValidationSummary>((summary, report) => ({
      total: summary.total + report.summary.total,
      pass: summary.pass + report.summary.pass,
      warning: summary.warning + report.summary.warning,
      fail: summary.fail + report.summary.fail,
      info: summary.info + report.summary.info,
    }), { total: 0, pass: 0, warning: 0, fail: 0, info: 0 }),
    creatives: reports,
  };
}

export function isBlockingStatus(status: ValidationStatus): boolean {
  return status === "fail";
}
