import type { CreativeContext } from "../context";
import type { ValidationResult } from "../types";
import type { ValidationProfile } from "../profiles/types";
import type { RuntimeContext } from "./types";
import { runRuntimeAnalysis } from "./runner";
import { adBlockRule, animationDurationRule, consoleErrorsRule, consoleWarningsRule, cpuUsageRule, creativeBorderRule, imagesLoadRule, initialLoadSizeRule, landingPageRule, memoryUsageRule, networkRequestsRule, notFoundRule, runtimeDurationRule, runtimeMeasurementPixelsRule, subloadSizeRule, totalLoadSizeRule, videoPlaybackRule, visualPaintRule, visualStartRule } from "../rules/runtime";
import { getDefaultValidationProfile } from "../profiles/registry";
import { applySeverityOverride, resolveRuleProfile } from "../profiles/resolve-profile";

const runtimeRules = [animationDurationRule, adBlockRule, notFoundRule, consoleErrorsRule, consoleWarningsRule, creativeBorderRule, visualPaintRule, visualStartRule, imagesLoadRule, videoPlaybackRule, initialLoadSizeRule, subloadSizeRule, totalLoadSizeRule, runtimeDurationRule, cpuUsageRule, memoryUsageRule, networkRequestsRule, runtimeMeasurementPixelsRule, landingPageRule];

export async function validateRuntime(context: CreativeContext, profile: ValidationProfile = getDefaultValidationProfile()): Promise<{ runtime: RuntimeContext | null; results: ValidationResult[] }> {
  const enabledRules = runtimeRules.map((rule) => ({ rule, ruleProfile: resolveRuleProfile(profile, rule.id) })).filter(({ ruleProfile }) => ruleProfile.enabled);

  if (enabledRules.length === 0) {
    return { runtime: null, results: [] };
  }

  let runtime: RuntimeContext;
  try {
    runtime = await runRuntimeAnalysis(context);
  } catch (error) {
    runtime = {
      origin: "", runtimeStatus: "unavailable",
      consoleErrors: [], consoleWarnings: [], pageErrors: [], requests: [], responses: [], requestFailures: [], dialogs: [], images: [], videos: [], externalUrls: [], insecureUrls: [],
      rendered: false, navigationAttempts: [], navigationResponses: [], popupAttempts: [], durationMs: 0,
      error: error instanceof Error ? error.message : "Runtime analysis failed.",
    };
  }

  if (runtime.error || runtime.runtimeStatus === "unavailable") {
    runtime.runtimeStatus = "unavailable";
    const runtimeError = runtime.error ?? "Runtime analysis was unavailable.";
    return {
      runtime,
      results: enabledRules.map(({ rule }) => ({
        ruleId: rule.id,
        title: rule.name,
        category: rule.category,
        status: "info" as const,
        message: `Runtime check not tested: ${runtimeError}`,
        details: { runtimeAvailable: false, error: runtimeError },
      })),
    };
  }

  runtime.runtimeStatus = "available";
  const results = await Promise.all(enabledRules.map(async ({ rule, ruleProfile }) => {
    try {
      return applySeverityOverride(await rule.run(runtime, ruleProfile), ruleProfile);
    } catch (error) {
      return {
        ruleId: rule.id,
        title: rule.name,
        category: rule.category,
        status: "fail" as const,
        message: error instanceof Error ? error.message : "Runtime rule failed.",
      };
    }
  }));
  return { runtime, results };
}
